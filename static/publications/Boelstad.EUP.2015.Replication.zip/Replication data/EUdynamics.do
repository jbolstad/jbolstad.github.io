set more off
use "/your/local/directory/EUdynamics.dta", clear
************************************************************************************************************************
***** Filtering (see online the appendix for explanation):
forvalues i = 1/9 {
	** Run alternative models:
	arfima membrshp_i_`i' spring, ar(1)
	estimates store a`i'
	predict dsuppARFI`i', res
	arfima membrshp_i_`i' spring, ar(1) smemory
	estimates store b`i'
	predict dsuppAR`i', res
	arfima membrshp_i_`i' spring
	estimates store c`i'
	predict dsuppFI`i', res
	
	** Find the best model:
	lrtest a`i' c`i'
	if r(p) > 0.05 {
		local best`i' = 3
		}
	else {
		lrtest a`i' b`i',
		if r(p) > 0.05 {
			local best`i' = 2
		}
		else {
			local best`i' = 1
		}
	}

	** Select the filtered innovations for the best model:
	if `best`i'' == 1 {
		estimates restore a`i'
		gen ds`i' = dsuppARFI`i'
	}
	if `best`i'' == 2 {
		estimates restore b`i'
		gen ds`i' = dsuppAR`i'
	}
	if `best`i'' == 3 {
		estimates restore c`i'
		gen ds`i' = dsuppFI`i'
	}
	
	** Store results for the best model:
	mat beta = e(b)
	
	if `best`i'' == 2 {
		mat ar = (nullmat(ar) \ beta[1,3])
	}
	else {
		mat ar = (nullmat(ar) \ . )
	}
	
	if `best`i'' == 3 {
		mat d = (nullmat(d) \ beta[1,3])
	}
	else {
		mat d = (nullmat(d) \ . )
	}
	
	** Prepare results to be reported:
	mat spring = (nullmat(spring) \ beta[1,1])
	mat cons = (nullmat(cons) \ beta[1,2])
	mat sigma2 = (nullmat(sigma2) \ beta[1,4])
	dfuller membrshp_i_`i', trend
	mat dfullerpre = (nullmat(dfullerpre) \ r(p))
	sum membrshp_i_`i'
	mat sdpre = (nullmat(sdpre) \ r(sd))
	dfuller ds`i', trend
	mat dfullerpost = (nullmat(dfullerpost) \ r(p))
	sum ds`i'
	mat sdpost = (nullmat(sdpost) \ r(sd))

}

mat filtertab = (cons,spring,ar,d,sdpre,dfullerpre,sdpost,dfullerpost)
matrix rownames filtertab =  "France" "Belgium" "Netherlands" "W_Germany" "Italy" "Luxembourg" "Denmark" "Ireland" "U_K"
matrix colnames filtertab =  "Constant/Mean" "Spring" "L1/AR(1)" "d" "sd, pre" "dfuller p-value, pre" "sd, post" "dfuller p-value, post"

forvalues j = 1/8 {
	forvalues i = 1/9 {
	mat filtertab[`i',`j'] = round(filtertab[`i',`j'],.001)
	}
}

** Display the filtering models:
esttab matrix(filtertab) 
	
** Generate integrated measures:
forvalues i = 1/9 {
	gen i_ds`i' = sum(ds`i') if ds`i' < .
}

************************************************************************************************************************
***** Factor analysis:
factor ds1 ds2 ds3 ds4 ds5 ds7 ds8 ds9, factors(2)
fapara, reps(10)
factor ds1 ds2 ds3 ds4 ds5 ds7 ds8 ds9, factors(2)

predict main sec
gen i_main = sum(main) if main < .
gen i_sec = sum(sec) if sec < .
rotate, oblimin 
rotate, oblimin blank(.5)
predict main_obli sec_obli
gen i_main_obli = sum(main_obli) if main_obli < .
gen i_sec_obli = sum(sec_obli) if sec_obli < .

factor ds1 ds2 ds3 ds4 ds5 ds7 ds8 ds9, factors(2)
mat unrotload = e(L) 
mat EV = e(Ev)
local EV1 = round(EV[1,1],.001)
local EV2 = round(EV[1,2],.001)
rotate, oblimin 
mat EV = e(r_Ev)
mat tab = (unrotload , e(r_L), e(Psi)')
mat EVtab = ( `EV1' , `EV2' , . , . , . )
mat tab = (tab \ ( `EV1' , `EV2' , . , . , . ))

forvalues j = 1/5 {
	forvalues i = 1/8 {
	mat tab[`i',`j'] = round(tab[`i',`j'],.001)
	}
}
matrix rownames tab =  "France" "Belgium" "Netherlands" "W_Germany" "Italy" "Denmark" "Ireland" "UK" "Eigenvalue"
matrix colnames tab =  "Factor 1" "Factor 2" "Core" "Periphery" "Uniqueness"

** Display factor analysis:
esttab matrix(tab)

************************************************************************************************************************
***** VEC model:
varsoc sum_dir i_main_obli i_sec_obli, exog(time) maxlag(4)
vecrank sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(2) ic levela

constraint 1 [_ce1]sum_dir = 1
constraint 2 [_ce1]i_main_obli = 0
constraint 3 [_ce2]sum_dir = 1
constraint 4 [_ce2]i_sec_obli = 0

* vec sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(1) rank(2) bconstraints(1/4) 
* vec sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(2) rank(2) bconstraints(1/4) 
** Best alternative model:
* vec sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(4) rank(2) bconstraints(1/4) 
* veclmar, mlag(4)
** Final, parsimonius model:
vec sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(2) rank(1)
vecstable
veclmar, mlag(4)
** Predict error-correction term:
predict fdECT, ce
** Predict residuals:
predict fdres_sum_dir, res equation(#1)
predict fdres_factor1, res equation(#2)
predict fdres_factor2, res equation(#3)
** Stationarity:
dfuller fdECT 
dfuller fdres_sum_dir
dfuller fdres_factor1
dfuller fdres_factor2
** IRFs and FEVD:
irf create factorvecirf, set(vecf4) replace step(30)
irf graph oirf, irf(factorvecirf) set(vecf4) lstep(0) ustep(30)  name(df1irf, replace)
irf graph fevd, irf(factorvecirf) set(vecf4) lstep(0) ustep(30)  name(df1fevd, replace)

*** Reporting VEC model:
vec sum_dir i_main_obli i_sec_obli, trend(rtrend) lags(2) rank(1)
** Calculate p of Chi2:
local pchi2_1 = chi2tail(e(k_1),e(chi2_1))
local pchi2_2 = chi2tail(e(k_2),e(chi2_2))
local pchi2_3 = chi2tail(e(k_3),e(chi2_3))
** 
estadd scalar pchi2_1 `pchi2_1'
estadd scalar pchi2_2 `pchi2_2'
estadd scalar pchi2_3 `pchi2_3'

estimates store vecfactor

** Display VEC Model:
esttab vecfactor, unstack label b(3) se nogaps scalars(r2_1 r2_2 r2_3  chi2_1 chi2_2 chi2_3 pchi2_1 pchi2_2 pchi2_3) nonumbers ///
	eqlabels("D.Integration" "D.Core" "D.Periphery") /// 
    varlabels(L._ce1  "L.ECT" LD.sum_dir "L.D.Integration" LD.i_main_obli "L.D.Core" LD.i_sec_obli "L.D.Periphery" _cons "Constant")

*** Reporting EC-equation:
mat betaEC = e(beta)
mat VCE_EC = e(V_beta)
local se1 = round(sqrt(VCE_EC[2,2]),.001)
local se2 = round(sqrt(VCE_EC[3,3]),.001)
local se3 = round(sqrt(VCE_EC[4,4]),.001)
local b1 = round(betaEC[1,2],.001)
local b2 = round(betaEC[1,3],.001)
local b3 = round(betaEC[1,4],.001)
local b4 = round(betaEC[1,5],.001)

mat EC = (1 \ . \ `b1' \ `se1' \ `b2'  \ `se2' \ `b3'  \ `se3' \ `b4' \ . )

** Display cointegrating equation:
esttab matrix(EC), nogaps varlabels(r1 "Integration" r2 "." r3 "Core" r4 "." r5 "Periphery" r6 "." r7 "Trend" r8 "." r9 "Constant" r10 ".")
