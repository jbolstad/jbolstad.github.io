cd "/your/local/directory/Supplementary material/"
capture program drop prepdata
program define prepdata
	version 9.1
	local usevar `0'
	use "transparency.dta", clear
	replace Docarchdate = Docdate if Docarchdate < Docdate & Docdate < .
	gen lag = Docarchdate - Docdate
	replace lag = . if Doctype == 1
	gen ln_lag = ln(lag)
	gen dur = cenddate - startdate 
	gen ln_dur = ln(dur)
	encode Commission_DG, gen(PolArea) 
	encode Prop, gen(Prop1)
	encode doccatV2, gen(Doccat_num)
	gen proceduredoc = .
	replace proceduredoc = 0 if inlist(Doccat_num,1,3,4,8,14,16)
	replace proceduredoc = 1 if inlist(Doccat_num,2,5,6,7,9,10,11,12,13,15,17,18)
	tab Doctype, gen(type)
	gen restricted = 0 if Doctype < .
	replace restricted = 1 if Doctype < 3
	gen month = month(`usevar')
	gen docyear = year(`usevar')
	gen yearmonth =  ym(docyear,month)
	format yearmonth %tm
	gen time = .
	gen tr = .
	gen AccessRegulation = 0 if `usevar' < .
	replace AccessRegulation = 1 if `usevar' < . & `usevar' > td(3,12,2001)
	gen Enlargement2004 = 0 if `usevar' < .
	replace Enlargement2004 = 1 if `usevar' < . & `usevar' > td(1,5,2004)
	gen Enlargement2007 = 0 if `usevar' < .
	replace Enlargement2007 = 1 if `usevar' < . & `usevar' > td(1,1,2007)
end

********** Create alternative datasets:
prepdata Docdate
drop if proceduredoc != 1
save "edited.dta", replace
prepdata Docdate
drop if proceduredoc != 0
save "edited_outcome.dta", replace
prepdata Docarchdate
save "editedarch.dta", replace
********** Collapse main data:
use "edited.dta", clear
collapse (mean) lag ln_lag type1 type2 type3 restricted month time tr AccessRegulation Enlargement2004 Enlargement2007 ln_dur dur (count) n = lag volume = Doctype (sum) ntype1 = type1 ntype2 = type2 ntype3 = type3, by(yearmonth) 
tsset yearmonth, monthly
save "monthly.dta", replace
********** Collapse outcome data:
use "edited_outcome.dta", clear
collapse (mean) lag ln_lag type1 type2 type3 restricted month time tr AccessRegulation Enlargement2004 Enlargement2007 ln_dur dur (count) n = lag volume = Doctype (sum) ntype1 = type1 ntype2 = type2 ntype3 = type3, by(yearmonth) 
tsset yearmonth, monthly
save "monthly_outcome.dta", replace
********** Add data based on archival date:
use "editedarch.dta", clear
local prefix "_a"
collapse (mean) lag`prefix' = lag ln_lag`prefix' = ln_lag type1`prefix' = type1 type2`prefix' = type2 type3`prefix' = type3 restricted`prefix' = restricted (count) n`prefix' = ln_lag volume`prefix' = Doctype (sum) ntype1`prefix' = type1 ntype2`prefix' = type2 ntype3`prefix' = type3, by(yearmonth) 
tsset yearmonth, monthly
save "monthlyarch.dta", replace
********** Merge the alternative datasets:
use "monthly.dta", clear
merge 1:1 yearmonth using "monthlyarch.dta"
save "monthly.dta", replace
