* cd "/your/local/directory/Supplementary material/"
set more off

* 2004 Enlargement, 1 May 2004:
global tr = ym(2004,5)
global case "Enlargement2004"
global dv "lag"
do caseanalysis_t.do
global dv "dur"
do caseanalysis_t.do
global dv "type1"
do caseanalysis_t.do
global dv "type2"
do caseanalysis_t.do
global dv "lag"
do caseanalysis_placebo.do

* 2007 Enlargement, 1 January 2007:
global tr = ym(2007,1)
global case "Enlargement2007"
global dv "lag"
do caseanalysis_t.do
global dv "type1"
do caseanalysis_t.do
global dv "type2"
do caseanalysis_t.do

********* 
global lb = ym(1999,1)
global ub = ym(2009,12)
global tr1a = ym(2001,6)
global tr1 = ym(2001,12)
global tr2 = ym(2004,5)
global tr3 = ym(2007,1)
** Total obs and clusters:
use "transparency.dta", clear
qui: tab Prop
di r(r)
di r(N)
********* Included obs and clusters:
use "edited.dta", clear
count if yearmonth >= $lb & yearmonth <= $ub
sum lag type1 type2 restricted if yearmonth >= $lb & yearmonth <= $ub
qui: tab Prop1 if yearmonth >= $lb & yearmonth <= $ub
di r(r)
di r(N)

****** Figures:
use "monthly.dta", clear
label variable lag "Lag of Release"
label variable type1 "Non-Release"
label variable type2 "Partial Release"
label variable n "Observations per Month"
sum n 
local nmax = r(max) * 5
local nmaxlab2 = round((r(max)+100),100)
local nmaxlab1 = `nmaxlab2' / 2

twoway  (tsline type1) (tsline type2)  ///
	if yearmonth >= $lb & yearmonth <= $ub,name(longseriestype, replace) ///
		xmtick($lb(24)$ub) xlabel($lb(24)$ub)  ///
		 xline($tr1a $tr1 $tr2 $tr3, lpattern(dash)) ///
		xtitle("") legend(region(lwidth(none))) ytitle("Share of Documents") scale(.95) 
graph export longseriestype.pdf, replace
graph export longseriestype.eps, replace

twoway (tsline lag)  ///
	if yearmonth >= $lb & yearmonth <= $ub,name(longserieslag, replace) ///
		xmtick($lb(24)$ub) xlabel($lb(24)$ub) ///
		 xline($tr1a $tr1 $tr2 $tr3, lpattern(dash)) ///
		 xtitle("") legend(region(lwidth(none))) ///
		 ytitle("Number of Days") scale(.95) 
graph export longserieslag.pdf, replace
graph export longserieslag.eps, replace

****** Figures based on archival dates:
label variable lag_a "Lag of Release (endd.)"
label variable type1_a "Non-Release (endd.)"
label variable type2_a "Partial Release (endd.)"
label variable n_a "Observations per Month (endd.)"
sum n 
local nmax = r(max) * 5
local nmaxlab2 = round((r(max)+100),100)
local nmaxlab1 = `nmaxlab2' / 2

twoway (tsline type1_a) (tsline type2_a)  ///
	if yearmonth >= $lb & yearmonth <= $ub,name(longseriestype2, replace) ///
		xmtick($lb(24)$ub) xlabel($lb(24)$ub)  ///
		 xline($tr1a $tr1 $tr2 $tr3, lpattern(dash)) ///
		xtitle("") legend(region(lwidth(none))) ytitle("Share of Documents") scale(.95) 
graph export longseriestype2.pdf, replace
graph export longseriestype2.eps, replace
		
twoway  (tsline lag_a) (spike n_a yearmonth, yaxis(2)) ///
	if yearmonth >= $lb & yearmonth <= $ub,name(longserieslag2, replace) ///
		xmtick($lb(24)$ub) xlabel($lb(24)$ub) ///
		yscale(range(0 `nmax') axis(2)) xline($tr1a $tr1 $tr2 $tr3, lpattern(dash)) ///
		ylabel(0 `nmaxlab1' `nmaxlab2', axis(2)) xtitle("") legend(region(lwidth(none))) ///
		 ytitle("Number of Days") scale(.95) 
graph export longserieslag2.pdf, replace
graph export longserieslag2.eps, replace

******* Simple descriptives for different years:
use "edited.dta", clear
sum lag if yearmonth >= ym(2000,1) & yearmonth <= ym(2000,12)  
sum lag if yearmonth >= ym(2002,1) & yearmonth <= ym(2002,12)  
sum lag if yearmonth >= ym(2009,1) & yearmonth <= ym(2009,12)  

sum type1 if yearmonth >= ym(2000,1) & yearmonth <= ym(2000,12)  
sum type1 if yearmonth >= ym(2002,1) & yearmonth <= ym(2002,12)  
sum type1 if yearmonth >= ym(2009,1) & yearmonth <= ym(2009,12) 

****** Cross-tabulation of the dependent variables:
use "edited.dta", clear
tabstat lag if yearmonth > ym(2003,1), by(Doctype) stat(mean n) 

*********** Regression tables:
esttab lagE4 lagE4disagg1 lagE4disagg2 lagE4disagg3  using E4lag.tex, eform(0 1 1 1) ///
	scalars(Window Constant SE pval r2 r2_a dfuller BGodfrey ARCHLM pr0 pv1) alignment(D{.}{.}{-1}) ///
	sfmt(%9.0f %9.3f) nodepvars nonumbers nogaps compress se(%9.3f) b(%9.3f) ///  
	replace label indicate("FE, Month = *month" "FE, Policy Area = *PolArea" "FE, Doc. Type = *Doccat_num") ///
	title("Impact of the 2004 enlargement on lag of release to the public" \label{tab:E4}) ///
	varlabels(tr "Enlargement" Time "Time" c.tr#c.time  "Enlargement x Time" _cons "Constant" Proc "Co-Decision" ///
	ln_dur "Length of Negotiation" amendVar "Amendment by Commission")
	
esttab type1E4 type2E4 type2E4disagg1 type2E4disagg2 type2E4disagg3 using E4release.tex, ///
	scalars(Window Constant SE pval r2 r2_a dfuller BGodfrey ARCHLM pr0 pv1) alignment(D{.}{.}{-1}) ///
	sfmt(%9.0f %9.3f) nodepvars nonumbers nogaps compress se(%9.3f) b(%9.3f) ///  
	replace label indicate("FE, Month = *month" "FE, Policy Area = *PolArea" "FE, Doc. Type = *Doccat_num") ///
	title("Impact of the 2004 enlargement on censorship of documents" \label{tab:E4}) ///
	varlabels(tr "Enlargement" Time "Time" c.tr#c.time  "Enlargement x Time" _cons "Constant" Proc "Co-Decision" ///
	ln_dur "Length of Negotiation" amendVar "Amendment by Commission")

esttab type1E7 type2E7  lagE7 lagE7disagg1 lagE7disagg2 lagE7disagg3  using E7.tex, eform(0 0 0 1 1 1) ///
	scalars(Window Constant SE pval r2 r2_a dfuller BGodfrey ARCHLM pr0 pv1) alignment(D{.}{.}{-1}) ///
	sfmt(%9.0f %9.3f) nodepvars nonumbers nogaps compress se(%9.3f) b(%9.3f) ///  
	replace label indicate("FE, Month = *month" "FE, Policy Area = *PolArea" "FE, Doc. Type = *Doccat_num") ///
	title("Impact of the 2007 enlargement on legislative transparency" \label{tab:E7}) ///
	varlabels(c.tr#c.time  "Enlargement x Time" _cons "Constant" Proc "Co-Decision" ln_dur "Length of Negotiation" ///
	amendVar "Amendment by Commission")
