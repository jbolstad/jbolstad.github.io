*********************************************************************************
if ("$dv" == "lag") {
	local dvt = "Lag of Release"
	local yttl = "Number of Days" 
}
if ("$dv" == "volume") {
	local dvt = "Legislative Volume"
}
if ("$dv" == "restricted") {
	local dvt = "Restricted Access"
}
if ("$dv" == "type1") {
	local dvt = "Non-Release"
	local yttl = "Share of Documents"
}
if ("$dv" == "type2") {
	local dvt = "Partial Release"
	local yttl = "Share of Documents"
}
if ("$dv" == "dur") {
	local dvt = "Length of Negotiation"
	local yttl = "Number of Days"
}

local window = 24

if ("$case" == "AccessRegulation") {
	local caseletter "A"
	local case "2001 Regulation"
	}
if ("$case" == "Enlargement2004") {
	local caseletter "E4"
	local case "2004 Enlargement"
	}
if ("$case" == "Enlargement2007") {
	local caseletter "E7"
	local case "2007 Enlargement"
	}
local window2 = `window' * 2
global lb = ($tr - `window')
global ub = ($tr + `window' - 1)

****** Identify optimal base categories:
use "edited.dta", clear
levelsof month if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
sum $dv if yearmonth >= $lb & yearmonth <= $ub  
local avg = r(mean)
local basemonth = 1
local best_dist = 10000
foreach i of numlist `nums' {
    qui: sum $dv if yearmonth >= $lb & yearmonth <= $ub  & month == `i'
    if `best_dist' > abs(`avg' - r(mean)) {
    	local basemonth = `i'
    	local best_dist = abs(`avg' - r(mean))
    }
}

** PolArea - group categories with no partial releases:
if ("$dv" == "type2") {
	levelsof PolArea if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
	foreach i of numlist `nums' {
		sum $dv if yearmonth >= $lb & yearmonth <= $ub & PolArea == `i' & tr != . & time != . & Proc != . & ln_dur != . & amendVar != . & month != . & Prop1 != .
		if r(mean) == 0 {
			replace PolArea = 0 if PolArea == `i'
		}
	}
	** Group closest category with 0.
	levelsof PolArea if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
	local best_dist = 10000
	foreach i of numlist `nums' {
	    qui: sum $dv if yearmonth >= $lb & yearmonth <= $ub & PolArea == `i'
	    if (`best_dist' > `avg' & `avg' > 0) {
	    	local reparea = `i'
	    }
	}
	replace PolArea = 0 if PolArea == `reparea'
}

** PolArea - best area for best basemonth:
levelsof PolArea if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
sum $dv if yearmonth >= $lb & yearmonth <= $ub & month == `basemonth' 
local avg = r(mean)
local basearea = 1
local best_dist = 10000
foreach i of numlist `nums' {
    qui: sum $dv if yearmonth >= $lb & yearmonth <= $ub & PolArea == `i' & month == `basemonth'
    if `best_dist' > abs(`avg' - r(mean)) {
    	local basearea = `i'
    	local best_dist = abs(`avg' - r(mean))
    }
}

**
use "monthly.dta", clear
replace time = yearmonth if yearmonth >= $lb & yearmonth <= $ub
replace time = (time - $tr)
replace tr = $case
***** Aggregate time-series model for diagnostics:
qui: reg $dv c.tr##c.time  ib1.month if yearmonth >= $lb & yearmonth <= $ub
estat bgodfrey, lags(1/2)
mat bgodf = r(p)
local bgod = bgodf[1,1]
estat archlm, lags(1/2)
mat archlm = r(p)
local arch = archlm[1,1]
estat hettest
local hett = r(p)
predict tempres if yearmonth >= $lb & yearmonth <= $ub, res
dfuller tempres
local dfull = r(p)
***** Time-series plot:
qui: reg $dv c.tr##c.time if yearmonth >= $lb & yearmonth <= $ub [pw=n]
mat coefs =  e(b)
mat list coefs
gen linpred_pre = _b[_cons] + (coefs[1,2] * time) if yearmonth <= $tr
gen linpred_ct = _b[_cons] + (coefs[1,2] * time) if yearmonth >= $tr
gen linpred_post = _b[_cons] + (coefs[1,2] * time) + (coefs[1,3] * time) + (coefs[1,1]) if yearmonth >= $tr
label variable tr "Enlargement"
label variable time "Time"
label variable $dv "`dvt'"
label variable linpred_ct "Counterfactual"
label variable linpred_post "Fitted Trend, Post"
label variable linpred_pre "Fitted Trend, Pre"
label variable n "Observations per Month"

sum n 
local nmax = r(max) * 5
local nmaxlab2 = round((r(max)+100),100)
local nmaxlab1 = `nmaxlab2' / 2

sum $dv if yearmonth >= $lb & yearmonth <= $ub
local dvmin = round(r(min),100) - 100
local dvmax = round(r(max),100)

if ("$dv" == "dur" | "$dv" == "lag") {
	twoway (tsline $dv) (spike n yearmonth, yaxis(2)) (tsline linpred_pre, lcolor(black) lpattern(solid)) (tsline linpred_post, lcolor(black) lpattern(longdash)) (tsline linpred_ct, lpattern(shortdash)) ///
	if yearmonth >= $lb & yearmonth <= $ub, xline($tr, lpattern(dash)) name(`caseletter'$dv, replace) ///
		xmtick($lb(12)$ub) xlabel($lb(12)$ub)  ///
		yscale(range(0 `nmax') axis(2)) yscale(range(`dvmin' `dvmax') axis(1)) ytitle("`yttl'") ///
		ylabel(0 `nmaxlab1' `nmaxlab2', axis(2)) ylabel(`dvmin' (100) `dvmax', axis(1)) xtitle("") legend(region(lwidth(none))) scale(.95) 
}
else {
	twoway (tsline $dv) (spike n yearmonth, yaxis(2)) (tsline linpred_pre, lcolor(black) lpattern(solid)) (tsline linpred_post, lcolor(black) lpattern(longdash)) (tsline linpred_ct, lpattern(shortdash)) ///
	if yearmonth >= $lb & yearmonth <= $ub, xline($tr, lpattern(dash)) name(`caseletter'$dv, replace) ///
		xmtick($lb(12)$ub) xlabel($lb(12)$ub)  ///
		yscale(range(0 `nmax') axis(2)) ytitle("`yttl'") ///
		ylabel(0 `nmaxlab1' `nmaxlab2', axis(2)) xtitle("") legend(region(lwidth(none))) scale(.95) 
}

graph export `caseletter'$dv$letter.pdf, name(`caseletter'$dv) replace
graph export `caseletter'$dv$letter.eps, name(`caseletter'$dv) replace

**** With monthly fixed effects:
qui: reg $dv c.tr##c.time  ib1.month if yearmonth >= $lb & yearmonth <= $ub [pw=n]
**** Get constant and SE for best base-month:
local Constant = (_b[_cons] + _b[`basemonth'.month])
mat varcovar =  e(V)
mat list varcovar
local SE = sqrt(varcovar[16,16] + varcovar[(`basemonth' + 3),(`basemonth' + 3)] + (2 * varcovar[(`basemonth' + 3),16]))
local t = (`Constant' / `SE')
local pval = (2*ttail(e(df_r),abs(`t')))

estadd scalar Window `window2'
estadd scalar BGodfrey `bgod'
estadd scalar ARCHLM `arch'
estadd scalar BPagan `hett'
estadd scalar dfuller `dfull'
estadd scalar Constant `Constant'
estadd scalar SE `SE'
estadd scalar pval `pval'
estimates store $dv`caseletter'
	

************************************************************
***** Lower-level models:
if ("$dv" != "dur") {
	use "edited.dta", clear
	label variable tr "Enlargement"
	label variable time "Time"
	sum $dv if yearmonth >= $lb & yearmonth <= $ub
	replace time = yearmonth if yearmonth >= $lb & yearmonth <= $ub
	replace time = (time - $tr)
	replace tr = $case

	** PolArea - group categories with no partial releases:
	if ("$dv" == "type2") {
		levelsof PolArea if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
		foreach i of numlist `nums' {
			sum $dv if yearmonth >= $lb & yearmonth <= $ub & PolArea == `i' & tr != . & time != . & Proc != . & ln_dur != . & amendVar != . & month != . & Prop1 != .
			if r(mean) == 0 {
				replace PolArea = 0 if PolArea == `i'
			}
		}
			levelsof PolArea if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
		local best_dist = 10000
		foreach i of numlist `nums' {
			sum $dv if yearmonth >= $lb & yearmonth <= $ub & PolArea == `i' & tr != . & time != . & Proc != . & ln_dur != . & amendVar != . & month != . & Prop1 != .
			if (`best_dist' > `avg' & `avg' > 0) {
		    	local reparea = `i'
		    }
		}
		replace PolArea = 0 if PolArea == `reparea'
	}
	** Document category - group categories with no partial releases:
	if ("$dv" == "type2") {
		levelsof Doccat_num if yearmonth >= $lb & yearmonth <= $ub , local(nums) 
		foreach i of numlist `nums' {
			sum $dv if yearmonth >= $lb & yearmonth <= $ub & Doccat_num == `i' & tr != . & time != . & Proc != . & ln_dur != . & amendVar != . & month != . & Prop1 != . & PolArea != .
			if r(mean) == 0 {
				replace Doccat_num = 0 if Doccat_num == `i'
			}
		}	
		** Grouping with proposal: 
		replace Doccat_num = 13 if Doccat_num == 0
	}

	************************* Basic model with fixed effects:
	if ("$dv" == "lag") nbreg $dv c.tr##c.time ib1.month ib1.PolArea ib13.Doccat_num if yearmonth >= $lb & yearmonth <= $ub & ln_dur != . & amendVar != ., cluster(Prop1)
	else logit $dv c.tr##c.time ib1.month ib1.PolArea ib13.Doccat_num if yearmonth >= $lb & yearmonth <= $ub & ln_dur != . & amendVar != ., cluster(Prop1)
	** Calculate alternative constant:
	local Constant = (_b[_cons] + _b[`basemonth'.month])	
	mat varcovar =  e(V)
	mat list varcovar
	local monthid = rownumb(varcovar,"`basemonth'.month")
	local consid = rownumb(varcovar,"_cons")
	local SE = sqrt(varcovar[`consid',`consid'] + varcovar[`monthid',`monthid'] + (2 * varcovar[`monthid',`consid']))
	local t = (`Constant' / `SE')
	local pval = (2*ttail(e(df_r),abs(`t')))
	estadd scalar Window `window2'
	estadd scalar Constant `Constant'
	estadd scalar SE `SE'
	estadd scalar pval `pval'
	** Add margins, mostly relevant for logit: 
	margins, over(tr) at(time = 0 Doccat_num = 9 month = 6 PolArea = 13)
	mat marg = r(b) 
	estadd scalar pr0 marg[1,1]
	estadd scalar pv1 marg[1,2]
	estimates store $dv`caseletter'disagg1
	************************* Controlling for duration of negotiation:
	if ("$dv" == "lag") nbreg $dv c.tr##c.time ln_dur  ib1.month ib1.PolArea ib13.Doccat_num  if yearmonth >= $lb & yearmonth <= $ub & ln_dur != ., cluster(Prop1) 
	else logit $dv c.tr##c.time ln_dur ib1.month ib1.PolArea ib13.Doccat_num if yearmonth >= $lb & yearmonth <= $ub & ln_dur != . & amendVar != ., cluster(Prop1)
	** Calculate alternative constant:	
	local Constant = (_b[_cons] + _b[`basemonth'.month])	
	mat varcovar =  e(V)
	local areaid = rownumb(varcovar,"`basearea'.PolArea")
	local monthid = rownumb(varcovar,"`basemonth'.month")
	local consid = rownumb(varcovar,"_cons")
	local SE = sqrt(varcovar[`consid',`consid'] + varcovar[`monthid',`monthid'] + varcovar[`areaid',`areaid'] + (2 * varcovar[`monthid',`consid']) + (2 * varcovar[`consid',`areaid']) + (2 * varcovar[`areaid',`monthid']))
	local t = (`Constant' / `SE')
	local pval = (2*ttail(e(N),abs(`t')))
	estadd scalar Window `window2'
	estadd scalar Constant `Constant'
	estadd scalar SE `SE'
	estadd scalar pval `pval'
	** Add margins, mostly relevant for logit: 
	sum ln_dur if yearmonth >= $lb & yearmonth <= $ub
	local mean = r(mean)
	margins, over(tr) at(time = 0 Doccat_num = 9 month = 6 PolArea = 13 ln_dur = `mean')
	mat marg = r(b) 
	estadd scalar pr0 marg[1,1]
	estadd scalar pv1 marg[1,2]
	estimates store $dv`caseletter'disagg2
	************************* With additional controls:
	if ("$dv" == "lag") nbreg $dv c.tr##c.time Proc amendVar ln_dur ib1.month ib1.PolArea ib13.Doccat_num if yearmonth >= $lb & yearmonth <= $ub, cluster(Prop1) 
	else logit $dv c.tr##c.time Proc amendVar ln_dur ib1.month ib1.PolArea ib13.Doccat_num if yearmonth >= $lb & yearmonth <= $ub, cluster(Prop1)
	** Calculate alternative constant:
	local Constant = (_b[_cons] + _b[`basemonth'.month] + _b[`basearea'.PolArea])	
	mat varcovar =  e(V)
	local areaid = rownumb(varcovar,"`basearea'.PolArea")
	local monthid = rownumb(varcovar,"`basemonth'.month")
	local consid = rownumb(varcovar,"_cons")
	local SE = sqrt(varcovar[`consid',`consid'] + varcovar[`monthid',`monthid'] + varcovar[`areaid',`areaid'] + (2 * varcovar[`monthid',`consid']) + (2 * varcovar[`consid',`areaid']) + (2 * varcovar[`areaid',`monthid']))
	local t = (`Constant' / `SE')
	local pval = (2*ttail(e(N),abs(`t')))
	estadd scalar Window `window2'
	estadd scalar Constant `Constant'
	estadd scalar SE `SE'
	estadd scalar pval `pval'
	** Add margins, mostly relevant for logit: 
	sum ln_dur if yearmonth >= $lb & yearmonth <= $ub
	local mean = r(mean)
	margins, over(tr) at(time = 0 Doccat_num = 9 month = 6 PolArea = 13 Proc = 1 amendVar = 0 ln_dur = `mean')
	mat marg = r(b) 
	estadd scalar pr0 marg[1,1]
	estadd scalar pv1 marg[1,2]
	estimates store $dv`caseletter'disagg3
}
