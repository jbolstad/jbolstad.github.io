This folder contains replication files for the following article:
Bølstad, Jørgen, and Elias Dinas, "A Categorization Theory of Spatial Voting: How the Center Divides the Political Space", British Journal of Political Science.

All data used in this article are publicly available, and this folder mainly contains the codes that were used to analyze these data. Nevertheless, because the main dataset (European Election Study 2009) has just been released in a newer version, this folder also includes compressed copy of the old version to ensure replicability ("ees2009_v0.9_20110622.zip"). Before running the analyses, the following file should be run to prepare the data: "EES data preparation.do". Then, the following files will re-produce the results reported in the article:

- Visual inspection: "figure 3 and 4.R"
- Critical tests / Figure 6: "critical tests master file.do"
- Table 1: "table 1.do"
- Projection models / Figure 7: "figure 7.R"
- Table 2: "CHES models.do"
- Counterfactual analysis: "bootstrap counterfactual analysis.do"

For the appendix:

- Figure A.1: "extremeness tests master file.do"
- Table A.3, A.4, A.5, and A.6: "projection models.do"
- Table A.7 and A.8: First run "CIS data preparation.do", then "spanish models.do"
- Table A.9: "vote choice models.do"
- Table A.10: "PID models.do"
- Table A.11: "ANES.do" 
 