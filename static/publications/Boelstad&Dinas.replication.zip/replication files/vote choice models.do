use "EES 2009 - stacked.dta", clear

xtreg voterec lrdir lrproxabs lrsameside lropposite i.countrystack if eu15 == 1, fe cluster(id)
estimates store mod1

xtreg voterec lrproxabs lrsameside lropposite i.countrystack if eu15 == 1, fe cluster(id)
estimates store mod2

xtreg voterec lrsameside lropposite i.lrproxabs i.countrystack if eu15==1 & lrproxabs < 5 & lrproxabs > 0, fe cluster(id)
estimates store mod3

xtreg voterec c.lrproxabs##i.lrsameside c.lrproxabs##lropposite i.countrystack if eu15 == 1, fe cluster(id)
estimates store mod4

esttab mod1 mod2 mod3 mod4, ///
	rename(1.lrsameside lrsameside 1.lropposite lropposite 1.lrsameside#c.lrproxabs "Proximity~*~Same~Side" 1.lropposite#c.lrproxabs "Proximity~*~Opposite~Side") ///
	indicate(Party-Fixed Eff. = *countrystack) compress nogaps ///
	drop(*0b.lrsameside *0b.lropposite 1b.lrproxabs o.lrproxabs 2.lrproxabs 3.lrproxabs 4.lrproxabs 0b.lrsameside#co.lrproxabs 0b.lropposite#co.lrproxabs) ///
	replace label  title("Replication of Table 1 with Vote Choice as Dependent Variable") se page b(3) scalars(r2_a N N_clust) sfmt(%9.3f %9.0f )

