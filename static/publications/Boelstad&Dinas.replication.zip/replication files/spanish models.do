*** Tab A.7: 
reg ptv reldircen_01sd reldirsq_01sd, cluster(id)
estimates store mod1
reg ptv inmdircen_01sd inmdirsq_01sd, cluster(id)
estimates store mod2
reg ptv nacdircen_01sd nacdirsq_01sd, cluster(id)
estimates store mod3
reg ptv samesiderel samesiderelsq oppsiderel oppsiderelsq, cluster(id)
estimates store mod4
reg ptv samesideinm samesideinmsq oppsideinm oppsideinmsq, cluster(id)
estimates store mod5
reg ptv samesidenac samesidenacsq oppsidenac oppsidenacsq, cluster(id)
estimates store mod6

esttab mod1 mod2 mod3 mod4 mod5 mod6, compress nogaps replace label  title("Directional Effects with the Center and Status Quo as Neutral Point") se ar2 page rename( ///
	 samesiderel "Same~Side,~Center" oppsiderel "Opposite~Side,~Center"  ///
	 samesiderelsq "Same~Side,~Status~Quo" oppsiderelsq "Opposite~Side,~Status~Quo"  ///
	 samesideinm "Same~Side,~Center" oppsideinm "Opposite~Side,~Center"  ///
	 samesideinmsq "Same~Side,~Status~Quo" oppsideinmsq "Opposite~Side,~Status~Quo"  ///
	 samesidenac "Same~Side,~Center" oppsidenac "Opposite~Side,~Center"  ///
	 samesidenacsq "Same~Side,~Status~Quo" oppsidenacsq "Opposite~Side,~Status~Quo" ///
	 reldircen_01sd "Directional~Term,~Center" ///
	 reldirsq_01sd "Directional~Term,~Status~Quo" ///
	 inmdircen_01sd "Directional~Term,~Center" ///
	 inmdirsq_01sd "Directional~Term,~Status~Quo" ///
	 nacdircen_01sd "Directional~Term,~Center" ///
	 nacdirsq_01sd "Directional~Term,~Status~Quo" )  b(3) scalars(r2 N N_clust) sfmt(%9.3f %9.0f ) 

*** Tab A.8:
reg ptv samesiderel oppsiderel reldirsqcen,cluster(id)
estimates store spain2a
reg ptv samesideinm oppsideinm inmdirsqcen,cluster(id)
estimates store spain2b
reg ptv samesidenac oppsidenac nacdirsqcen,cluster(id)
estimates store spain2c
reg ptv  samesiderel oppsiderel if reldirsqcen==0 ,cluster(id)
estimates store spain2d
reg ptv  samesideinm oppsideinm if inmdirsqcen==0 ,cluster(id)
estimates store spain2e
reg ptv  samesidenac oppsidenac if nacdirsqcen==0 ,cluster(id)
estimates store spain2f

esttab spain2a spain2b spain2c spain2d spain2e spain2f, compress nogaps replace label  title("Categorization Effects Controlled for the SQ-Based Directional Term") se ar2 page rename( ///
	 samesiderel "Same~Side" oppsiderel "Opposite~Side" reldirsqcen "Directional~Term" ///
	 samesideinm "Same~Side" oppsideinm "Opposite~Side" inmdirsqcen "Directional~Term" ///
	 samesidenac "Same~Side" oppsidenac "Opposite~Side" nacdirsqcen "Directional~Term" ) scalars(r2 N N_clust) b(3) sfmt(%9.3f %9.0f ) 
