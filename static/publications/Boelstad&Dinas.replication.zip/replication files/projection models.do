use "EES 2009 - stacked.dta", clear

*** Table A.3:
reg negative lrsamesidemean lroppositemean ptv samemeanptv oppmeanptv if eu15==1, cluster(id)
estimates store mod2
xtreg negative lroppositemean ptv samemeanptv oppmeanptv if eu15==1, i(id) cluster(id) fe
estimates store mod2breg negative lrsamesidemean lroppositemean ptv samemeanptv oppmeanptv lrproxabs if eu15==1, cluster(id)
estimates store mod3
reg negative lrsamesidemean lroppositemean ptv samemeanptv oppmeanptv lrproxabs proxptv if eu15==1, cluster(id)
estimates store mod4
xtreg negative2 lroppositemean ptv samemeanptv oppmeanptv lrproxabs proxptv if eu15==1, i(id) cluster(id) fe
estimates store mod4b
esttab mod2 mod2b mod3 mod4 mod4b, se(%9.3f) b(%9.3f) nodepvars nonumbers nogaps compress se scalars(r2 N N_clust) sfmt(%9.3f %9.0f ) ///
	label  title("Models Predicting Mis-Categorization to Detect Projection Bias") rename( ///
	lroppositemean "Opposite~Side" lrsamesidemean "Same~Side"  ///
	ptv "Preference" lrproxabs  "Proximity")
	
*** Table A.4:
reg lrproxabs lrsamesidemean lroppositemean ptv samemeanptv oppmeanptv if eu15==1, cluster(id)
estimates store mod2xtreg lrproxabs lroppositemean ptv samemeanptv oppmeanptv if eu15==1, cluster(id) fe
estimates store mod2b
reg diflrmean lrsamesidemean lroppositemean ptv samemeanptv oppmeanptv if eu15==1, cluster(id)
estimates store mod3
xtreg diflrmean lroppositemean ptv samemeanptv oppmeanptv if eu15==1, i(id) cluster(id) fe
estimates store mod3b
xtreg diflrmean lroppositemean ptv samemeanptv oppmeanptv lrproxmean if eu15==1, i(id) cluster(id) fe
estimates stor mod3c

esttab mod2 mod2b mod3 mod3b mod3c, se(%9.3f) b(%9.3f) nodepvars nonumbers nogaps compress se scalars(r2_a N N_clust ) sfmt(%9.3f %9.0f ) ///
	label  title("Models Predicting Subjective Proximity to Detect Projection Bias") rename( ///
	lroppositemean "Opposite~Side" lrsamesidemean "Same~Side"  ///
	ptv "Preference" lrproxabs  "Proximity")
	
*** Table A.5:
reg negativech lrsamesidech lroppsidech ptv samechptv oppchptv if eu15==1, cluster(id)
estimates store mod1a
xtreg negativech lrsamesidech lroppsidech ptv samechptv oppchptv if eu15==1, cluster(id) fe
estimates store mod1breg negativech lrsamesidech lroppsidech ptv samechptv oppchptv lrproxch if eu15==1, cluster(id)
estimates store mod2a
xtreg negativech lrsamesidech lroppsidech ptv samechptv oppchptv lrproxch if eu15==1, cluster(id) fe
estimates store mod2b
reg negativech lrsamesidech lroppsidech ptv samechptv oppchptv c.lrproxch##c.ptv if eu15==1, cluster(id) 
estimates store mod3a
xtreg negativech lrsamesidech lroppsidech ptv samechptv oppchptv c.lrproxch##c.ptv if eu15==1, cluster(id) fe
estimates store mod3b

esttab mod1a mod1b mod2a mod2b mod3a mod3b, se(%9.3f) b(%9.3f) nodepvars nonumbers nogaps compress se scalars(r2_a N N_clust ) sfmt(%9.3f %9.0f ) ///
	label  title("Models Predicting Mis-Categorization using Chapel Hill Placements") rename( ///
	lroppositemean "Opposite~Side" lrsamesidemean "Same~Side"  ///
	ptv "Preference" lrproxabs  "Proximity")
	
*** Table A.6:
reg lrproxabs lrsamesidech lroppsidech ptv samechptv oppchptv if eu15==1, cluster(id)
estimates store mod2xtreg lrproxabs lrsamesidech lroppsidech ptv samechptv oppchptv if eu15==1, i(id) cluster(id) fe
estimates store mod2b
reg difproxlrch lrsamesidech lroppsidech ptv samechptv oppchptv if eu15==1, cluster(id)
estimates store mod3
reg difproxlrch lrsamesidech lroppsidech ptv samechptv oppchptv lrproxch if eu15==1, cluster(id) 
estimates store mod3b
xtreg difproxlrch lrsamesidech lroppsidech ptv samechptv oppchptv lrproxch if eu15==1, i(id) cluster(id) fe
estimates stor mod3c

esttab mod2 mod2b mod3 mod3b mod3c, se(%9.3f) b(%9.3f) nodepvars nonumbers nogaps compress se scalars(r2_a N N_clust ) sfmt(%9.3f %9.0f ) ///
	label  title("Models Predicting Subjective Proximity using Chapel Hill Placements") rename( ///
	lroppositemean "Opposite~Side" lrsamesidemean "Same~Side"  ///
	ptv "Preference" lrproxabs  "Proximity")

