setwd("your/local/directory/")

library("foreign")
library("mgcv")

ees <- as.data.frame(read.dta("EES 2009 - stacked.dta"))
ees.eu15 <- as.data.frame(subset(ees, complete.cases(ptv,lrsameside,stack,lropposite,lrcen) & eu15 ==1))
ees.eu15$lrsidesmean <- factor(ees.eu15$lrsidesmean)
ees.eu15$lrproxmean <- abs(ees.eu15$lrcen-ees.eu15$lrpartycenmean)
ees.eu15$diflrmean  <- ees.eu15$lrproxabs-ees.eu15$lrproxmean

### Left panel:
b <- gam(negative~s(ptv,by=lrsidesmean,k=11),data=ees.eu15)
plotData <- list()
trace(mgcv:::plot.gam, at = list(c(27, 1)), 
      quote({
        plotData <<- pd
      }))
mgcv::plot.gam(b, seWithMean = TRUE, pages = 1)
postscript("fig7left.eps", width=5, height=4.55)
par(cex=1.07)
par(mgp=c(2.5,1,0))
par(mar=c(4.1,4.1,1.1,1.1))
lims <- c(-.41,.41)
plot(plotData[[2]]$x, plotData[[2]]$fit,lty=c(3),type="n",ylim=lims, rug=F, xlab="Preference Strength", ylab="Effect on Probability of Mis-Categorization", main="", axes=F)
abline(h=0, lty=2, lwd=1, col="darkgrey")
par(new=T)
plot(plotData[[2]]$x, plotData[[2]]$fit,ylim=lims,lty=5,type="l",lwd=1.5,axes=F,xlab="",ylab="", main="")
matlines(plotData[[2]]$x, cbind(plotData[[2]]$fit + plotData[[2]]$se, 
                                plotData[[2]]$fit - plotData[[2]]$se), lty = 2, col = 1)
par(new=T)
plot(plotData[[3]]$x, plotData[[3]]$fit,ylim=lims,lty=1,type="l",lwd=1.5,axes=F,xlab="",ylab="", main="")
matlines(plotData[[3]]$x, cbind(plotData[[3]]$fit + plotData[[3]]$se, 
                                plotData[[3]]$fit - plotData[[3]]$se), lty = 2, col = 1)
axis(1)
axis(2)
legend("topright", bty="n", inset=c(-.04,-.04),xpd=T,cex=.82, pt.cex=.82, bg="white",
       c("Voter on opposite side of obj. party placement", "Voter on same side as obj. party placement"),lwd=c( 1.5,1.5),pch=c( NA,  NA),lty=c(1,5),pt.bg=c("black","white"))
dev.off()

### Right panel:
b3 <- gam(diflrmean~s(ptv,by=lrsidesmean,k=11)+lrproxmean,data=ees.eu15)
plotData <- list()
trace(mgcv:::plot.gam, at = list(c(27, 1)), 
      quote({
        plotData <<- pd
      }))
mgcv::plot.gam(b3, seWithMean = TRUE, pages = 1)
postscript("fig7right.eps", width=5, height=4.5)
par(cex=1.07)
par(mgp=c(2.5,1,0))
par(mar=c(4.1,4.1,1.1,1.1))
lims <- c(-2,2)
plot(plotData[[2]]$x, plotData[[2]]$fit,lty=c(3),type="n",ylim=lims, rug=F, xlab="Preference Strength", ylab="Effect on Overestimation of Distance to Party", main="", axes=F)
abline(h=0, lty=2, lwd=1, col="darkgrey")
par(new=T)
plot(plotData[[2]]$x, plotData[[2]]$fit,ylim=lims,lty=5,type="l",lwd=1.5,axes=F,xlab="",ylab="", main="")
matlines(plotData[[2]]$x, cbind(plotData[[2]]$fit + plotData[[2]]$se, 
                                plotData[[2]]$fit - plotData[[2]]$se), lty = 2, col = 1)
par(new=T)
plot(plotData[[3]]$x, plotData[[3]]$fit,ylim=lims,lty=1,type="l",lwd=1.5,axes=F,xlab="",ylab="", main="")
matlines(plotData[[3]]$x, cbind(plotData[[3]]$fit + plotData[[3]]$se, 
                                plotData[[3]]$fit - plotData[[3]]$se), lty = 2, col = 1)
axis(1)
axis(2)
legend("topright", bty="n", inset=c(-.04,-.04),xpd=T,cex=.82, pt.cex=.82, bg="white",
       c("Voter on opposite side of obj. party placement", "Voter on same side as obj. party placement"),lwd=c( 1.5,1.5),pch=c( NA,  NA),lty=c(1,5),pt.bg=c("black","white"))
dev.off()



