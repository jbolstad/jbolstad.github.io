setwd("your/local/directory")

library(foreign)
library(lmtest)
library(plm)
library(xtable)
library(FinTS)
library(rugarch)
library(sandwich)

suffix <- ""
## Toggle: Estimate GARCH models?
do.garch <- F
## Event data:
signals <- read.csv("signals.csv", row.names = 1)
signals$date <- as.Date(signals$date)
signals[is.na(signals)] <- ""
signals$strength[signals$strength==1] <- 0
## Excluding singular cases (as explained in the article):
drop <- which(signals$actor=="2" & signals$strength=="2" & signals$sign=="0")
signals <- signals[-drop,]
drop <- which(signals$actor=="0" & signals$strength=="2" & signals$sign=="0")
signals <- signals[-drop,]
drop <- which(signals$actor=="0" & signals$strength=="2" & signals$sign=="2")
signals <- signals[-drop,]
########################################################################
#### Further tests regarding Draghi's speech, 2012-07-26:
# Drop signals after the speech:
#signals <- signals[signals$date < "2012-07-26",]
# Drop the speech itself:
#signals <- signals[signals$date != "2012-07-26",]
########################################################################
signals$type <- with(signals, interaction(strength, actor,  sign ))
types <- tapply(as.numeric(signals$type),signals$type,mean)
types <- types[!is.na(types)]
types.sign <- tapply(as.numeric(signals$sign),signals$type,mean)
types.actor <- tapply(as.numeric(signals$actor),signals$type,mean)
types.actor <- types.actor[!is.na(types.sign)]
types.strength <- tapply(as.numeric(signals$strength),signals$type,mean)
types.strength <- types.strength[!is.na(types.sign)]
types.sign <- types.sign[!is.na(types.sign)]
## Types labels:
types.lab <- vector()
for (lab in 1:length(types)) {
  if (types.sign[lab] == 0) {sign.i <- "Neg"}
  if (types.sign[lab] == 1) {sign.i <- "Pos"}
  if (types.sign[lab] == 2) {sign.i <- "Mix"}
  if (is.na(types.strength[lab])) {strength.i <- "Int"}
    else {  
      if (types.strength[lab] == 0) {strength.i <- "Sta"}
      if (types.strength[lab] == 2) {strength.i <- "Dec"}}
  if (types.actor[lab] == 0) {actor.i <- "Ger"}
  if (types.actor[lab] == 1) {actor.i <- "EU"}
  if (types.actor[lab] == 2) {actor.i <- "ECB"}
  if (types.actor[lab] == 3) {actor.i <- "RA"}
  
  lab.i <- paste(strength.i,actor.i,sign.i,sep=".")
  types.lab <- c(types.lab, lab.i)
}
## Bond yield data:
spreads <- read.csv("spreads.csv", row.names = 1)
spreads[,1] <- as.Date(spreads[,1])
n.c <- NCOL(spreads)-1
d.log.spreads <- (log(spreads[2:NROW(spreads),2:(n.c+1)]) - log(spreads[1:(NROW(spreads)-1),2:(n.c+1)]))
d.log.spreads <- cbind(spreads[2:NROW(spreads),1],d.log.spreads)
colnames(d.log.spreads)[1] <- "date"
d.spreads <- d.log.spreads
d.spreads.sub <- as.matrix(d.spreads[d.spreads$date >= "2009-01-01" & d.spreads$date <= "2012-12-31",2:(n.c+1)])
dates.sub <- d.spreads[d.spreads$date >= "2009-01-01" & d.spreads$date <= "2012-12-31",1]
## Lagged spreads (we have earlier data, so there is no need to lose any observations):
d.spreads.sub.l1 <- as.matrix(d.spreads[(which(d.spreads$date == "2009-01-01")-1):(which(d.spreads$date == "2012-12-31")-1),2:(n.c+1)])
d.spreads.sub.l2 <- as.matrix(d.spreads[(which(d.spreads$date == "2009-01-01")-2):(which(d.spreads$date == "2012-12-31")-2),2:(n.c+1)])
d.spreads.sub.l3 <- as.matrix(d.spreads[(which(d.spreads$date == "2009-01-01")-3):(which(d.spreads$date == "2012-12-31")-3),2:(n.c+1)])
d.spreads.sub.l4 <- as.matrix(d.spreads[(which(d.spreads$date == "2009-01-01")-4):(which(d.spreads$date == "2012-12-31")-4),2:(n.c+1)])
## Move events to first subsequent trading day:
while (length(signals$date[!(signals$date %in% dates.sub)]) > 0) {
  signals$date[!(signals$date %in% dates.sub)] <- signals$date[!(signals$date %in% dates.sub)] + 1
}
## Create event matrix:
events <- matrix(0,nrow=NROW(d.spreads.sub),ncol=length(types))
for (i in 1:length(types)) {
  events[dates.sub %in% signals$date[signals$type == dimnames(types)[[1]][i]],i] <- 1
}
colnames(events) <- dimnames(types)[[1]]
empty <- matrix(0,ncol=length(types),nrow=2)
events.lead1 <- rbind(events[2:(NROW(d.spreads.sub)-0),1:length(types)],empty[1,])
events.l1 <- rbind(empty[1,],events[1:(NROW(d.spreads.sub)-1),1:length(types)])
events.l2 <- rbind(empty,events[1:(NROW(d.spreads.sub)-2),1:length(types)])
events.l3 <- rbind(empty,empty[1,],events[1:(NROW(d.spreads.sub)-3),1:length(types)])
## Signal year and quarter:
sign.year <- as.numeric(strftime(dates.sub,"%Y"))
sign.quarter <- quarters(dates.sub)
sign.yrqr <- interaction(as.factor(sign.year),as.factor(sign.quarter),lex.order = T)
## Stack data:
yrqr.stacked <- as.factor(c(rep(sign.yrqr,5)))
events.stacked <- rbind(events,events,events,events,events)
events.l2.stacked <- rbind(events.l2,events.l2,events.l2,events.l2,events.l2)
events.l1.stacked <- rbind(events.l1,events.l1,events.l1,events.l1,events.l1)
events.l3.stacked <- rbind(events.l3,events.l3,events.l3,events.l3,events.l3)
events.lead1.stacked <- rbind(events.lead1,events.lead1,events.lead1,events.lead1,events.lead1)

d.spreads.sub.stacked <- vector()
d.spreads.l1.stacked <- vector()
d.spreads.l2.stacked <- vector()
d.spreads.l3.stacked <- vector()
for (c in 1:n.c) {
  d.spreads.sub.stacked <- rbind(d.spreads.sub.stacked,cbind(d.spreads.sub[,c+0],cbind(rep(c,NROW(d.spreads.sub)))))
  d.spreads.l1.stacked <- rbind(d.spreads.l1.stacked,cbind(d.spreads.sub.l1[,c+0]))
  d.spreads.l2.stacked <- rbind(d.spreads.l2.stacked,cbind(d.spreads.sub.l2[,c+0]))
  d.spreads.l3.stacked <- rbind(d.spreads.l3.stacked,cbind(d.spreads.sub.l3[,c+0]))
}
## Models:
time.stacked <- rep(1:NROW(dates.sub),n.c)
dat <- as.data.frame(cbind(d.spreads.sub.stacked[,1],events.stacked,events.l1.stacked,as.factor(yrqr.stacked),d.spreads.l1.stacked,d.spreads.l2.stacked,as.factor(d.spreads.sub.stacked[,2]),time.stacked))
rownames(dat) <- 1:NROW(dat)
colnames(dat) <- paste("v",1:NCOL(dat),sep="")
ind <- c(colnames(dat)[NCOL(dat)-1],colnames(dat)[NCOL(dat)])

mod.plm.pool <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + as.factor(yrqr.stacked),model = c("pooling"),data=dat,index=ind)
mod.plm.pool.l1 <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + as.factor(yrqr.stacked) + d.spreads.l1.stacked,model = c("pooling"),data=dat,index=ind)
mod.plm.pool.l2 <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + as.factor(yrqr.stacked) + d.spreads.l1.stacked + d.spreads.l2.stacked,model = c("pooling"),data=dat,index=ind)
mod.plm.pool.l3 <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + as.factor(yrqr.stacked) + d.spreads.l1.stacked + d.spreads.l2.stacked + d.spreads.l3.stacked,model = c("pooling"),data=dat,index=ind)
########################################################################
## Main results:
mod.to.report <- mod.plm.pool.l2

est.temp <- summary(mod.to.report)$coefficients[,1]
avail.0 <- !is.na(mod.to.report$coefficients)[2:(length(types)+1)]
avail.1 <- !is.na(mod.to.report$coefficients)[1+(1+(length(types))):((length(types))*2)]
avail <- avail.0 & avail.1  
types.a <- types[avail]
est.temp <- est.temp[2:(((length(types.a)-0)*2)+1)]
est <- est.temp[1:(length(types.a)-0)] + est.temp[(1+(length(types.a)-0)):((length(types.a)-0)*2)]

report <- !is.na(types.actor) & !is.na(types.strength) & types.actor != 3 & types.sign != 3
report.a <- report[avail]

vcov.mat <- vcovHC(mod.to.report, method="white1", type="HC0")
vcov.mat <- vcov.mat[2:(((length(types.a)-0)*2)+1),2:(((length(types.a)-0)*2)+1)]

vc.2 <- matrix(NA,nrow=(length(types.a)),ncol=6)
for (typ in 1: (length(types.a))) {
  for (t in (1:2)) {
    vc.2[typ,t] <- vcov.mat[typ+((t-1)*length(types.a)),typ+((t-1)*length(types.a))]
  }
  vc.2[typ,4] <- vcov.mat[typ+(0*length(types.a)),typ+(1*length(types.a))]
}
se <- sqrt(vc.2[,1] + vc.2[,2] + (2 * vc.2[,4]))
est <- est[report.a]
se <- se[report.a]
types.a <- types.a[report.a]
t.ind <- 1:(length(types.a))
########################################################################
## Main plot:
confidence <- .95
t <-  qt((1-(1-confidence)/2), df = 1000)
lim <- .155
i <- order(types.sign[avail][report.a],types.actor[avail][report.a])
i <- rev(i)
est <- est[i]
se <- se[i]
ci.hi <- est + (se * t)
ci.lo <- est - (se * t)
signif <- (ci.hi < 0 | ci.lo > 0)

use.0 <- types.sign[avail][report.a][i] == 0
use.1 <- types.sign[avail][report.a][i] == 1
use.2 <- types.sign[avail][report.a][i] == 2

add.neg <- (6 - length(t.ind[use.0])) / 5
add.mix <- (6 - length(t.ind[use.2])) / 5

lo.margin <- .09
hi0 <- 1
lo0 <- 1 - ((1-lo.margin)*(length(t.ind[use.0])+add.neg)/(length(t.ind)+add.neg+add.mix))
hi1 <- lo0
lo1 <- hi1 - ((1-lo.margin)*length(t.ind[use.1])/(length(t.ind)+add.neg+add.mix))
hi2 <- lo1 
lo2 <- 0

act.labs <- c("Germany","EU","ECB")
act.labs.2 <- c("Ger.","EU","ECB")
postscript(paste("figure2", suffix, ".eps", sep=""),width=7,height=8)
#pdf(paste("figure2", suffix, ".pdf", sep=""),width=7,height=8)
par(mgp=c(2.5,1,0))
par(mar=c(.6,3.1,2.1,3.1))
## Plot 1: 
par(fig=c(0,1,lo0,hi0))
use <- types.sign[avail][report.a][i] == 0

m.ns <- types.strength[avail][report.a][i][use] == 1 & !signif[use]
m.s <- types.strength[avail][report.a][i][use] == 1 & signif[use]
w.ns <- types.strength[avail][report.a][i][use] == 0 & !signif[use]
w.s <- types.strength[avail][report.a][i][use] == 0 & signif[use]
s.ns <- types.strength[avail][report.a][i][use] == 2 & !signif[use]
s.s <- types.strength[avail][report.a][i][use] == 2 & signif[use]

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig <- use & signif
insig <- use & !signif
t.ind.t <- t.ind

plot(est[use][m.ns],t.ind.t[use][m.ns],ylim=c(min(t.ind.t[use])-.35,max(t.ind.t[use])+.35),type="n", axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Negative Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo[sig],t.ind.t[sig],ci.hi[sig],t.ind.t[sig],angle=90,code=3,length=0)
arrows(ci.lo[insig],t.ind.t[insig],ci.hi[insig],t.ind.t[insig],angle=90,code=3,length=0,col="gray60")
points(est[use][w.ns],t.ind.t[use][w.ns],pch=16,col="gray60",cex=.65)
points(est[use][s.ns],t.ind.t[use][s.ns],pch=16,col="gray60",cex=1.0)
points(est[use][w.s],t.ind.t[use][w.s],pch=16,cex=.65)
points(est[use][s.s],t.ind.t[use][s.s],pch=16,cex=1.0)
axis(2, at=y.lab, labels=act.labs.2, las = 0)
lines.at <- (min(t.ind.t[use]) + cumsum(rev(table(types.actor[avail][report][i][use])))[1:2] + .5 - 1)
abline(h=lines.at,lty=3)
legend("topright",cex=.75, bg="white",bty="o", inset=c(-.06,.00),xpd=T,box.col="black",
       c("Statement (significant)","Decision (significant)","Statement (insignificant)","Decision (insignificant)"),
       pch=c( 16,16,16,16),col=c("black","black","gray60","gray60"),pt.cex=c(.65,1,.65,1))
## Plot 2:
par(mar=c(.6,3.1,2.1,3.1))
par(fig=c(0,1,lo1,hi1), new=TRUE)
use <- types.sign[avail][report.a][i] == 1

m.ns <- types.strength[avail][report.a][i][use] == 1 & !signif[use]
m.s <- types.strength[avail][report.a][i][use] == 1 & signif[use]
w.ns <- types.strength[avail][report.a][i][use] == 0 & !signif[use]
w.s <- types.strength[avail][report.a][i][use] == 0 & signif[use]
s.ns <- types.strength[avail][report.a][i][use] == 2 & !signif[use]
s.s <- types.strength[avail][report.a][i][use] == 2 & signif[use]

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig <- use & signif
insig <- use & !signif

plot(est[use][m.ns],t.ind[use][m.ns],ylim=c(min(t.ind[use])-.35,max(t.ind[use])+.35),axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Positive Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo[sig],t.ind[sig],ci.hi[sig],t.ind[sig],angle=90,code=3,length=0)
arrows(ci.lo[insig],t.ind[insig],ci.hi[insig],t.ind[insig],angle=90,code=3,length=0,col="gray60")
points(est[use][w.ns],t.ind[use][w.ns],pch=16,col="gray60",cex=.65)
points(est[use][s.ns],t.ind[use][s.ns],pch=16,col="gray60",cex=1.0)
points(est[use][w.s],t.ind[use][w.s],pch=16,cex=.65)
points(est[use][m.s],t.ind[use][m.s],pch=16)
points(est[use][s.s],t.ind[use][s.s],pch=16,cex=1.0)
axis(2, at=y.lab, labels=act.labs, las = 0)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)
### Plot 3:
par(mar=c(4.1,3.1,2.1,3.1))
par(fig=c(0,1,lo2,hi2), new=TRUE)
use <- types.sign[avail][report.a][i] == 2

m.ns <- types.strength[avail][report.a][i][use] == 1 & !signif[use]
m.s <- types.strength[avail][report.a][i][use] == 1 & signif[use]
w.ns <- types.strength[avail][report.a][i][use] == 0 & !signif[use]
w.s <- types.strength[avail][report.a][i][use] == 0 & signif[use]
s.ns <- types.strength[avail][report.a][i][use] == 2 & !signif[use]
s.s <- types.strength[avail][report.a][i][use] == 2 & signif[use]

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig <- use & signif
insig <- use & !signif

plot(est[use][m.ns],t.ind[use][m.ns],ylim=c(min(t.ind[use])-.35,max(t.ind[use])+.35),axes=FALSE,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Mixed Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo[sig],t.ind[sig],ci.hi[sig],t.ind[sig],angle=90,code=3,length=0)
arrows(ci.lo[insig],t.ind[insig],ci.hi[insig],t.ind[insig],angle=90,code=3,length=0,col="gray60")
points(est[use][w.ns],t.ind[use][w.ns],pch=16,col="gray60",cex=.65)
points(est[use][s.ns],t.ind[use][s.ns],pch=16,col="gray60",cex=1.0)
points(est[use][w.s],t.ind[use][w.s],pch=16,cex=.65)
points(est[use][m.s],t.ind[use][m.s],pch=16)
points(est[use][s.s],t.ind[use][s.s],pch=16,cex=1.0)
axis(2, at=y.lab, labels=act.labs.2, las = 0)
mtext("Cumulative Effect, Day 0-1, Log-differenced Spreads",side=1,line=2.5)
axis(1, labels=T)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)
###
dev.off()
########################################################################
## Save full table of results:
results.raw <- summary(mod.to.report)$coefficients
HC.se.raw <- sqrt(diag(HC.vcov.mat))
results.raw[,2] <- HC.se.raw
results.raw[,3] <- (results.raw[,1]/results.raw[,2])
results.raw[,4] <- (pt(-abs(results.raw[,3]),df=5000)*2)

pbsytest(mod.plm.pool,test="ar")
pbsytest(mod.plm.pool.l1,test="ar")
pbsytest(mod.plm.pool.l2,test="ar")

BSEY.AR.p <- pbsytest(mod.to.report,test="ar")$p.value

results.raw.r <- results.raw
results.raw.r[,1:2] <- formatC(round(results.raw[,1:2],digits=3),format='f',digits=3)
results.stars <- results.raw.r
for (i in 1:NROW(results.raw)) {
  if (results.raw[i,4] < .1) {results.stars[i,1] <- paste(results.raw.r[i,1],"*ones",sep="")}
  if (results.raw[i,4] < .05) {results.stars[i,1] <- paste(results.raw.r[i,1],"*twos",sep="")}
  if (results.raw[i,4] < .01) {results.stars[i,1] <- paste(results.raw.r[i,1],"*threes",sep="")}
}

col1 <-  results.stars[-((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2]
empty <- matrix("",ncol=2,nrow=(NROW(results.stars)-1-((length(types[avail])*2))))
col2 <- rbind(rbind(rep("",2)),results.stars[((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2],empty)
additional.stats <- rbind(cbind(formatC(round(summary(mod.to.report)$r.squared[2],digits=3),format='f',digits=3),rbind(rep("",3))),
                          cbind(NROW(d.spreads.sub.stacked),rbind(rep("",3))),
                          cbind(formatC(round(BSEY.AR.p,digits=3),format='f',digits=3),rbind(rep("",3))) 
                          )

summary(mod.to.report)$r.squared[2]
results.out <- cbind(col1,col2)
results.out <- rbind(results.out,additional.stats)
rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],"Yl1","Yl2","R2, adj.","N","Bera-SE-Yoon")
write.csv(results.out,file=paste("mainmod", suffix, ".csv" ,sep=""))
xtable(results.out)
########################################################################
## Robustness check using different windows:
mod.plm.pool.l2.m11 <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + events.lead1.stacked + as.factor(yrqr.stacked) + d.spreads.l1.stacked + d.spreads.l2.stacked,model = c("pooling"),data=dat,index=ind)
mod.plm.pool.l2.02 <- plm(d.spreads.sub.stacked[,1] ~ events.stacked + events.l1.stacked + events.l2.stacked + as.factor(yrqr.stacked) + d.spreads.l1.stacked + d.spreads.l2.stacked,model = c("pooling"),data=dat,index=ind)

BSEY.AR.m11.p <- pbsytest(mod.plm.pool.l2.m11,test="ar")$p.value
BSEY.AR.02.p <- pbsytest(mod.plm.pool.l2.02,test="ar")$p.value

est.temp.m11 <- summary(mod.plm.pool.l2.m11)$coefficients[,1]
avail.0 <- !is.na(mod.plm.pool.l2.m11$coefficients)[2:(length(types)+1)]
avail.1 <- !is.na(mod.plm.pool.l2.m11$coefficients)[1+(1+(length(types))):((length(types))*2)]
avail <- avail.0 & avail.1  
types.a <- types[avail]
est.temp.m11 <- est.temp.m11[2:(((length(types.a)-0)*3)+1)]
est.m11 <- est.temp.m11[1:(length(types.a)-0)] + est.temp.m11[(1+(length(types.a)-0)):((length(types.a)-0)*2)] + est.temp.m11[(1+(length(types.a)-0)*2):((length(types.a)-0)*3)]

est.temp.02 <- summary(mod.plm.pool.l2.02)$coefficients[,1]
est.temp.02 <- est.temp.02[2:(((length(types.a)-0)*3)+1)]
est.02 <- est.temp.02[1:(length(types.a)-0)] + est.temp.02[(1+(length(types.a)-0)):((length(types.a)-0)*2)] + est.temp.02[(1+(length(types.a)-0)*2):((length(types.a)-0)*3)]

report <- !is.na(types.actor) & !is.na(types.strength) & types.actor != 3 & types.sign != 3
report.a <- report[avail]

vcov.mat.m11 <- vcov(mod.plm.pool.l2.m11)
HC.vcov.mat.m11 <- vcovHC(mod.plm.pool.l2.m11, method="white1", type="HC0")
vcov.mat.m11 <- HC.vcov.mat.m11
vcov.mat.m11 <- vcov.mat.m11[2:(((length(types.a)-0)*3)+1),2:(((length(types.a)-0)*3)+1)]

vcov.mat.02 <- vcov(mod.plm.pool.l2.02)
HC.vcov.mat.02 <- vcovHC(mod.plm.pool.l2.02, method="white1", type="HC0")
vcov.mat.02 <- HC.vcov.mat.02
vcov.mat.02 <- vcov.mat.02[2:(((length(types.a)-0)*3)+1),2:(((length(types.a)-0)*3)+1)]

vc.2.m11 <- matrix(NA,nrow=(length(types.a)),ncol=6)
for (typ in 1: (length(types.a))) {
  for (t in (1:3)) {
    vc.2.m11[typ,t] <- vcov.mat.m11[typ+((t-1)*length(types.a)),typ+((t-1)*length(types.a))]
  }
  vc.2.m11[typ,4] <- vcov.mat.m11[typ+(0*length(types.a)),typ+(1*length(types.a))]
  vc.2.m11[typ,5] <- vcov.mat.m11[typ+(0*length(types.a)),typ+(2*length(types.a))]
  vc.2.m11[typ,6] <- vcov.mat.m11[typ+(1*length(types.a)),typ+(2*length(types.a))]
}

vc.2.02 <- matrix(NA,nrow=(length(types.a)),ncol=6)
for (typ in 1: (length(types.a))) {
  for (t in (1:3)) {
    vc.2.02[typ,t] <- vcov.mat.02[typ+((t-1)*length(types.a)),typ+((t-1)*length(types.a))]
  }
  vc.2.02[typ,4] <- vcov.mat.02[typ+(0*length(types.a)),typ+(1*length(types.a))]
  vc.2.02[typ,5] <- vcov.mat.02[typ+(0*length(types.a)),typ+(2*length(types.a))]
  vc.2.02[typ,6] <- vcov.mat.02[typ+(1*length(types.a)),typ+(2*length(types.a))]
}

se.m11 <- sqrt(vc.2.m11[,1] + vc.2.m11[,2] + vc.2.m11[,3] + (2 * vc.2.m11[,4]) + (2 * vc.2.m11[,5]) + (2 * vc.2.m11[,6]))
se.02 <- sqrt(vc.2.02[,1] + vc.2.02[,2] + vc.2.02[,3] + (2 * vc.2.02[,4]) + (2 * vc.2.02[,5]) + (2 * vc.2.02[,6]))
########################################################################
## Export 2 full tables of robustness results:
## 1: [-1,1]-window:
results.raw <- summary(mod.plm.pool.l2.m11)$coefficients
HC.se.raw <- sqrt(diag(HC.vcov.mat.m11))
results.raw[,2] <- HC.se.raw
results.raw[,3] <- (results.raw[,1]/results.raw[,2])
results.raw[,4] <- (pt(-abs(results.raw[,3]),df=5000)*2)

results.raw.r <- results.raw
results.raw.r[,1:2] <- formatC(round(results.raw[,1:2],digits=3),format='f',digits=3)
results.stars <- results.raw.r
for (i in 1:NROW(results.raw)) {
  if (results.raw[i,4] < .1) {results.stars[i,1] <- paste(results.raw.r[i,1],"*ones",sep="")}
  if (results.raw[i,4] < .05) {results.stars[i,1] <- paste(results.raw.r[i,1],"*twos",sep="")}
  if (results.raw[i,4] < .01) {results.stars[i,1] <- paste(results.raw.r[i,1],"*threes",sep="")}
}

col2 <-  results.stars[-((length(types[avail])+1+1):((length(types[avail])*3)+1)),1:2]
empty <- matrix("",ncol=2,nrow=(NROW(results.stars)-1-((length(types[avail])*3))))
col1 <- rbind(rbind(rep("",2)),results.stars[(((length(types[avail])*2)+1+1):((length(types[avail])*3)+1)),1:2],empty)
col3 <- rbind(rbind(rep("",2)),results.stars[((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2],empty)
additional.stats <- rbind(cbind(formatC(round(summary(mod.plm.pool.l2.m11)$r.squared[2],digits=3),format='f',digits=3),rbind(rep("",5))),
                          cbind(NROW(d.spreads.sub.stacked),rbind(rep("",5))),
                          cbind(formatC(round(BSEY.AR.m11.p,digits=3),format='f',digits=3),rbind(rep("",5))))
results.out <- cbind(col1,col2,col3)
results.out <- rbind(results.out,additional.stats)
rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],"Yl1","Yl2","R2, adj.","N","Bera-SE-Yoon")
write.csv(results.out,file=paste("m11", suffix, ".csv" ,sep=""))
xtable(results.out)

## 2: [0,2]-window:
results.raw <- summary(mod.plm.pool.l2.02)$coefficients
HC.se.raw <- sqrt(diag(HC.vcov.mat.02))
results.raw[,2] <- HC.se.raw
results.raw[,3] <- (results.raw[,1]/results.raw[,2])
results.raw[,4] <- (pt(-abs(results.raw[,3]),df=5000)*2)

results.raw.r <- results.raw
results.raw.r[,1:2] <- formatC(round(results.raw[,1:2],digits=3),format='f',digits=3)
results.stars <- results.raw.r
for (i in 1:NROW(results.raw)) {
  if (results.raw[i,4] < .1) {results.stars[i,1] <- paste(results.raw.r[i,1],"*ones",sep="")}
  if (results.raw[i,4] < .05) {results.stars[i,1] <- paste(results.raw.r[i,1],"*twos",sep="")}
  if (results.raw[i,4] < .01) {results.stars[i,1] <- paste(results.raw.r[i,1],"*threes",sep="")}
}

col1 <-  results.stars[-((length(types[avail])+1+1):((length(types[avail])*3)+1)),1:2]
empty <- matrix("",ncol=2,nrow=(NROW(results.stars)-1-((length(types[avail])*3))))
col2 <- rbind(rbind(rep("",2)),results.stars[((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2],empty)
col3 <- rbind(rbind(rep("",2)),results.stars[(((length(types[avail])*2)+1+1):((length(types[avail])*3)+1)),1:2],empty)
additional.stats <- rbind(cbind(formatC(round(summary(mod.plm.pool.l2.02)$r.squared[2],digits=3),format='f',digits=3),rbind(rep("",5))),
                          cbind(NROW(d.spreads.sub.stacked),rbind(rep("",5))),
                          cbind(formatC(round(BSEY.AR.02.p,digits=3),format='f',digits=3),rbind(rep("",5)))
                          )
results.out <- cbind(col1,col2,col3)
results.out <- rbind(results.out,additional.stats)
rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],"Yl1","Yl2","R2, adj.","N","Bera-SE-Yoon")
write.csv(results.out,file=paste("02", suffix, ".csv" ,sep=""))
xtable(results.out)
########################################################################
## Figure 4:
est.m11 <- est.m11[report.a]
se.m11 <- se.m11[report.a]
est.02 <- est.02[report.a]
se.02 <- se.02[report.a]
types.a <- types.a[report.a]
t.ind <- 1:(length(types.a))

confidence <- .95
t <-  qt((1-(1-confidence)/2), df = 1000)
lim <- .155
i <- order(types.sign[avail][report.a],types.actor[avail][report.a])
i <- rev(i)

est.m11 <- est.m11[i]
se.m11 <- se.m11[i]
ci.hi.m11 <- est.m11 + (se.m11 * t)
ci.lo.m11 <- est.m11 - (se.m11 * t)
signif.m11 <- (ci.hi.m11 < 0 | ci.lo.m11 > 0)

est.02 <- est.02[i]
se.02 <- se.02[i]
ci.hi.02 <- est.02 + (se.02 * t)
ci.lo.02 <- est.02 - (se.02 * t)
signif.02 <- (ci.hi.02 < 0 | ci.lo.02 > 0)

use.0 <- types.sign[avail][report.a][i] == 0
use.1 <- types.sign[avail][report.a][i] == 1
use.2 <- types.sign[avail][report.a][i] == 2

hi0 <- 1
lo0 <- 1 - ((1-lo.margin)*(length(t.ind[use.0])+add.neg)/(length(t.ind)+add.neg+add.mix))
hi1 <- lo0
lo1 <- hi1 - ((1-lo.margin)*length(t.ind[use.1])/(length(t.ind)+add.neg+add.mix))
hi2 <- lo1 
lo2 <- 0

act.labs <- c("Germany","EU","ECB")
postscript(paste("figure4",".eps", sep=""),width=7,height=8)
#pdf(paste("figure4",".pdf", sep=""),width=7,height=8)
par(mgp=c(2.5,1,0))
par(mar=c(.6,3.1,2.1,3.1))
### Plot 1: 
par(fig=c(0,1,lo0,hi0))
use <- types.sign[avail][report.a][i] == 0

m.ns.m11 <- types.strength[avail][report.a][i][use] == 1 & !signif.m11[use]
m.s.m11 <- types.strength[avail][report.a][i][use] == 1 & signif.m11[use]
w.ns.m11 <- types.strength[avail][report.a][i][use] == 0 & !signif.m11[use]
w.s.m11 <- types.strength[avail][report.a][i][use] == 0 & signif.m11[use]
s.ns.m11 <- types.strength[avail][report.a][i][use] == 2 & !signif.m11[use]
s.s.m11 <- types.strength[avail][report.a][i][use] == 2 & signif.m11[use]

m.ns.02 <- types.strength[avail][report.a][i][use] == 1 & !signif.02[use]
m.s.02 <- types.strength[avail][report.a][i][use] == 1 & signif.02[use]
w.ns.02 <- types.strength[avail][report.a][i][use] == 0 & !signif.02[use]
w.s.02 <- types.strength[avail][report.a][i][use] == 0 & signif.02[use]
s.ns.02 <- types.strength[avail][report.a][i][use] == 2 & !signif.02[use]
s.s.02 <- types.strength[avail][report.a][i][use] == 2 & signif.02[use]

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig.m11 <- use & signif.m11
insig.m11 <- use & !signif.m11
sig.02 <- use & signif.02
insig.02 <- use & !signif.02
t.ind.t <- t.ind
adj.m11 <- -.15
adj.02 <- .15

plot(est.m11[use][m.ns.m11],t.ind.t[use][m.ns.m11],ylim=c(min(t.ind.t[use])-.35,max(t.ind.t[use])+.35),type="n", axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Negative Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo.m11[sig.m11],t.ind.t[sig.m11]-adj.m11,ci.hi.m11[sig.m11],t.ind.t[sig.m11]-adj.m11,angle=90,code=3,length=0)
arrows(ci.lo.m11[insig.m11],t.ind.t[insig.m11]-adj.m11,ci.hi.m11[insig.m11],t.ind.t[insig.m11]-adj.m11,angle=90,code=3,length=0,col="gray60")
points(est.m11[use][w.ns.m11],t.ind.t[use][w.ns.m11]-adj.m11,pch=17,col="gray60",cex=.65)
points(est.m11[use][s.ns.m11],t.ind.t[use][s.ns.m11]-adj.m11,pch=17,col="gray60",cex=1.0)
points(est.m11[use][w.s.m11],t.ind.t[use][w.s.m11]-adj.m11,pch=17,cex=.65)
points(est.m11[use][s.s.m11],t.ind.t[use][s.s.m11]-adj.m11,pch=17,cex=1.0)

arrows(ci.lo.02[sig.02],t.ind.t[sig.02]-adj.02,ci.hi.02[sig.02],t.ind.t[sig.02]-adj.02,angle=90,code=3,length=0)
arrows(ci.lo.02[insig.02],t.ind.t[insig.02]-adj.02,ci.hi.02[insig.02],t.ind.t[insig.02]-adj.02,angle=90,code=3,length=0,col="gray60")
points(est.02[use][w.ns.02],t.ind.t[use][w.ns.02]-adj.02,pch=15,col="gray60",cex=.65)
points(est.02[use][s.ns.02],t.ind.t[use][s.ns.02]-adj.02,pch=15,col="gray60",cex=1.0)
points(est.02[use][w.s.02],t.ind.t[use][w.s.02]-adj.02,pch=15,cex=.65)
points(est.02[use][s.s.02],t.ind.t[use][s.s.02]-adj.02,pch=15,cex=1.0)

axis(2, at=y.lab, labels=act.labs.2, las = 0)
lines.at <- (min(t.ind.t[use]) + cumsum(rev(table(types.actor[avail][report][i][use])))[1:2] + .5 - 1)
abline(h=lines.at,lty=3)
legend("topright",cex=.75, bg="white",bty="o", inset=c(-.06,.00),xpd=T,box.col="black",
       c("Statement, [-1,1]-window","Decision, [-1,1]-window","Statement, [0,2]-window","Decision, [0,2]-window","(Insign. estimates in gray)"),
       pch=c( 17,17,15,15,NA),col=c("black","black","black","black",NA),pt.cex=c(.65,1,.65,1,NA))

### Plot 2:
par(mar=c(.6,3.1,2.1,3.1))
par(fig=c(0,1,lo1,hi1), new=TRUE)
use <- types.sign[avail][report.a][i] == 1

m.ns.m11 <- types.strength[avail][report.a][i][use] == 1 & !signif.m11[use]
m.s.m11 <- types.strength[avail][report.a][i][use] == 1 & signif.m11[use]
w.ns.m11 <- types.strength[avail][report.a][i][use] == 0 & !signif.m11[use]
w.s.m11 <- types.strength[avail][report.a][i][use] == 0 & signif.m11[use]
s.ns.m11 <- types.strength[avail][report.a][i][use] == 2 & !signif.m11[use]
s.s.m11 <- types.strength[avail][report.a][i][use] == 2 & signif.m11[use]

m.ns.02 <- types.strength[avail][report.a][i][use] == 1 & !signif.02[use]
m.s.02 <- types.strength[avail][report.a][i][use] == 1 & signif.02[use]
w.ns.02 <- types.strength[avail][report.a][i][use] == 0 & !signif.02[use]
w.s.02 <- types.strength[avail][report.a][i][use] == 0 & signif.02[use]
s.ns.02 <- types.strength[avail][report.a][i][use] == 2 & !signif.02[use]
s.s.02 <- types.strength[avail][report.a][i][use] == 2 & signif.02[use]

sig.02 <- use & signif.02
insig.02 <- use & !signif.02

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig.m11 <- use & signif.m11
insig.m11 <- use & !signif.m11

plot(est.m11[use][m.ns.m11],t.ind[use][m.ns.m11],ylim=c(min(t.ind[use])-.35,max(t.ind[use])+.35),axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Positive Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo.m11[sig.m11],t.ind[sig.m11]-adj.m11,ci.hi.m11[sig.m11],t.ind[sig.m11]-adj.m11,angle=90,code=3,length=0)
arrows(ci.lo.m11[insig.m11],t.ind[insig.m11]-adj.m11,ci.hi.m11[insig.m11],t.ind[insig.m11]-adj.m11,angle=90,code=3,length=0,col="gray60")
points(est.m11[use][w.ns.m11],t.ind[use][w.ns.m11]-adj.m11,pch=17,col="gray60",cex=.65)
points(est.m11[use][s.ns.m11],t.ind[use][s.ns.m11]-adj.m11,pch=17,col="gray60",cex=1.0)
points(est.m11[use][w.s.m11],t.ind[use][w.s.m11]-adj.m11,pch=17,cex=.65)
points(est.m11[use][s.s.m11],t.ind[use][s.s.m11]-adj.m11,pch=17,cex=1.0)

arrows(ci.lo.02[sig.02],t.ind.t[sig.02]-adj.02,ci.hi.02[sig.02],t.ind.t[sig.02]-adj.02,angle=90,code=3,length=0)
arrows(ci.lo.02[insig.02],t.ind.t[insig.02]-adj.02,ci.hi.02[insig.02],t.ind.t[insig.02]-adj.02,angle=90,code=3,length=0,col="gray60")
points(est.02[use][w.ns.02],t.ind.t[use][w.ns.02]-adj.02,pch=15,col="gray60",cex=.65)
points(est.02[use][s.ns.02],t.ind.t[use][s.ns.02]-adj.02,pch=15,col="gray60",cex=1.0)
points(est.02[use][w.s.02],t.ind.t[use][w.s.02]-adj.02,pch=15,cex=.65)
points(est.02[use][s.s.02],t.ind.t[use][s.s.02]-adj.02,pch=15,cex=1.0)

axis(2, at=y.lab, labels=act.labs, las = 0)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)
### Plot 3:
par(mar=c(4.1,3.1,2.1,3.1))
par(fig=c(0,1,lo2,hi2), new=TRUE)
use <- types.sign[avail][report.a][i] == 2

m.ns.m11 <- types.strength[avail][report.a][i][use] == 1 & !signif.m11[use]
m.s.m11 <- types.strength[avail][report.a][i][use] == 1 & signif.m11[use]
w.ns.m11 <- types.strength[avail][report.a][i][use] == 0 & !signif.m11[use]
w.s.m11 <- types.strength[avail][report.a][i][use] == 0 & signif.m11[use]
s.ns.m11 <- types.strength[avail][report.a][i][use] == 2 & !signif.m11[use]
s.s.m11 <- types.strength[avail][report.a][i][use] == 2 & signif.m11[use]

m.ns.02 <- types.strength[avail][report.a][i][use] == 1 & !signif.02[use]
m.s.02 <- types.strength[avail][report.a][i][use] == 1 & signif.02[use]
w.ns.02 <- types.strength[avail][report.a][i][use] == 0 & !signif.02[use]
w.s.02 <- types.strength[avail][report.a][i][use] == 0 & signif.02[use]
s.ns.02 <- types.strength[avail][report.a][i][use] == 2 & !signif.02[use]
s.s.02 <- types.strength[avail][report.a][i][use] == 2 & signif.02[use]

sig.02 <- use & signif.02
insig.02 <- use & !signif.02

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

sig.m11 <- use & signif.m11
insig.m11 <- use & !signif.m11

plot(est.m11[use][m.ns.m11],t.ind[use][m.ns.m11],ylim=c(min(t.ind[use])-.35,max(t.ind[use])+.35),axes=FALSE,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Mixed Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)
arrows(ci.lo.m11[sig.m11],t.ind[sig.m11]-adj.m11,ci.hi.m11[sig.m11],t.ind[sig.m11]-adj.m11,angle=90,code=3,length=0)
arrows(ci.lo.m11[insig.m11],t.ind[insig.m11]-adj.m11,ci.hi.m11[insig.m11],t.ind[insig.m11]-adj.m11,angle=90,code=3,length=0,col="gray60")
points(est.m11[use][w.ns.m11],t.ind[use][w.ns.m11]-adj.m11,pch=17,col="gray60",cex=.65)
points(est.m11[use][s.ns.m11],t.ind[use][s.ns.m11]-adj.m11,pch=17,col="gray60",cex=1.0)
points(est.m11[use][w.s.m11],t.ind[use][w.s.m11]-adj.m11,pch=17,cex=.65)
points(est.m11[use][s.s.m11],t.ind[use][s.s.m11]-adj.m11,pch=17,cex=1.0)

arrows(ci.lo.02[sig.02],t.ind.t[sig.02]-adj.02,ci.hi.02[sig.02],t.ind.t[sig.02]-adj.02,angle=90,code=3,length=0)
arrows(ci.lo.02[insig.02],t.ind.t[insig.02]-adj.02,ci.hi.02[insig.02],t.ind.t[insig.02]-adj.02,angle=90,code=3,length=0,col="gray60")
points(est.02[use][w.ns.02],t.ind.t[use][w.ns.02]-adj.02,pch=15,col="gray60",cex=.65)
points(est.02[use][s.ns.02],t.ind.t[use][s.ns.02]-adj.02,pch=15,col="gray60",cex=1.0)
points(est.02[use][w.s.02],t.ind.t[use][w.s.02]-adj.02,pch=15,cex=.65)
points(est.02[use][s.s.02],t.ind.t[use][s.s.02]-adj.02,pch=15,cex=1.0)

act.labs.2 <- c("Ger.","EU","ECB")
axis(2, at=y.lab, labels=act.labs.2, las = 0)
mtext("Cumulative Effect, Log-differenced Spreads",side=1,line=2.5)
axis(1, labels=T)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)
###
dev.off()

########################################################################
## Results by country:
report <- !is.na(types.actor) & !is.na(types.strength) & types.actor != 3 & types.sign != 3
country.res <- vector()
country.models <- list()
country.models.l3 <- list()
country.models.l4 <- list()
for (c in 1:5) {
  res <- lm(d.spreads.sub[,c] ~ events + events.l1 + as.factor(sign.yrqr) + d.spreads.sub.l1[,c] + d.spreads.sub.l2[,c])
  res.l3 <- lm(d.spreads.sub[,c] ~ events + events.l1 + as.factor(sign.yrqr) + d.spreads.sub.l1[,c] + d.spreads.sub.l2[,c] + d.spreads.sub.l3[,c])
  res.l4 <- lm(d.spreads.sub[,c] ~ events + events.l1 + as.factor(sign.yrqr) + d.spreads.sub.l1[,c] + d.spreads.sub.l2[,c] + d.spreads.sub.l3[,c] + d.spreads.sub.l4[,c])
  ## Add 1 lag for Spain and Greece:
  if (c %in% c(4,5)) {res <- res.l3}  
  est.temp <- res$coefficients[2:(((length(types)-0)*2)+1)]
  est.c <- est.temp[1:(length(types)-0)] + est.temp[(1+(length(types)-0)):((length(types)-0)*2)]
  est.c <- est.c[report]
  country.res <- cbind(country.res,est.c)
  country.models[[c]] <- res
  country.models.l3[[c]] <- res.l3
  country.models.l4[[c]] <- res.l4
}

country.res <- country.res[i,]

## GARCH results:
if (do.garch == T) {
  timedummies <- as.data.frame(model.matrix(~ -1 + factor(sign.yrqr)))
  timedummies <- timedummies[-1]
  predictors <- cbind(events,events.l1,timedummies)
  spec3 = ugarchspec(
    mean.model=list(armaOrder = c(2, 0),external.regressors=as.matrix(predictors)),start.pars=c())
  spec3
  spec4 = ugarchspec(
    mean.model=list(armaOrder = c(3, 0),external.regressors=as.matrix(predictors)),start.pars=c())
  spec4
  ##
  country.garch.res <- vector()
  garch.models <- list()
  for (c in 1:5) {
    res <- ugarchfit(data = d.spreads.sub[,c], spec = spec3)
    est.temp <- coef(res)[(1+3):(((length(types)-0)*2)+3)]
    est.c <- est.temp[1:(length(types)-0)] + est.temp[(1+(length(types)-0)):((length(types)-0)*2)]
    est.c <- est.c[report]
    country.garch.res <- cbind(country.garch.res,est.c)
    garch.models[[c]] <- res
  }
  country.garch.res <- country.garch.res[i,]
}
########################################################################
## Figure 3:
act.labs <- c("Germany","EU","ECB")
postscript(paste("figure3",".eps", sep=""),width=7,height=8)
#pdf(paste("figure3",".pdf", sep=""),width=7,height=8)
par(mgp=c(2.5,1,0))
par(mar=c(.6,3.1,2.1,3.1))
t.ind <- 1:(length(types.a))
t.ind.t <- t.ind
n.c <- NCOL(d.spreads.sub)
order.c <- c(n.c,1:(n.c-1))
dots <- c(21:25)
c.labs <- c("Italy", "Ireland", "Portugal", "Spain", "Greece")[order.c]
### Plot 1: 
par(fig=c(0,1,lo0,hi0))
use <- types.sign[avail][report.a][i] == 0
sta <- types.strength[avail][report.a][i][use] == 0 
dec <- types.strength[avail][report.a][i][use] == 2 
y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

adj <- .15

plot(country.res[,1][use],t.ind.t[use],ylim=c(min(t.ind.t[use])-.35,max(t.ind.t[use])+.35),type="n", axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Negative Signals",xlim=c(-lim,lim))
abline(v=0,lty=2)

for (c in 1:5) {
  points(country.res[,order.c[c]][use][sta],t.ind.t[use][sta]+adj,pch=dots[c],cex=.61,bg="black")
  points(country.res[,order.c[c]][use][dec],t.ind.t[use][dec]+adj,pch=dots[c],cex=.95,bg="black")
}
for (c in 1:5) {
  points(country.garch.res[,order.c[c]][use][sta],t.ind.t[use][sta]-adj,pch=dots[c],cex=.61,col="gray60",bg="gray60")
  points(country.garch.res[,order.c[c]][use][dec],t.ind.t[use][dec]-adj,pch=dots[c],cex=.95,col="gray60",bg="gray60")
}

axis(2, at=y.lab, labels=act.labs.2, las = 0)
lines.at <- (min(t.ind.t[use]) + cumsum(rev(table(types.actor[avail][report][i][use])))[1:2] + .5 - 1)
abline(h=lines.at,lty=3)

legend("topright",cex=.75, bg="white",bty="o", inset=c(-.06,.00),xpd=T,box.col="black",
       c(c.labs, "(GARCH in gray)"),pch=c( dots,NA),col=c("black","black"),pt.bg=c("black"),pt.cex=c(.95))

### Plot 2:
par(mar=c(.6,3.1,2.1,3.1))
par(fig=c(0,1,lo1,hi1), new=TRUE)
use <- types.sign[avail][report.a][i] == 1
sta <- types.strength[avail][report.a][i][use] == 0 
dec <- types.strength[avail][report.a][i][use] == 2 
y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

plot(country.res[,1][use],t.ind.t[use],ylim=c(min(t.ind.t[use])-.35,max(t.ind.t[use])+.35),type="n", axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Positive Signals",xlim=c(-lim,lim))

abline(v=0,lty=2)
for (c in 1:5) {
  points(country.res[,order.c[c]][use][sta],t.ind.t[use][sta]+adj,pch=dots[c],cex=.61,bg="black")
  points(country.res[,order.c[c]][use][dec],t.ind.t[use][dec]+adj,pch=dots[c],cex=.95,bg="black")
}
for (c in 1:5) {
  points(country.garch.res[,order.c[c]][use][sta],t.ind.t[use][sta]-adj,pch=dots[c],cex=.61,col="gray60",bg="gray60")
  points(country.garch.res[,order.c[c]][use][dec],t.ind.t[use][dec]-adj,pch=dots[c],cex=.95,col="gray60",bg="gray60")
}

axis(2, at=y.lab, labels=act.labs, las = 0)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)

### Plot 3:
par(mar=c(4.1,3.1,2.1,3.1))
par(fig=c(0,1,lo2,hi2), new=TRUE)
use <- types.sign[avail][report.a][i] == 2

sta <- types.strength[avail][report.a][i][use] == 0 
dec <- types.strength[avail][report.a][i][use] == 2 

y.lab <- tapply(t.ind[use],types.actor[avail][report.a][i][use],mean)

plot(country.res[,1][use],t.ind.t[use],ylim=c(min(t.ind.t[use])-.35,max(t.ind.t[use])+.35),type="n", axes=F,col="gray60",yaxt="n",xaxt="n", pch=16,xlab="", ylab="",main="Mixed Signals",xlim=c(-lim,lim))

abline(v=0,lty=2)

for (c in 1:5) {
  points(country.res[,order.c[c]][use][sta],t.ind.t[use][sta]+adj,pch=dots[c],cex=.61,bg="black")
  points(country.res[,order.c[c]][use][dec],t.ind.t[use][dec]+adj,pch=dots[c],cex=.95,bg="black")
}
for (c in 1:5) {
  points(country.garch.res[,order.c[c]][use][sta],t.ind.t[use][sta]-adj,pch=dots[c],cex=.61,col="gray60",bg="gray60")
  points(country.garch.res[,order.c[c]][use][dec],t.ind.t[use][dec]-adj,pch=dots[c],cex=.95,col="gray60",bg="gray60")
}

act.labs.2 <- c("Ger.","EU","ECB")
axis(2, at=y.lab, labels=act.labs.2, las = 0)
mtext("Cumulative Effect, Day 0-1, Log-differenced Spreads",side=1,line=2.5)
axis(1, labels=T)
abline(h=(min(t.ind[use]) + cumsum(rev(table(types.actor[avail][report.a][i][use])))[1:2] + .5 - 1),lty=3)
###
dev.off()
########################################################################
## Exporting 2 x 5 tables of country-specific results:
## First: 5 x AR(2)DL results:

for (c in order.c) {
results.raw <- summary(country.models[[c]])$coefficients
HC.se.raw <- sqrt(diag(vcovHC(country.models[[c]])))
results.raw[,2] <- HC.se.raw
results.raw[,3] <- (results.raw[,1]/results.raw[,2])
results.raw[,4] <- (pt(-abs(results.raw[,3]),df=length(country.models[[c]]$residuals))*2)

arch.lm.p.2 <- formatC(round(ArchTest(country.models[[c]]$residuals, 2)$p.value,digits=3),format='f',digits=3)
arch.lm.p.5 <- formatC(round(ArchTest(country.models[[c]]$residuals, 5)$p.value,digits=3),format='f',digits=3)
box.p.5 <- formatC(round(AutocorTest(country.models[[c]]$residuals, lag=5)$p.value,digits=3),format='f',digits=3)

results.raw.r <- results.raw
results.raw.r[,1:2] <- formatC(round(results.raw[,1:2],digits=3),format='f',digits=3)
results.stars <- results.raw.r
for (i in 1:NROW(results.raw)) {
  if (results.raw[i,4] < .1) {results.stars[i,1] <- paste(results.raw.r[i,1],"*ones",sep="")}
  if (results.raw[i,4] < .05) {results.stars[i,1] <- paste(results.raw.r[i,1],"*twos",sep="")}
  if (results.raw[i,4] < .01) {results.stars[i,1] <- paste(results.raw.r[i,1],"*threes",sep="")}
}

col1 <-  results.stars[-((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2]
empty <- matrix("",ncol=2,nrow=(NROW(results.stars)-1-((length(types[avail])*2))))
col2 <- rbind(rbind(rep("",2)),results.stars[((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2],empty)

additional.stats <- rbind(cbind(formatC(round(summary(country.models[[c]])$adj.r.squared,digits=3),format='f',digits=3),rbind(rep("",3))),
                                cbind(arch.lm.p.2,rbind(rep("",3))),
                                cbind(arch.lm.p.5,rbind(rep("",3))),
                                cbind(box.p.5,rbind(rep("",3)))
                                )

summary(mod.to.report)$r.squared[2]
results.out <- cbind(col1,col2)
results.out <- rbind(results.out,additional.stats)

if (c %in% 1:3) {
  rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],"Yl1","Yl2",
                           "R2, adj.","ARCH-LM(2)","ARCH-LM(5)","Ljung-Box(5)")
} else {
  rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],"Yl1","Yl2","Yl3",
                             "R2, adj.","ARCH-LM(2)","ARCH-LM(5)","Ljung-Box(5)")
}

write.csv(results.out,file=paste("countrymod", c, ".csv" ,sep=""))
print(c.labs[which(order.c == c)])
print(xtable(results.out))
}

## Second: 5 x AR(2)DL-GARCH results:
for (c in order.c) {
  z = residuals(garch.models[[c]])/sigma(garch.models[[c]])
  arch.lm.p.2 <- formatC(round(ArchTest(z, 2)$p.value,digits=3),format='f',digits=3)
  arch.lm.p.5 <- formatC(round(ArchTest(z, 5)$p.value,digits=3),format='f',digits=3)
  box.p.5 <- formatC(round(AutocorTest(z, lag=5,df=3)$p.value,digits=3),format='f',digits=3)
  box.p.5.sq <- formatC(round(AutocorTest(z^2, lag=5,df=3)$p.value,digits=3),format='f',digits=3)

  results.raw.a <- garch.models[[c]]@fit$robust.matcoef  
  results.raw <- rbind(results.raw.a[c(1,4:((length(types[avail])*2)+NCOL(timedummies)+3)),],results.raw.a[2:3,],results.raw.a[((length(types[avail])*2)+NCOL(timedummies)+4):((length(types[avail])*2)+NCOL(timedummies)+6),])
  
  results.raw.r <- results.raw
  results.raw.r[,1:2] <- formatC(round(results.raw[,1:2],digits=3),format='f',digits=3)
  results.stars <- results.raw.r
  for (i in 1:NROW(results.raw)) {
    if (results.raw[i,4] < .1) {results.stars[i,1] <- paste(results.raw.r[i,1],"*ones",sep="")}
    if (results.raw[i,4] < .05) {results.stars[i,1] <- paste(results.raw.r[i,1],"*twos",sep="")}
    if (results.raw[i,4] < .01) {results.stars[i,1] <- paste(results.raw.r[i,1],"*threes",sep="")}
  }
  
  col1 <-  results.stars[-((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2]
  empty <- matrix("",ncol=2,nrow=(NROW(results.stars)-1-((length(types[avail])*2))))
  col2 <- rbind(rbind(rep("",2)),results.stars[((length(types[avail])+1+1):((length(types[avail])*2)+1)),1:2],empty)

  additional.stats <- rbind(
                            cbind(arch.lm.p.2,rbind(rep("",3))),
                            cbind(arch.lm.p.5,rbind(rep("",3))),
                            cbind(box.p.5,rbind(rep("",3))),
                            cbind(box.p.5.sq,rbind(rep("",3)))
                            )
  results.out <- cbind(col1,col2)
  results.out <- rbind(results.out,additional.stats)
  rownames(results.out) <- c("Intercept",types.lab[avail],levels(sign.yrqr)[2:length(levels(sign.yrqr))],
                             "Yl1","Yl2","omega","alpha","beta","ARCH-LM(2)","ARCH-LM(5)","Ljung-Box(5)","Ljung-Box2(5)")
  write.csv(results.out,file=paste("countrygarchmod", c, ".csv" ,sep=""))
  print(c.labs[which(order.c == c)])
  print(xtable(results.out))
}
