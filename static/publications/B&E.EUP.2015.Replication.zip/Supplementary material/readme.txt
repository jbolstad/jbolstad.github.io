This folder contains complete data and replication codes for the following article:
Bølstad, Jørgen, and Christoph Elhardt, 2015, "To Bail Out or Not to Bail Out? Crisis Politics, Credibility, and Default Risk in the Eurozone", European Union Politics, 16 (3).

The coding of relevant events (signals.csv) is as follows:

Actor:
0 = Germany
1 = EU
2 = ECB
3 = Rating Agency

Sign:
0 = Negative
1 = Positive
2 = Mixed

Strength:
0 = Weak statement
1 = Strong statement (in the article analyzed together with weak statements)
2 = Decision
NA/blank = Interest rate decision (by the ECB)

For further details, please contact the authors.