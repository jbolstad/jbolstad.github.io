setwd("your/local/directory")

library(foreign)
library(splines)
library(mgcv)

limit <- 5
pad.right <- 1
######## Event data:
signals <- read.csv("signals.csv", row.names = 1)
signals$date <- as.Date(signals$date)
signals[is.na(signals)] <- ""
signals$type <- with(signals, interaction(actor, sign, strength))
######## Bond rate data:
spreads <- read.csv("spreads.csv", row.names = 1)
spreads[,1] <- as.Date(spreads[,1])
n.c <- NCOL(spreads)-1
d.log.spreads <- (log(spreads[2:NROW(spreads),2:(n.c+1)]) - log(spreads[1:(NROW(spreads)-1),2:(n.c+1)]))
d.log.spreads <- cbind(spreads[2:NROW(spreads),1],d.log.spreads)
colnames(d.log.spreads)[1] <- "date"
d.spreads <- d.log.spreads
d.spreads.sub <- as.matrix(d.spreads[d.spreads$date >= "2009-01-01" & d.spreads$date <= "2012-12-31",2:(n.c+1)])
dates.sub <- d.spreads[d.spreads$date >= "2009-01-01" & d.spreads$date <= "2012-12-31",1]
######## Move events to first subsequent trading day:
while (length(signals$date[!(signals$date %in% dates.sub)]) > 0) {
  signals$date[!(signals$date %in% dates.sub)] <- signals$date[!(signals$date %in% dates.sub)] + 1
}
######## How many signals on the same days?
1:3 * table(table(signals$date))
sum(1:3 * table(table(signals$date)))
sum((1:3 * table(table(signals$date)))[2:3])
######## Identify isolated events:
use <- vector()
for (i in 1:NROW(signals)) { 
  use.i <- T
  d.i <- signals$date[i]
  b.i <- signals$date[i-1] 
  a.i <- signals$date[i+1]   
  ## Trading days since last event:
  dates.b <- dates.sub[dates.sub > signals$date[i-1] & dates.sub <= signals$date[i]]
  ## Trading days until next event:
  dates.a <- dates.sub[dates.sub >= signals$date[i] & dates.sub < signals$date[i+1]] 
  if (i > 1) {if (length(dates.b) < (limit + 0)) {use.i <- F}}
  if (i < NROW(signals)) {if (length(dates.a) < (limit + 0 + pad.right)) {use.i <- F}}
  use <- c(use,use.i)
}
## Keep only isolated events:
signals <- signals[use,]
## Exclude the weakest signals:
drop <- which(signals$strength=="0")
signals <- signals[-drop,]
########
types <- tapply(as.numeric(signals$type),signals$type,mean)
types <- types[!is.na(types)]
######## Obtain relevant spreads for each isolated event:
window <- round(limit / 2) - 1
data <- vector()
  for (i in 1:NROW(signals)) {
    print(i)
    lead <- 1
    lag <- 0
    # Select the closest day we have data for, before and after signal:
    s.i <- which(d.spreads$date==(signals$date[i]))
    while (length(s.i)==0 & lag < 5) {
      lag <- lag + 1
      s.i <- which(d.spreads$date==(signals$date[i] + lag))
    }
    b.i <- which(d.spreads$date==(signals$date[i] - lead))
    lag <- 1
    a.i <- which(d.spreads$date==(d.spreads$date[s.i] + lag))
    while (length(b.i)==0 & lead < 5) {
      lead <- lead + 1
      b.i <- which(d.spreads$date==(signals$date[i] - lead))
    }
    while (lag < 5 & length(a.i)==0) {
      lag <- lag + 1
      a.i <- which(d.spreads$date==(signals$date[i] + lag))
    }
    spread.b <- d.spreads[(b.i - window):b.i,2:(n.c+1)]
    spread.a <- d.spreads[a.i:(a.i + window + pad.right),2:(n.c+1)]
    spread.s <- d.spreads[s.i,2:(n.c+1)]
    date.b <- -(NROW(spread.b)-0):-1
    date.a <- 1:(NROW(spread.a)-0)
    date.c <- c(date.b,0,date.a)
    spread.c <- rbind(spread.b,spread.s,spread.a)
    tr.c <- c(rep(0,NROW(spread.b)),rep(1,(NROW(spread.a)+1)))
    case.c <- rep(i,NROW(spread.c))
    data.c <- cbind(case.c,date.c,tr.c,spread.c)
    data <- rbind(data,data.c)
  }
######## Plot the average response for isolated events:
x <- window + 1
x2 <- c(-x:(x+pad.right))

wind <- c(0,1)
wind.b <- wind + c(-.5,+.5)
wind.m11 <- c(-1,-1)
wind.m11.b <- wind.m11 + c(-.5,+.5)
wind.02 <- c(2,2)
wind.02.b <- wind.02 + c(-.5,+.5)

data.abs <- data
data.abs[,4:(n.c+3)] <- abs(data[,4:(n.c+3)])
m.diff <- apply(data.abs[,4:(n.c+3)],1,mean)
m.diff.d <- tapply(m.diff,data.abs[,2],mean)
use <- c(1:length(m.diff.d))

data.abs.stack <- vector()
for (c in 1:n.c) {
  data.abs.stack <- rbind(data.abs.stack, cbind(data.abs[,2],data.abs[,c+3],rep(c,length(data.abs[,c+3]))))
}

mod <- lm(data.abs.stack[,2] ~ 0 + as.factor(data.abs.stack[,1]) + as.factor(data.abs.stack[,3]))
est <- summary(mod)$coefficients[1:(length(unique(data.abs.stack[,1]))),1]
se <- summary(mod)$coefficients[1:(length(unique(data.abs.stack[,1]))),2]
ci.lo <- est - (2*se)
ci.hi <-  est + (2*se)

lims <- c(0.03,.1)
if (use.log) {lims <- c(.025,.055)}
u2 <- 1:length(x2)

#postscript("figure1.eps",width=7,height=4)
pdf("figure1.pdf",width=7,height=4)
par(mgp=c(2.5,1,0))
par(mar=c(4.1,4.1,1.1,1.1))
plot(x2[u2],est[u2],ylim=lims+c(-.0003,.0003),pch=20,type="n",xlab="Trading Days Relative to Event", ylab="Mean Abs. Change in Logged Spreads",axes=F)
polygon(c(c(wind.b[1],wind.b[1]),c(wind.b[2],wind.b[2])), c(c(lims[2],lims[1]), c(lims[1],lims[2])),
        col = "grey80", border = NA)
polygon(c(c(wind.m11.b[1],wind.m11.b[1]),c(wind.m11.b[2],wind.m11.b[2])), c(c(lims[2],lims[1]), c(lims[1],lims[2])),
        col = "grey90", border = NA)
polygon(c(c(wind.02.b[1],wind.02.b[1]),c(wind.02.b[2],wind.02.b[2])), c(c(lims[2],lims[1]), c(lims[1],lims[2])),
        col = "grey90", border = NA)
points(x2[u2],est[u2],pch=20)
s <-predict(interpSpline(x2[u2],est[u2]))
lines(s,lty=1)
abline(v=0,lty=2)
axis(1)
axis(2,at=pretty(lims))
dev.off()
