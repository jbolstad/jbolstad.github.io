setwd("your/local/directory")

library(foreign)

signals <- read.csv("signals.csv", row.names = 1)
signals$date <- as.Date(signals$date)
signals[is.na(signals)] <- ""
signals$strength[signals$strength==1] <- 0
signals$type <- with(signals, interaction(strength, actor, sign))
types <- tapply(as.numeric(signals$type),signals$type,mean)
types <- types[!is.na(types)]
types.sign <- tapply(as.numeric(signals$sign),signals$type,mean)
types.actor <- tapply(as.numeric(signals$actor),signals$type,mean)
types.actor <- types.actor[!is.na(types.sign)]
descriptives <- table(signals$sign,signals$actor,signals$strength)
descriptives <- ftable(descriptives)
n.a <- length(unique(types.actor))
descriptives <- cbind(descriptives[1:n.a,],descriptives[(n.a+1):(2*n.a),],descriptives[((2*n.a)+1):(3*n.a),])
descriptives <- descriptives[,-c(7)]
descriptives <- descriptives[,c(2,3,1,5,6,4,7,8)]
descriptives <- cbind(descriptives,apply(descriptives,1,sum))
descriptives <- rbind(descriptives,apply(descriptives,2,sum))
descriptives <- rbind(c(rep(c("Sta.",  "Dec.","Int."),2),c("Sta.",  "Dec.","")),descriptives)
rownames(descriptives) <- c("", "Germany", "EU", "ECB", "Rating Ag.", "Total")
colnames(descriptives) <- c("","Negative","","","Positive","","Mixed","","Total")
descriptives
