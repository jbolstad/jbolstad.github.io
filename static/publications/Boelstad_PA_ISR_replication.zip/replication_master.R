# This file runs all codes necessary to replicate the results in the article and in the appendix.
# Approximate running time on a 4-core 3.20Ghz processor: 1 week.

source("scripts/00_compile_models.R")
source("scripts/01a_run_simulations.R")
source("scripts/01b_plot_simulations.R")
source("scripts/02a_UK_fit_models.R")
source("scripts/02b_UK_summary.R")
source("scripts/02c_UK_plots.R")
source("scripts/02d_UK_posterior_predictions.R")
source("scripts/02e_UK_posterior_pred_plot.R")
source("scripts/03a_14_countries_analysis.R")
source("scripts/03b_14_countries_summary.R")
