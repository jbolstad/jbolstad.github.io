create.data <- function(N, J, B, gs, p.sd, nu, ppos.sd, hetero = T) {
  # Latent parameters:
  true.theta <- rnorm(J, 0, 1)  
  true.alpha <- rnorm(N, 0, 1.15)
  true.beta <- rnorm(N, .9, .8)
  true.self <- rnorm(N, 0, 2)
  true.gamma <- rbeta(N, gs[1], gs[2])
  
  # Self-placements:
  true.self2 <- true.alpha + true.beta * true.self
  self <- round(true.self2)
  self[self < -B] <- -B
  self[self > B] <- B
  
  # Errors:
  if (hetero == F) {ppos.err <- rnorm(N * J, 0, ppos.sd)} else {
    w_j <- rdirichlet(1, rep(8, J))
    sigma_i <- sqrt(rinvchisq(N, nu, scale = (ppos.sd^2) * (J^2)))
    sd_ij <- matrix(rep(sigma_i, times = J) * rep(w_j, each = N), nrow = N, ncol = J)
    ppos.err <- matrix(rnorm(N * J, 0, sd_ij), nrow = N, ncol = J)
  }
  
  # Party positions with DIF:
  mu0 <- (matrix(rep(true.alpha, each = J) + (rep(true.beta, each = J) * true.theta), N, J, byrow = T))
  
  # Preferences reflecting different party sizes and some proximity voting:
  dist <- abs(true.self2 - mu0)
  pref.mu.l <- rnorm(J, 0, p.sd)
  pref.mu.r <- rnorm(J, 0, p.sd)
  prefs <- vector()
  for (j in 1:J) {prefs <- cbind(prefs, rnorm(N, pref.mu.l[j], 1))}
  prefs.r <- vector()
  for (j in 1:J) {prefs.r <- cbind(prefs.r, rnorm(N, pref.mu.r[j], 1))}
  prefs[true.self > 0, ] <- prefs.r[true.self > 0, ]
  w2 <- rbeta(N, 1, 7)
  prefs <- (1 - w2) * prefs - w2 * log(dist)
  prefs <- pnorm(prefs, mean = mean(prefs) + .5, sd = .5)
  
  # Standardizing preferences by individual:  
  pref.min <- apply(prefs, 1, min, na.rm = T)
  pref.max <- apply(prefs, 1, max, na.rm = T)
  repl <- pref.min !=  pref.max
  prefs[repl, ] <- (prefs[repl, ] - pref.min[repl]) / (pref.max[repl] - pref.min[repl])
  prefs <- round(prefs * 10) / 10
  
  # Rationalized party positions:
  p1 <- prefs * self + prefs * B - B
  p2 <- prefs * self - prefs * B + B
  l <- self >=  mu0 
  p <- l * p1 + (1-l) * p2
  r <- p - mu0
  ppos <- round(mu0 + r * rep(true.gamma, times = J) + ppos.err)
  ppos[ppos < -B] <- -B
  ppos[ppos > B] <- B 
  
  # Get mean positions for inits:
  mean.ppos <- apply(ppos, 2, mean, na.rm = T)
  
  return(list(N = N, J = J, B = B, true.theta = true.theta, true.self = true.self, 
    true.mu0 = mu0, true.alpha = true.alpha, true.beta = true.beta, true.gamma = true.gamma, 
    V = self, U = prefs, Y = ppos, M = apply(is.na(ppos), 2, as.numeric), 
    L = which.min(mean.ppos), R = which.max(mean.ppos), mean.ppos = mean.ppos))
}

# Function to draw from an inverse Chi-square distribution (source: GeoR package):
rinvchisq <- function(n, df, scale = 1/df) {
  if ((length(scale) != 1) & (length(scale) != n)) 
    stop("scale should be a scalar or a vector of the same length as x")
  if (df <= 0) 
    stop("df must be greater than zero")
  if (any(scale <= 0)) 
    stop("scale must be greater than zero")
  return((df * scale) / rchisq(n, df = df))
}

# Function to draw from a Dirichlet distribution (source: MCMCpack package):
rdirichlet <- function (n, alpha) {
  l <- length(alpha)
  x <- matrix(rgamma(l * n, alpha), ncol = l, byrow = TRUE)
  sm <- x %*% rep(1, l)
  return(x / as.vector(sm))
}
