require("rstan")
require("basicspace")

m.BAM.homosk <- stan_model(file = "models/m_BAM_homoskedastic.stan", verbose = F)
m.BAM <- stan_model(file = "models/m_BAM.stan", verbose = F)
m.BAM2 <- stan_model(file = "models/m_BAM2.stan", verbose = F)
m.ISR <- stan_model(file = "models/m_ISR.stan", verbose = F)
m.ISR.homosk <- stan_model(file = "models/m_ISR_homoskedastic.stan", verbose = F)

save(list = c("m.BAM.homosk", "m.BAM", "m.BAM2", "m.ISR", "m.ISR.homosk"), file = "models/compiled_models.R")
