library(rstan)
library(basicspace)

source("scripts/functions_general.R")

load("models/compiled_models.R")
load("data/data_EES.R")

flatten.corr.matrix <- function(cormat, lab) {
  ut <- upper.tri(cormat)
  x = rownames(cormat)[row(cormat)[ut]]
  y = rownames(cormat)[col(cormat)[ut]]
  cor = cormat[ut]
  names(cor) = paste(lab, x, y, sep = "-")
  return(cor)
}

# For seed-comparability with future versions of R:
if ((version$major == "3" & as.numeric(version$minor) >=  6.0) | as.numeric(version$major) > 3) {RNGkind(sample.kind = "Rounding")} 
# Set seed for inits
set.seed(123)

# Excluding the UK because it is in the main paper:
data.all <- data.all[!data.all$t101b %in% c("UK"), ]

newdata <- vector()
newppos <- vector()
countryparams <- vector()

# Loop across all countries:
for (country in rev(unique(data.all$t101b))){
  dat <- get.EES.data(data.all, country)
  use <- dat$use
  dat <- prep.data(dat$self, dat$ppos, dat$prefs)
  # Also storing selected data in original format:
  data.c <- data.all[data.all$t101b == country, ][dat$keep, ]
  
  # Use homoskedastic model in Bulgaria:
  if (country == "BG") {ISR.mod <- m.ISR.homosk} else {ISR.mod <- m.ISR}

  chains <- 3; it <- 2000; warm <- 500; samples <- 1500
  # Samling longer in Austria and Italy:
  if (country %in% c("AT", "IT")) {it <- 3500; warm <- 500; samples <- 3000}
  
  thin <- round((it - warm)/(samples/chains))

  # Fit ISR:
  ptm <- proc.time()
  fit.ISR <- sampling(object = ISR.mod, data = dat, chains = chains, cores = chains, 
    algorithm = "NUTS", warmup = warm, iter = it, thin = thin, init = inits.2, seed = 123)
  t <- (proc.time() - ptm)[[3]]
  print(paste("NUTS finished ISR in ", country, " at: " , date(), ". Time spent: ", round(t), "s.", sep = ""))  
  
  # Fit BAM2:
  ptm <- proc.time()
  fit.BAM2 <- sampling(object = m.BAM2, data = dat, chains = chains, cores = chains, 
    algorithm = "NUTS", warmup = warm, iter = it, thin = thin, init = inits.2, seed = 123)
  t <- (proc.time() - ptm)[[3]]
  print(paste("NUTS finished BAM2 in ", country, " at: " , date(), ". Time spent: ", round(t), "s.", sep = ""))  
  
  # Fit BAM:
  ptm <- proc.time()
  fit.BAM <- sampling(object = m.BAM, data = dat, chains = chains, cores = chains, 
    algorithm = "NUTS", warmup = warm, iter = it, thin = thin, init = inits.BAM, seed = 123)
  t <- (proc.time() - ptm)[[3]]
  print(paste("NUTS finished BAM in ", country, " at: " , date(), ". Time spent: ", round(t), "s.", sep = ""))  
  
  # Fit AMx / homoskedastic BAM:
  ptm <- proc.time()
  fit.AM <- sampling(object = m.BAM.homosk, data = dat, chains = chains, cores = chains, 
    algorithm = "NUTS", warmup = warm, iter = it, thin = thin, init = inits.BAM, seed = 123)
  t <- (proc.time() - ptm)[[3]]
  print(paste("NUTS finished AM* in ", country, " at: " , date(), ". Time spent: ", round(t), "s.", sep = ""))  
  
  AM.est <- get.estimates(fit.AM, dat)
  BAM.est <- get.estimates(fit.BAM, dat)
  BAM2.est <- get.estimates(fit.BAM2, dat)
  ISR.est <- get.estimates(fit.ISR, dat)
  
  AM.waic <- WAIC(get.lik(fit.AM, dat$M))
  BAM.waic <- WAIC(get.lik(fit.BAM, dat$M))
  BAM2.waic <- WAIC(get.lik(fit.BAM2, dat$M))
  ISR.waic <- WAIC(get.lik(fit.ISR, dat$M))
  
  AM.neg.beta <- sum(AM.est$beta[, 2] < 0) / dat$N
  BAM.neg.beta <- sum(BAM.est$beta[, 2] < 0) / dat$N
  BAM2.neg.beta <- sum(BAM2.est$beta[, 2] < 0) / dat$N
  ISR.neg.beta <- sum(ISR.est$beta[, 2] < 0) / dat$N
  
  BAM.pars <- c("alpha", "beta", "theta")
  ISR.pars <- c("alpha", "beta", "theta", "gamma")
  
  AM.Rhat <- max(summary(fit.AM, pars = BAM.pars)$summary[, 10])
  BAM.Rhat <- max(summary(fit.BAM, pars = BAM.pars)$summary[, 10])
  BAM2.Rhat <- max(summary(fit.BAM2, pars = BAM.pars)$summary[, 10])
  ISR.Rhat <- max(summary(fit.ISR, pars = ISR.pars)$summary[, 10])
  
  AM.n.eff <- min(summary(fit.AM, pars = BAM.pars)$summary[, 9])
  BAM.n.eff <- min(summary(fit.BAM, pars = BAM.pars)$summary[, 9])
  BAM2.n.eff <- min(summary(fit.BAM2, pars = BAM.pars)$summary[, 9])
  ISR.n.eff <- min(summary(fit.ISR, pars = ISR.pars)$summary[, 9])
  
  mean.gamma <- mean(ISR.est$gamma, na.rm = T)
  
  # Correlations between estimates across models:
  mod.names <- c("AMx", "BAM", "BAM2", "ISR")
  vpos <- cbind(AM.est$vpos[, 2], BAM.est$vpos[, 2], BAM2.est$vpos[, 2], ISR.est$vpos[, 2])
  colnames(vpos) <- mod.names
  ppos <- cbind(AM.est$theta[, 4], BAM.est$theta[, 4], BAM2.est$theta[, 4], ISR.est$theta[, 4])
  colnames(ppos) <- mod.names
  r.vpos <- rbind(flatten.corr.matrix(cor(vpos), "v"))
  r.ppos <- rbind(flatten.corr.matrix(cor(ppos), "p"))
  
  # Results at country-level:
  params.c <- cbind.data.frame(country, dat$N, dat$J, AM.neg.beta, BAM.neg.beta, BAM2.neg.beta, ISR.neg.beta, AM.Rhat, BAM.Rhat, BAM2.Rhat, ISR.Rhat, 
    AM.n.eff, BAM.n.eff, BAM2.n.eff, ISR.n.eff, AM.waic, BAM.waic, BAM2.waic, ISR.waic, mean.gamma, r.vpos, r.ppos)
  countryparams <- rbind(countryparams, params.c)
  
  # Results at party-level:
  ppos.c <- cbind.data.frame(rep(country, dat$J), use, AM.est$theta, BAM.est$theta, BAM2.est$theta, ISR.est$theta, dat$mean.ppos)
  colnames(ppos.c) <- c("c", "party", "AM.lo", "AM.med", "AM.hi", "AM.mean", "BAM.lo", "BAM.med", "BAM.hi", 
    "BAM.mean", "BAM2.lo", "BAM2.med", "BAM2.hi", "BAM2.mean", "ISR.lo", "ISR.med", "ISR.hi", "ISR.mean", "mean.ppos")
  newppos <- rbind(newppos, ppos.c)
  
  # Results at individual-level:
  results.c <- cbind(AM.est$alpha, AM.est$beta, AM.est$vpos[, 1:4], BAM.est$alpha, BAM.est$beta, BAM.est$vpos[, 1:4], 
    BAM2.est$alpha, BAM2.est$beta, BAM2.est$vpos[, 1:4], ISR.est$alpha, ISR.est$beta, ISR.est$gamma, ISR.est$vpos[, 1:4])
  colnames(results.c) <- c("a.AM.lo", "a.AM.med", "a.AM.hi", "a.AM.mean", "b.AM.lo", "b.AM.med", "b.AM.hi", "b.AM.mean", 
    "v.AM.lo", "v.AM.med", "v.AM.hi", "v.AM.mean", "a.BAM.lo", "a.BAM.med", "a.BAM.hi", "a.BAM.mean", 
    "b.BAM.lo", "b.BAM.med", "b.BAM.hi", "b.BAM.mean", "v.BAM.lo", "v.BAM.med", "v.BAM.hi", "v.BAM.mean", 
    "a.BAM2.lo", "a.BAM2.med", "a.BAM2.hi", "a.BAM2.mean", "b.BAM2.lo", "b.BAM2.med", "b.BAM2.hi", "b.BAM2.mean", 
    "v.BAM2.lo", "v.BAM2.med", "v.BAM2.hi", "v.BAM2.mean", "a.ISR.lo", "a.ISR.med", "a.ISR.hi", "a.ISR.mean", 
    "b.ISR.lo", "b.ISR.med", "b.ISR.hi", "b.ISR.mean", "g.ISR.pmode", "v.ISR.lo", "v.ISR.med", "v.ISR.hi", "v.ISR.mean")
  data.c.full <- cbind(data.c, results.c)
  newdata <- rbind(newdata, data.c.full)
}

save(list = c("newdata", "newppos", "countryparams"), file = "results/results_14_countries.R")
