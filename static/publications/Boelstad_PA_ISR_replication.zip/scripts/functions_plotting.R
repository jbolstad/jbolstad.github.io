library(RColorBrewer)

source("scripts/functions_plot_legends.R")

# Create transparent and non-transparent palettes:
n.group = 5
n.l <- n.group + 1
pal.1 <- brewer.pal(n.l+1, "Reds");pal.1 <- pal.1[-1]
pal.1.t <- rgb(t(col2rgb(pal.1, alpha = F)), alpha=50, maxColorValue=255) 
pal.2 <- brewer.pal(n.l+1, "Blues");pal.2 <- pal.2[-1]
pal.2.t <- rgb(t(col2rgb(pal.2, alpha = F)), alpha=50, maxColorValue=255) 
pal.3 <- brewer.pal(n.l+1, "Greens");pal.3 <- pal.3[-1]
pal.3.t <- rgb(t(col2rgb(pal.3, alpha = F)), alpha=50, maxColorValue=255) 
pal.4 <- brewer.pal(n.l+1, "Oranges");pal.4 <- pal.4[-1]
pal.4.t <- rgb(t(col2rgb(pal.4, alpha = F)), alpha=50, maxColorValue=255) 

# Function determining which points are in inter-quartile range:
is.in.iqr <- function(v, ind) {
  in.iqr <- vector(length=length(ind))
  for (cat in unique(ind)) {in.iqr[ind == cat] <- (v[ind == cat] > quantile(v[ind == cat], probs=c(.25), na.rm=T) & v[ind == cat] < quantile(v[ind == cat], probs=c(.75), na.rm=T))} 
  return(in.iqr)
}

# Function to plot simulation results for 4 models:
m.boxplot4 <- function(xlab, xlabs, xlabfac = 1, ylab, title, labels, plotleg = T, ind, y, ylims, yaxs, ylines, showprob, x.add, l.placement="topright") {
  n.cat <- length(unique(ind))
  xaxs <- 1:n.cat
  
  x.1 <- xaxs - 1.5*x.add 
  x.2 <- xaxs - .5*x.add 
  x.3 <- xaxs + .5*x.add 
  x.4 <- xaxs + 1.5*x.add 
  
  xlims <- c(1-(x.add*1.75), max(xaxs)+(x.add*1.75))
  plot(1, 1, ylim=ylims, xlim=xlims, axes=F, type="n", 
    xlab="", ylab=ylab)#, xaxs="i", yaxs="i")
  if (length(ylines)>0) {for (yl in ylines) {abline(h=yl, col="lightgray")}}
  x.ind <- transform(ind, id=as.numeric(factor(ind)))[, 2]
  show <- as.logical(rbinom(length(x.ind), size=1, prob=showprob))
  
  x.ind.1 <- x.ind - 1.5*x.add + rnorm(length(x.ind), 0, x.add/11)
  x.ind.2 <- x.ind - .5*x.add + rnorm(length(x.ind), 0, x.add/11)
  x.ind.3 <- x.ind + .5*x.add + rnorm(length(x.ind), 0, x.add/11)
  x.ind.4 <- x.ind + 1.5*x.add + rnorm(length(x.ind), 0, x.add/11)
  
  in.iqr.1 <- is.in.iqr(y[, 1], x.ind)
  points(x.ind.1[show&!in.iqr.1], y[, 1][show&!in.iqr.1], pch=16, cex=.6, col=pal.2.t[3])
  boxplot(y[, 1]~ind, at=x.1, add=T, ylim=ylims, xlim=xlims, outline=F, medlty=1, boxlty=3, 
    axes=F, boxwex=.12, outpch=16, whisklty=3, whisklwd=1, outcex=.25, medlwd=2, 
    border=pal.2[6], medcol=pal.2[6], whiskcol=pal.2[6], col=pal.2[1], staplelty=0)
  
  in.iqr.2 <- is.in.iqr(y[, 2], x.ind)
  points(x.ind.2[show&!in.iqr.2], y[, 2][show&!in.iqr.2], pch=16, cex=.6, col=pal.2.t[3])
  boxplot(y[, 2]~ind, at=x.2, add=T, ylim=ylims, xlim=xlims, outline=F, medlty=1, boxlty=2, 
    axes=F, boxwex=.12, outpch=16, whisklty=2, whisklwd=1, outcex=.25, medlwd=2, 
    border=pal.2[6], medcol=pal.2[6], whiskcol=pal.2[6], col=pal.2[2], staplelty=0)
  
  in.iqr.3 <- is.in.iqr(y[, 3], x.ind)
  points(x.ind.3[show&!in.iqr.3], y[, 3][show&!in.iqr.3], pch=16, cex=.6, col=pal.2.t[3])
  boxplot(y[, 3]~ind, at=x.3, add=T, ylim=ylims, xlim=xlims, outline=F, medlty=1, boxlty=4, 
    axes=F, boxwex=.12, outpch=16, whisklty=4, whisklwd=1, outcex=.25, 
    border=pal.2[6], medcol=pal.2[6], whiskcol=pal.2[6], col=pal.2[3], staplelty=0)
  
  in.iqr.4 <- is.in.iqr(y[, 4], x.ind)
  points(x.ind.4[show&!in.iqr.4], y[, 4][show&!in.iqr.4], pch=16, cex=.6, col=pal.2.t[3])
  boxplot(y[, 4]~ind, at=x.4, add=T, ylim=ylims, xlim=xlims, outline=F, medlty=1, boxlty=1, 
    axes=F, boxwex=.12, outpch=16, whisklty=1, whisklwd=1, outcex=.25, medlwd=2, 
    border=pal.2[6], medcol=pal.2[6], whiskcol=pal.2[6], col=pal.2[4], staplelty=0)
  
  title(title, line = .65)
  axis(1, labels=xlabs, at=xaxs)
  axis(2, at=yaxs)
  mtext(text=xlab, side=1, line=2.5, outer=F, cex=.75 * xlabfac)
  
  if (plotleg == T) {legend.2(l.placement, bty="n", inset=c(.00, .025), cex=1, labels, fill=c(pal.2[1], pal.2[2], pal.2[3], pal.2[4]), 
    border=c(pal.2[6], pal.2[6], pal.2[6], pal.2[6]), fill.lty=c(3, 2, 4, 1))}
}

# Function to plot simulation results for a single model:
m.boxplot1 <- function(xlab, xlabs, xlabfac = 1, ylab, title, labels, plotleg = T, ind, y, ylims, yaxs, ylines, showprob, x.add, l.placement="bottomright") {
  n.cat <- length(unique(ind))
  xaxs <- 1:n.cat
  x.l <- xaxs - x.add 
  x.r <- xaxs + x.add 
  xlims <- c(1-(x.add*1.25), max(xaxs)+(x.add*1.25))
  plot(1, 1, ylim=ylims, xlim=xlims, axes=F, type="n", 
       xlab="", ylab=ylab)#, xaxs="i", yaxs="i")
  if (length(ylines)>0) {for (yl in ylines) {abline(h=yl, col="lightgray")}}
  x.ind <- transform(ind, id=as.numeric(factor(ind)))[, 2]
  show <- as.logical(rbinom(length(x.ind), size=1, prob=showprob))
  
  x.indlog_lik <- x.ind + rnorm(length(x.ind), 0, x.add/11)
  
  in.iqr <- is.in.iqr(y, x.ind)
  points(x.ind[show&!in.iqr], y[show&!in.iqr], pch=16, cex=.6, col=pal.2.t[3])
  boxplot(y~ind, at=xaxs, add=T, ylim=ylims, xlim=xlims, outline=F, 
          axes=F, boxwex=.2, outpch=16, whisklty=1, whisklwd=1, outcex=.25, medlwd=2, 
          border=pal.2[6], medcol=pal.2[6], whiskcol=pal.2[6], col=pal.2[4], outcol=pal.2.t[4], staplelty=0)
  
  title(title, line = .65)
  axis(1, labels=xlabs, at=xaxs)
  axis(2, at=yaxs)
  mtext(text=xlab, side=1, line=2.5, outer=F, cex=.75 * xlabfac)
  
  if (plotleg == T) {legend.2(l.placement, bty="n", inset=c(.00, .025), cex=1, labels, fill=c(pal.2[4]), 
    border=c(pal.2[6]), fill.lty=c(1))}
}

new.pairs <- function(x, labels, panel = points, ..., lower.panel = panel, 
                      upper.panel = panel, diag.panel = NULL, text.panel = textPanel, 
                      label.pos = 0.5 + has.diag/3, line.main = 3, cex.labels = NULL, 
                      font.labels = 1, row1attop = TRUE, gap = 1, log = "", xlim=NULL, ylim=NULL) {
  if (doText <- missing(text.panel) || is.function(text.panel)) 
    textPanel <- function(x = 0.5, y = 0.5, txt, cex, font) text(x, 
                                                                 y, txt, cex = cex, font = font)
  localAxis <- function(side, x, y, xpd, bg, col = NULL, main, 
                        oma, ...) {
    xpd <- NA
    if (side%%2L == 1L && xl[j]) 
      xpd <- FALSE
    if (side%%2L == 0L && yl[i]) 
      xpd <- FALSE
    if (side%%2L == 1L) 
      Axis(x, side = side, xpd = xpd, ...)
    else Axis(y, side = side, xpd = xpd, ...)
  }
  localPlot <- function(..., main, oma, font.main, cex.main) plot(...)
  localLowerPanel <- function(..., main, oma, font.main, cex.main) lower.panel(...)
  localUpperPanel <- function(..., main, oma, font.main, cex.main) upper.panel(...)
  localDiagPanel <- function(..., main, oma, font.main, cex.main) diag.panel(...)
  dots <- list(...)
  nmdots <- names(dots)
  if (!is.matrix(x)) {
    x <- as.data.frame(x)
    for (i in seq_along(names(x))) {
      if (is.factor(x[[i]]) || is.logical(x[[i]])) 
        x[[i]] <- as.numeric(x[[i]])
      if (!is.numeric(unclass(x[[i]]))) 
        stop("non-numeric argument to 'pairs'")
    }
  }
  else if (!is.numeric(x)) 
    stop("non-numeric argument to 'pairs'")
  panel <- match.fun(panel)
  if ((has.lower <- !is.null(lower.panel)) && !missing(lower.panel)) 
    lower.panel <- match.fun(lower.panel)
  if ((has.upper <- !is.null(upper.panel)) && !missing(upper.panel)) 
    upper.panel <- match.fun(upper.panel)
  if ((has.diag <- !is.null(diag.panel)) && !missing(diag.panel)) 
    diag.panel <- match.fun(diag.panel)
  if (row1attop) {
    tmp <- lower.panel
    lower.panel <- upper.panel
    upper.panel <- tmp
    tmp <- has.lower
    has.lower <- has.upper
    has.upper <- tmp
  }
  nc <- ncol(x)
  if (nc < 2) 
    stop("only one column in the argument to 'pairs'")
  if (doText) {
    if (missing(labels)) {
      labels <- colnames(x)
      if (is.null(labels)) 
        labels <- paste("var", 1L:nc)
    }
    else if (is.null(labels)) 
      doText <- FALSE
  }
  oma <- if ("oma" %in% nmdots) 
    dots$oma
  main <- if ("main" %in% nmdots) 
    dots$main
  if (is.null(oma)) 
    oma <- c(4, 4, if (!is.null(main)) 6 else 4, 4)
  opar <- par(mfrow = c(nc, nc), mar = rep.int(gap/2, 4), oma = oma)
  on.exit(par(opar))
  dev.hold()
  on.exit(dev.flush(), add = TRUE)
  xl <- yl <- logical(nc)
  if (is.numeric(log)) 
    xl[log] <- yl[log] <- TRUE
  else {
    xl[] <- grepl("x", log)
    yl[] <- grepl("y", log)
  }
  for (i in if (row1attop) 
    1L:nc
    else nc:1L) for (j in 1L:nc) {
      l <- paste0(ifelse(xl[j], "x", ""), ifelse(yl[i], "y", ""))
      if (is.null(xlim) & is.null(ylim))
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
                  type = "n", ..., log = l)
      if (is.null(xlim) & !is.null(ylim))
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
                  type = "n", ..., log = l, ylim=ylim[j,i,])
      if (!is.null(xlim) & is.null(ylim))
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
                  type = "n", ..., log = l, xlim = xlim[j,i,])
      if (!is.null(xlim) & !is.null(ylim))
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
                  type = "n", ..., log = l, xlim = xlim[j,i,], ylim=ylim[j,i,])
      
      if (i == j || (i < j && has.lower) || (i > j && has.upper)) {
        box()
        if (i == 1 && (!(j%%2L) || !has.upper || !has.lower)) 
          localAxis(1L + 2L * row1attop, x[, j], x[, i], 
                    ...)
        if (i == nc && (j%%2L || !has.upper || !has.lower)) 
          localAxis(3L - 2L * row1attop, x[, j], x[, i], 
                    ...)
        if (j == 1 && (!(i%%2L) || !has.upper || !has.lower)) 
          localAxis(2L, x[, j], x[, i], ...)
        if (j == nc && (i%%2L || !has.upper || !has.lower)) 
          localAxis(4L, x[, j], x[, i], ...)
        mfg <- par("mfg")
        if (i == j) {
          if (has.diag) 
            localDiagPanel(as.vector(x[, i]), ...)
          if (doText) {
            par(usr = c(0, 1, 0, 1))
            if (is.null(cex.labels)) {
              l.wid <- strwidth(labels, "user")
              cex.labels <- max(0.8, min(2, 0.9/max(l.wid)))
            }
            xlp <- if (xl[i]) 
              10^0.5
            else 0.5
            ylp <- if (yl[j]) 
              10^label.pos
            else label.pos
            text.panel(xlp, ylp, labels[i], cex = cex.labels, 
                       font = font.labels)
          }
        }
        else if (i < j) 
          localLowerPanel(as.vector(x[, j]), as.vector(x[, 
                                                         i]), ...)
        else localUpperPanel(as.vector(x[, j]), as.vector(x[, 
                                                            i]), ...)
        if (any(par("mfg") != mfg)) 
          stop("the 'panel' function made a new plot")
      }
      else par(new = FALSE)
    }
  if (!is.null(main)) {
    font.main <- if ("font.main" %in% nmdots) 
      dots$font.main
    else par("font.main")
    cex.main <- if ("cex.main" %in% nmdots) 
      dots$cex.main
    else par("cex.main")
    mtext(main, 3, line.main, outer = TRUE, at = 0.5, cex = cex.main, 
          font = font.main)
  }
  invisible(NULL)
}

panel.dens <- function(x, ...) {
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(usr[1:2], 0, 1.5) )
  h <- density(x)
  y <- h$y; y <- y/max(y)
  lines(h$x, y)
}

panel.cor <- function(x, y, digits = 2, prefix = "r = ", cex.cor, ...) {
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  r <- cor(x, y)
  txt <- format(c(r, 0.123456789), digits = digits)[1]
  txt <- paste0(prefix, txt)
  if(missing(cex.cor)) cex.cor <- 1.5
  text(0.5, 0.5, txt, cex = cex.cor)
}

