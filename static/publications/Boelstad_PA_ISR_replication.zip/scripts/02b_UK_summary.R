library(rstan)
require(xtable)

source("scripts/functions_general.R")

load("data/data_EES.R")
ches.dta <- read.csv("data/data_CHES.csv")
ches.codes <- read.csv("data/data_EES_CHES_codes.csv")

load("results/AM_fit_UK_N536.R")
load("results/AMx_fit_UK_N536.R")
load("results/BAM_fit_UK_N536.R")
load("results/BAM2_fit_UK_N536.R")
load("results/ISR_fit_UK_N536.R")

dat <- get.EES.data(data.all, "UK")
dat <- prep.data(dat$self, dat$ppos, dat$prefs, allow.miss = 0, req.only.Y = T)

colnames(ches.codes)[1:2] <- c("c", "party")
colnames(ches.dta)[1] <- "ches_id"

make.row <- function(mod) {
  Obs <- sum(!dat$M)
  
  est <- get.estimates(mod, dat)
  if (class(mod) == "stanfit") {
    est$theta <- est$theta[, 4]
    est$beta <- est$beta[, 2] 
  }

  neg.beta <- sum(est$beta < 0) / sum(!is.na(est$beta))

  UK.ppos <- as.data.frame(cbind(rep("UK", 8), c(1:8), as.data.frame(est$theta)))
  colnames(UK.ppos)[c(1:2, 3)] <- c("c", "party", "mean.est")
  ppos.full <- merge(UK.ppos, ches.codes, by = c("c", "party"))
  ppos.full <- merge(ppos.full, ches.dta, by = "ches_id")
  
  cor.CHES <- cor(ppos.full[, 4], ppos.full$mean)
  cor.CHES.spear <- cor(ppos.full[, 4], ppos.full$mean, method = "spearman")
  cor.mean <- cor(est$theta, dat$mean.ppos)
  
  if (class(mod) == "stanfit") {
    waic <- WAIC(get.lik(mod, dat$M))
    if (mod@model_name == "ISR") {
      max.rhat <- max(summary(mod, pars = c("alpha", "beta", "theta", "gamma", "delta"))$summary[, 10])
      min.n.eff <- min(summary(mod, pars = c("alpha", "beta", "theta", "gamma", "delta"))$summary[, 9])
    } else {
      max.rhat <- max(summary(mod, pars = c("alpha", "beta", "theta"))$summary[, 10])
      min.n.eff <- min(summary(mod, pars = c("alpha", "beta", "theta"))$summary[, 9])
    }
  } else {waic <- ""; max.rhat <- ""; min.n.eff <- ""}

  dec.2 <- c(3, 4, 5, 6, 8)
  dec.0 <- c(7, 9)
  out <- c(dat$N, dat$J, cor.CHES, cor.CHES.spear, cor.mean, neg.beta, waic, max.rhat, min.n.eff)
  out[dec.2] <- formatC(as.numeric(out[dec.2]), digits = 2, format = "f")
  out[dec.0] <- formatC(as.numeric(out[dec.0]), digits = 0, format = "f")
  
  return(out)
}

# Table 1:
table <- vector()
table <- rbind(table, make.row(fit.AM))
table <- rbind(table, make.row(fit.AMx))
table <- rbind(table, make.row(fit.BAM))
table <- rbind(table, make.row(fit.BAM2))
table <- rbind(table, make.row(fit.ISR))
table

mod.names <- cbind(c("AM", "AMx", "BAM", "BAM2", "ISR"))
table.ed <- cbind(mod.names, table)
colnames(table.ed) <- c("Model", "N", "J", "CHES, Cor.", "CHES, Spear.", "Means, cor.", "beta < 0", "WAIC", "Max. Rhat", "Min. N_eff")

table.ed <- table.ed[, -10]
table.ed
table.ed <- table.ed[, -5]
table.ed

print(xtable(table.ed), file = "tables/table_1.tex", compress = FALSE, include.rownames = FALSE)
