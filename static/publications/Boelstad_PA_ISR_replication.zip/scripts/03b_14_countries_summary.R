library(xtable)

load("results/results_14_countries.R")
ches.dta <- read.csv("data/data_CHES.csv")
ches.codes <- read.csv("data/data_EES_CHES_codes.csv")

colnames(ches.codes)[1:2] <- c("c", "party")
colnames(ches.dta)[1] <- "ches_id"
ppos.full <- merge(newppos, ches.codes, by = c("c", "party"))
ppos.full <- merge(ppos.full, ches.dta, by = "ches_id")
ppos.full <- ppos.full[order(as.character(ppos.full$c)), ]

names <- c("Austria", "Bulgaria", "Estonia", "Greece", "Finland", "France", "Hungary", "Ireland", 
  "Italy", "Lithuania", "Netherlands", "Romania", "Slovenia", "Slovakia")

# Table S1:
results <- vector()
for (country in unique(ppos.full$c)) {
  use <- ppos.full$c == country
  use.data <- newdata[newdata$t101b == country, ]

  cor.AM.CHES <- cor(ppos.full$AM.mean[use], ppos.full$mean[use], method = "pearson")
  cor.BAM.CHES <- cor(ppos.full$BAM.mean[use], ppos.full$mean[use], method = "pearson")
  cor.BAM2.CHES <- cor(ppos.full$BAM2.mean[use], ppos.full$mean[use], method = "pearson")
  cor.ISR.CHES <- cor(ppos.full$ISR.mean[use], ppos.full$mean[use], method = "pearson")
  cor.mean.CHES <- cor(ppos.full$mean.ppos[use], ppos.full$mean[use], method = "pearson")
  cor.vpos <- cor(use.data$v.BAM.med, use.data$v.ISR.med, method = "pearson")

  results.temp <- c(country, countryparams[countryparams$country == country, c(2:3, 20)], 
    cor.mean.CHES, cor.AM.CHES, cor.BAM.CHES, cor.BAM2.CHES, cor.ISR.CHES)
  results <- rbind(results, results.temp)
}

results <- results[, -1]
results <- matrix(unlist(results), ncol = ncol(results), byrow = F)
rownames(results) <- c(names)

results <- as.data.frame(results)
colnames(results) <- c("N", "J", "Mean. Rat", "Means", "AM*", "BAM", "BAM2", "ISR")

table.S1 <- results
table.S1[, c(1:2)] <- format(round(table.S1[, c(1:2)], 0), nsmall = 0)
table.S1[, c(3:7)] <- format(round(table.S1[, c(3:7)], 2), nsmall = 2)

print(xtable(table.S1), file = "tables/table_S1.tex", compress = FALSE, include.rownames = FALSE)

# Table S2:
table.S2 <- as.data.frame(cbind(countryparams$AM.waic, countryparams$BAM.waic, countryparams$BAM2.waic, countryparams$ISR.waic))
table.S2 <- table.S2[nrow(table.S2):1, ]
rownames(table.S2) <- c(names)
colnames(table.S2) <- c("AM*", "BAM", "BAM2", "ISR")

print(xtable(table.S2), file = "tables/table_S2.tex", compress = FALSE, include.rownames = FALSE)

# Table S3:
table.S3 <- countryparams[, which(colnames(countryparams) == "v-AMx-BAM"):which(colnames(countryparams) == "v-BAM2-ISR")]
table.S3 <- table.S3[nrow(table.S3):1, ]
rownames(table.S3) <- c(names)
table.S3 <- format(round(table.S3, 2), nsmall = 2)

print(xtable(table.S3), file = "tables/table_S3.tex", compress = FALSE, include.rownames = FALSE)
