require(mgcv)
library(rstan)

source("scripts/functions_general.R")
source("scripts/functions_plotting.R")

load("data/data_EES.R")
ches.dta <- read.csv("data/data_CHES.csv")
ches.codes <- read.csv("data/data_EES_CHES_codes.csv")

load("results/AM_fit_UK_N536.R")
load("results/AMx_fit_UK_N536.R")
load("results/BAM_fit_UK_N536.R")
load("results/BAM2_fit_UK_N536.R")
load("results/ISR_fit_UK_N536.R")

dat <- get.EES.data(data.all, "UK")
dat <- prep.data(dat$self, dat$ppos, dat$prefs, allow.miss = 0, req.only.Y = T)
Y <- as.matrix(dat$Y)

ISR.est <- get.estimates(fit.ISR, dat)
BAM.est <- get.estimates(fit.BAM, dat)
BAM2.est <- get.estimates(fit.BAM2, dat)
AMx.est <- get.estimates(fit.AMx, dat)

####################################################################################################
# Figure 2. Party position plot:
UK.ppos <- as.data.frame(cbind(rep("UK", 8), c(1:8), BAM.est$theta, ISR.est$theta))
colnames(UK.ppos) <- c("c", "party", "BAM.lo", "BAM.med", "BAM.hi%", "BAM.mean", 
  "ISR.lo", "ISR.med", "ISR.hi%", "ISR.mean")
colnames(ches.codes)[1:2] <- c("c", "party")
colnames(ches.dta)[1] <- "ches_id"
ppos.full <- merge(UK.ppos, ches.codes, by = c("c", "party"))
ppos.full <- merge(ppos.full, ches.dta, by = "ches_id")
ppos.full$mean.lo <- ppos.full$mean - (2 * ppos.full$se)
ppos.full$mean.hi <- ppos.full$mean + (2 * ppos.full$se)
EES.UK.names <- c("Lab", "Con", "Lib", "SNP", "Plaid", "UKIP", "BNP", "Green")
EES.to.CHES <- c(2, 1, 3, 4, 5, 8, 6, 7)

pdf("figures/figure_2.pdf", width = 10, height = 5)
  xlims <- c(-5, 5)
  par(mfrow = c(1, 2))
  par(cex = 1.0)
  par(mar = c(4.1, 4.1, 1.1, 1.1))
  par(mgp = c(2.5, 1, 0))
  country <- "UK"
  d.c <- ppos.full[ppos.full$c == country, ]
  d.c$party.name <- c("Con", "Lab", "Lib", "SNP", "Plaid", "Green", "UKIP", "BNP")
  n.ch <- nchar(d.c$party.name)
  
  # First panel:  
  adj.x <- .35
  adj.y <- .04
  ylims <- c(-1, 1)
  plot(d.c$mean, d.c$BAM.med, type = "n", axes = F, ylim = ylims * 1.02, xlim = xlims, ylab = "BAM Estimate", xlab = "Expert Survey Average")
  abline(v = 0, lty = 1, col = "gray90")
  abline(h = 0, lty = 1, col = "gray90")
  fit <- lm(d.c$BAM.med ~ d.c$mean); abline(fit, lty = 2, col = "gray60")
  arrows(d.c$mean.lo, d.c$BAM.med, d.c$mean.hi, d.c$BAM.med, length = 0, col = pal.2[2], lwd = 1.75)
  arrows(d.c$mean, d.c$BAM.lo, d.c$mean, d.c$BAM.hi, length = 0, col = pal.2[2], lwd = 1.75)
  points(d.c$mean, d.c$BAM.med, pch = 19, cex = .7, col = pal.2[6])
  xs <- d.c$mean-adj.x - ((n.ch-3) * .05)
  ys <- d.c$BAM.med + adj.y
  text(xs, ys, d.c$party.name, cex = .7)
  axis(1, at = c(-5, -2.5, 0, 2.5, 5))
  axis(2, at = pretty(ylims))
  
  # Second panel:
  ylims <- c(-2, 2)
  adj.y <- .08
  plot(d.c$mean, d.c$ISR.med, type = "n", axes = F, ylim = ylims, xlim = xlims, ylab = "ISR Estimate", xlab = "Expert Survey Average")
  abline(v = 0, lty = 1, col = "gray90")
  abline(h = 0, lty = 1, col = "gray90")
  fit <- lm(d.c$ISR.med ~ d.c$mean)
  abline(fit, lty = 2, col = "gray60")
  arrows(d.c$mean.lo, d.c$ISR.med, d.c$mean.hi, d.c$ISR.med, length = 0, col = pal.2[2], lwd = 1.75)
  arrows(d.c$mean, d.c$ISR.lo, d.c$mean, d.c$ISR.hi, length = 0, col = pal.2[2], lwd = 1.75)
  points(d.c$mean, d.c$ISR.med, pch = 19, cex = .7, col = pal.2[6])
  xs <- d.c$mean-adj.x - ((n.ch - 3) * .05)
  ys <- d.c$ISR.med + adj.y
  ys[5] <- d.c$ISR.med[5] - adj.y
  xs[5] <- d.c$mean[5] + adj.x + .03
  axis(1, at = c(-5, -2.5, 0, 2.5, 5))
  axis(2, at = pretty(ylims))
  text(xs, ys, d.c$party.name, cex = .7)
dev.off()

####################################################################################################
# Figure 3. Voter correlation plot with 3 models:
d <- cbind(ISR.est$vpos[, 2], BAM.est$vpos[, 2], fit.AM$respondents[, 3])
colnames(d) <- c("ISR", "BAM", "AM")

new.xlim <- array(0, dim = c(3, 3, 2))
new.xlim[, , 1] <- -6
new.xlim[2, , 1] <- -4
new.xlim[3, , 1] <- -2.5
new.xlim[, , 2] <- 6
new.xlim[2, , 2] <- 4
new.xlim[3, , 2] <- 2.5
new.ylim = new.xlim
new.ylim[, , 1] = t(new.ylim[, , 1])
new.ylim[, , 2] = t(new.ylim[, , 2])

cairo_pdf(file = "figures/figure_3.pdf", onefile = F, width = 10, height = 6.75, family = "Helvetica", fallback_resolution = 600) 
  new.pairs(d, pch = 16, oma = rep(2.1, 4), col = pal.2.t[5], xlim = new.xlim, ylim = new.ylim, 
    diag.panel = panel.dens, upper.panel = panel.cor, cex.labels = 1.6)
dev.off()

####################################################################################################
# Figure 4. Rationalization plot:
gamma.samples.ISR <- extract(fit.ISR, pars = "gamma")[[1]]
beta.samples.ISR <- extract(fit.ISR, pars = "beta")[[1]]
alpha.samples.ISR <- extract(fit.ISR, pars = "alpha")[[1]]  

# Number of original draws:
n.1 <- nrow(gamma.samples.ISR)
# Number of desired draws:
n.2 <- 100
# Reduce number of draws:
set.seed(123)
use <- sample(1:1500, n.2)

gamma.samples.ISR <- gamma.samples.ISR[use, ]
beta.samples.ISR <- beta.samples.ISR[use, ]
alpha.samples.ISR <- alpha.samples.ISR[use, ]
vpos.samples.ISR <- (rep(dat$V, each = nrow(alpha.samples.ISR)) - alpha.samples.ISR) / beta.samples.ISR

cairo_pdf(file = "figures/figure_4.pdf", onefile = F, width = 7, height = 4.5, family = "Helvetica", fallback_resolution = 600)
  par(mar = c(4.1, 4.1, 1.1, 1.1), mgp = c(2.5, 1, 0)) 
  plot(0, 0, ylim = c(-5, 5), xlim = c(0, 1), axes = F, 
  	ylab = "Estimated Rationalization, ISR", xlab = "Voter Self-Placement", type = "n")
  for (s in 1:n.2) {
    dat.2 <- cbind.data.frame(as.numeric(gamma.samples.ISR[s, ]), dat$V)
    colnames(dat.2) <- c("rat", "vpos")
    # Logit-transform the data to better represent the central tendency:
    dat.2$rat <- log(dat.2$rat / (1 - dat.2$rat))
    fit <- gam(dat.2$rat~s(dat.2$vpos, fx = TRUE, k = 6, bs = "cr"))
    par(new = T)
    # Plot using logistic transformation back to original scale:
    plot(fit, shift = fit$coefficients[1], trans = function(x) exp(x)/(1 + exp(x)), rug = F, se = F, axes = F, xlab = "", ylab = "", ylim = c(0, 1), xlim = c(-5, 5), col = pal.2.t[5])
  }
  axis(1, at = c(-5, -2.5, 0, 2.5, 5)); axis(2)
dev.off()

####################################################################################################
# Figure S3. Voter correlation plot with 4 models:
d <- cbind(ISR.est$vpos[, 2], BAM.est$vpos[, 2], BAM2.est$vpos[, 2], fit.AM$respondents[, 3])
colnames(d) <- c("ISR", "BAM", "BAM2", "AM")

new.xlim <- array(0, dim = c(4, 4, 2))
new.xlim[ , , 1] <- -6
new.xlim[2, , 1] <- -4
new.xlim[3, , 1] <- -6
new.xlim[4, , 1] <- -2.5
new.xlim[ , , 2] <- 6
new.xlim[2, , 2] <- 4
new.xlim[3, , 2] <- 6
new.xlim[4, , 2] <- 2.5
new.ylim = new.xlim
new.ylim[ , , 1] = t(new.ylim[ , , 1])
new.ylim[ , , 2] = t(new.ylim[ , , 2])

cairo_pdf(file = "figures/figure_S3.pdf", onefile = F, width = 10, height = 6.75, family = "Helvetica", fallback_resolution = 600) 
  new.pairs(d, pch = 16, oma = rep(2.1, 4), col = pal.2.t[5], xlim = new.xlim, ylim = new.ylim, 
    diag.panel = panel.dens, upper.panel = panel.cor, cex.labels = 1.6)
dev.off()

####################################################################################################
# Figures S5, S6, S7, S8. Traceplots for theta:
traceplot(fit.AMx, pars = "theta", alpha = .5) + theme(legend.position = "bottom") + scale_colour_discrete() + 
  guides(colour = guide_legend(override.aes = list(alpha = 1)))
ggsave("figures/figure_S5.pdf", width = 8.5, height = 7)

traceplot(fit.BAM, pars = "theta", alpha = .5) + theme(legend.position = "bottom") + scale_colour_discrete() + 
  guides(colour = guide_legend(override.aes = list(alpha = 1)))
ggsave("figures/figure_S6.pdf", width = 8.5, height = 7)

traceplot(fit.BAM2, pars = "theta", alpha = .5) + theme(legend.position = "bottom") + scale_colour_discrete() + 
  guides(colour = guide_legend(override.aes = list(alpha = 1)))
ggsave("figures/figure_S7.pdf", width = 8.5, height = 7)

traceplot(fit.ISR, pars = "theta", alpha = .5) + theme(legend.position = "bottom") + scale_colour_discrete() + 
  guides(colour = guide_legend(override.aes = list(alpha = 1)))
ggsave("figures/figure_S8.pdf", width = 8.5, height = 7)
