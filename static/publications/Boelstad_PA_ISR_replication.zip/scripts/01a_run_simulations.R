library("rstan")
library("basicspace")

source("scripts/functions_create_data.R")
source("scripts/functions_general.R")

load("models/compiled_models.R")

# For seed-comparability with R versions >= 3.6:
if ((version$major == "3" & as.numeric(version$minor) >= 6.0) | as.numeric(version$major) > 3) {RNGkind(sample.kind = "Rounding")} 

# Function to run simulations:
run.sims <- function(ntrials = 5, N = 500, J = 8, B = 5, het = T, gvals = list(c(0, 1), c(1, 3), c(1, 1)), nu, ppos.sd) {
  results.full <- vector()
  iter <- 0
  for (i in 1:ntrials) {
    for (gs in gvals) { 
      ptm.it <- proc.time() 
      dat <<- create.data(hetero = het, N = N, J = J, B = B, gs = gs, p.sd = 1, nu = nu, ppos.sd = ppos.sd)
      chains = 3; it = 1000; warm = 500; samples = 1500
      thin <- round((it - warm)/(samples/chains))
      
      mod1.fit <- aldmck(as.data.frame(cbind(dat$V, dat$Y)), respondent = 1, polarity = (1 + dat$L))
      
      ptm <- proc.time()
      mod2.fit <- sampling(object = m.BAM, init = inits.BAM, data = dat, chains = chains, cores = chains,
        algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
      t.mod2 <- (proc.time() - ptm)[[3]]
      
      ptm <- proc.time()
      mod3.fit <- sampling(object = m.BAM2, init = inits.2, data = dat, chains = chains, cores = chains,
        algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
      t.mod3 <- (proc.time() - ptm)[[3]]
      
      ptm <- proc.time()
      mod4.fit <- sampling(object = m.ISR, init = inits.2, data = dat, chains = chains, cores = chains,
        algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
      t.mod4 <- (proc.time() - ptm)[[3]]

      mod1.est <- get.estimates(mod1.fit, dat)
      mod2.est <- get.estimates(mod2.fit, dat)
      mod3.est <- get.estimates(mod3.fit, dat)
      mod4.est <- get.estimates(mod4.fit, dat)

      true.prox <- abs(dat$true.mu0 - dat$V)
      raw.prox <- abs(dat$Y - dat$V)
      
      mod1.prox <- abs(matrix(rep(mod1.est$theta, each = N), nrow = N, ncol = J) - mod1.est$vpos)
      mod2.prox <- abs(matrix(rep(mod2.est$theta[, 4], each = N), nrow = N, ncol = J) - mod2.est$vpos[, 2])
      mod3.prox <- abs(matrix(rep(mod3.est$theta[, 4], each = N), nrow = N, ncol = J) - mod3.est$vpos[, 2])
      mod4.prox <- abs(matrix(rep(mod4.est$theta[, 4], each = N), nrow = N, ncol = J) - mod4.est$vpos[, 2])
      
      true.cor <- get.prox.cor(N, dat$U, true.prox)
      raw.cor <- get.prox.cor(N, dat$U, raw.prox)
      mod1.cor <- get.prox.cor(N, dat$U, mod1.prox)
      mod2.cor <- get.prox.cor(N, dat$U, mod2.prox)
      mod3.cor <- get.prox.cor(N, dat$U, mod3.prox)
      mod4.cor <- get.prox.cor(N, dat$U, mod4.prox)
  
      prox.bias.raw <- - mean(raw.cor - true.cor, na.rm = T)
      prox.bias.mod1 <- - mean(mod1.cor - true.cor, na.rm = T)
      prox.bias.mod2 <- - mean(mod2.cor - true.cor)
      prox.bias.mod3 <- - mean(mod3.cor - true.cor)
      prox.bias.mod4 <- - mean(mod4.cor - true.cor)
  
      prox.RMSE.raw <- sqrt(mean((true.cor - raw.cor)^2, na.rm = T))
      prox.RMSE.mod1 <- sqrt(mean((true.cor - mod1.cor)^2, na.rm = T))
      prox.RMSE.mod2 <- sqrt(mean((true.cor - mod2.cor)^2))
      prox.RMSE.mod3 <- sqrt(mean((true.cor - mod3.cor)^2))
      prox.RMSE.mod4 <- sqrt(mean((true.cor - mod4.cor)^2))

      results <- c(N, J, gs, (iter + 1), cor(dat$mean.ppos, dat$true.theta), 
        cor(mod1.est$theta, dat$true.theta), cor(mod2.est$theta[, 4], dat$true.theta), 
        cor(mod3.est$theta[, 4], dat$true.theta), cor(mod4.est$theta[, 4], dat$true.theta), 
        cor(mod1.est$vpos, dat$true.self, use = "complete.obs"), cor(mod2.est$vpos[, 2], dat$true.self), 
        cor(mod3.est$vpos[, 2], dat$true.self), cor(mod4.est$vpos[, 2], dat$true.self), 
        mean(- true.cor, na.rm = T), 
        prox.bias.raw, prox.bias.mod1, prox.bias.mod2, prox.bias.mod3, prox.bias.mod4, 
        prox.RMSE.raw, prox.RMSE.mod1, prox.RMSE.mod2, prox.RMSE.mod3, prox.RMSE.mod4, 
        sqrt(mean((mod4.est$gamma - dat$true.gamma)^2)), 
        mean(mod4.est$gamma - dat$true.gamma), 
        max(summary(mod2.fit, pars = c("alpha", "beta", "theta"))$summary[, 10]), 
        max(summary(mod3.fit, pars = c("alpha", "beta", "theta"))$summary[, 10]), 
        max(summary(mod4.fit, pars = c("alpha", "beta", "theta", "gamma"))$summary[, 10]), 
        min(summary(mod2.fit, pars = c("alpha", "beta", "theta"))$summary[, 9]), 
        min(summary(mod3.fit, pars = c("alpha", "beta", "theta"))$summary[, 9]), 
        min(summary(mod4.fit, pars = c("alpha", "beta", "theta", "gamma"))$summary[, 9]), 
        t.mod2, t.mod3, t.mod4, (proc.time() - ptm.it)[[3]])
      results.full <- rbind(results.full, results)
      iter <- iter + 1
      print(paste(format(round(iter/(length(gvals)*ntrials)*100, 2), nsmall = 2), "% of simulations done, at ", date(), sep = ""))  
    }
    if (i %in% (c(1:100)*25)) {save("results.full", file = "results_temp.R")}
  }
  rownames(results.full) <- NULL
  results.full <- as.data.frame(results.full)
  colnames(results.full) <- c("N", "J", "g.a", "g.b", "iter", "cor.mean.ppos", 
    "ppos.mod1", "ppos.mod2", "ppos.mod3", "ppos.mod4", "vpos.mod1", "vpos.mod2", "vpos.mod3", "vpos.mod4", 
    "true.cor", "prox.bias.raw", "prox.bias.mod1", "prox.bias.mod2", "prox.bias.mod3", "prox.bias.mod4", 
    "prox.RMSE.raw", "prox.RMSE.mod1", "prox.RMSE.mod2", "prox.RMSE.mod3", "prox.RMSE.mod4", 
    "mod4.gamma.RMSE", "mod4.gamma.bias", "rhat.mod2", "rhat.mod3", "rhat.mod4", 
    "neff.mod2", "neff.mod3", "neff.mod4", "time.mod2", "time.mod3", "time.mod4", "time.it")
  return(results.full)
}

# Note: The warm-up period has been kept short to save computation time. There are occasional warnings of 
# a few divergent transitions, which appear to be false positives that disappear when setting adapt_delta
# closer to 1, e.g. "sampling(.., control = list(adapt_delta = 0.99))". This is not done as a default here, 
# as it gives slower sampling, and the simulations already take a significant amount of time.

# Run first set of simulations
set.seed(123)
results <- run.sims(ntrials = 200, nu = 8, ppos.sd = .5)
save(list = c("results"), file = "results/results_simulations_1.R")

# Run second set of simulations
set.seed(1234)
results <- run.sims(ntrials = 200, nu = 3, ppos.sd = 1.4)
save(list = c("results"), file = "results/results_simulations_2.R")
