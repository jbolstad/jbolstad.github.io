source("scripts/functions_plotting.R")

simplots.1 <- function(fil, labs, xlabs) {
  load(file = paste(fil, ".R", sep = ""))
  r <- as.data.frame(results)
  r <- r[complete.cases(cbind(r$rhat.mod2, r$rhat.mod3, r$rhat.mod4)), ]
  keep.1 <- apply(cbind(r$neff.mod2, r$neff.mod3, r$neff.mod4), 1, function(x) {min(x) > 25})
  keep.2 <- apply(cbind(r$rhat.mod2, r$rhat.mod3, r$rhat.mod4), 1, function(x) {max(x) < 1.15})
  
  r <- r[keep.1 & keep.2, ]
  
  r$t <- interaction(as.factor(r$g.a), as.factor(r$g.b))
  r$t <- ordered(r$t, unique(as.character(r$t)))
  ind <<- r$t
  
  ylims <- c(0, 1)
  
  m.boxplot4(l.placement = "bottomright", y = cbind(r$ppos.mod1, r$ppos.mod2, r$ppos.mod3, r$ppos.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "Rationalization", ylab = "", xlabs = xlabs, 
             title = "Stimuli Positions", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = T, xlabfac = (4 / 3)) 
  
  m.boxplot4(y = cbind(r$vpos.mod1, r$vpos.mod2, r$vpos.mod3, r$vpos.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "Rationalization", ylab = "", xlabs = xlabs, 
             title = "Voter Positions", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = F, xlabfac = (4 / 3)) 
}

simplots.2 <- function(fil, labs, xlabs) {
  load(file = paste(fil, ".R", sep = ""))
  r <- as.data.frame(results)
  r <- r[complete.cases(cbind(r$rhat.mod2, r$rhat.mod3, r$rhat.mod4)), ]
  
  keep.1 <- apply(cbind(r$neff.mod2, r$neff.mod3, r$neff.mod4), 1, function(x) {min(x) > 25})
  keep.2 <- apply(cbind(r$rhat.mod2, r$rhat.mod3, r$rhat.mod4), 1, function(x) {max(x) < 1.15})
  
  print(sum(keep.1))
  print(sum(keep.1) / nrow(results))
  print(sum(keep.2))
  print(sum(keep.2) / nrow(results))
  print(sum(keep.1 & keep.2) / nrow(results))
  
  r <- r[keep.1 & keep.2, ]
  
  r$t <- interaction(as.factor(r$g.a), as.factor(r$g.b))
  r$t <- ordered(r$t, unique(as.character(r$t)))
  ind <<- r$t
  
  ylims <- c(-0.09, 1)
  
  m.boxplot4(l.placement = "bottomright", y = cbind(r$ppos.mod1, r$ppos.mod2, r$ppos.mod3, r$ppos.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "", ylab = "", xlabs = xlabs, 
             title = "Stimuli Positions, r", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = T) 
  
  m.boxplot4(y = cbind(r$vpos.mod1, r$vpos.mod2, r$vpos.mod3, r$vpos.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "", ylab = "", xlabs = xlabs, 
             title = "Voter Positions, r", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = F) 
  
  m.boxplot4(y = cbind(r$prox.bias.mod1, r$prox.bias.mod2, r$prox.bias.mod3, r$prox.bias.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "", ylab = "", xlabs = xlabs, 
             title = "Proximity, bias", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = F) 
  
  m.boxplot1(l.placement = "topright", y = cbind(r$mod4.gamma.bias), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "", ylab = "", xlabs = xlabs, 
             title = "Gamma, bias (ISR)", labels = "ISR", ind = r$t, showprob = 1, x.add = .18, plotleg = F) 
  
  m.boxplot4(l.placement = "topright", y = cbind(r$prox.RMSE.mod1, r$prox.RMSE.mod2, r$prox.RMSE.mod3, r$prox.RMSE.mod4), 
             ylims = ylims, yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "Rationalization", ylab = "", 
             xlabs = xlabs, title = "Proximity, RMSE", labels = labs, ind = r$t, showprob = 1, x.add = .18, plotleg = F) 
  
  m.boxplot1(l.placement = "topright", y = cbind(r$mod4.gamma.RMSE), ylims = ylims, 
             yaxs = pretty(round(ylims)), ylines = pretty(round(ylims)), xlab = "Rationalization", ylab = "", xlabs = xlabs, 
             title = "Gamma, RMSE (ISR)", labels = c("ISR"), ind = r$t, showprob = 1, x.add = .18, plotleg = F) 
}

labs <- c("AM", "BAM", "BAM2", "ISR")
xlabs <- c(0, .25, .5)

cairo_pdf(file = "figures/figure_1.pdf", onefile = F, width = 10, height = 4.5, 
          family = "Helvetica", fallback_resolution = 600) 
par(mfrow = c(1, 2), oma = c(1.3, .2, 0, 0), mar = c(2.9, 2.1, 2.1, 1.1), mgp = c(2.5, 1, 0))
simplots.1(fil = "results/results_simulations_1", labs, xlabs)
dev.off()

cairo_pdf(file = "figures/figure_S1.pdf", onefile = F, width = 7, height = 8, 
          family = "Helvetica", fallback_resolution = 600) 
par(mfrow = c(3, 2), oma = c(1.3, .2, 0, 0), mar = c(2.9, 2.1, 2.1, 1.1), mgp = c(2.5, 1, 0))
simplots.2(fil = "results/results_simulations_1", labs, xlabs)
dev.off()

cairo_pdf(file = "figures/figure_S2.pdf", onefile = F, width = 7, height = 8, 
          family = "Helvetica", fallback_resolution = 600) 
par(mfrow = c(3, 2), oma = c(1.3, .2, 0, 0), mar = c(2.9, 2.1, 2.1, 1.1), mgp = c(2.5, 1, 0))
simplots.2(fil = "results/results_simulations_2", labs, xlabs)
dev.off()
