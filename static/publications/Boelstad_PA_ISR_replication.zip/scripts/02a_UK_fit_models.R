# Note: This code saves models that require about 550MB of space.

library(rstan)
library(basicspace)

source("scripts/functions_general.R")

load("models/compiled_models.R")
load("data/data_EES.R")

dat <- get.EES.data(data.all, "UK")
dat <- prep.data(dat$self, dat$ppos, dat$prefs, allow.miss = 0, req.only.Y = T)
dat$M1 <- dat$M

# For seed-comparability with future versions of R:
if ((version$major == "3" & as.numeric(version$minor) >=  6.0) | as.numeric(version$major) > 3) {RNGkind(sample.kind = "Rounding")} 
# Set seed for inits
set.seed(123)

chains <- 3; it <- 2000; warm <- 500; samples <- 1500
thin <- round((it - warm) / (samples / chains))

# Fit ISR:
ptm <- proc.time()
fit.ISR <- sampling(object = m.ISR, init = inits.2, data = dat, chains = chains, cores = chains, 
  algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
t <- (proc.time() - ptm)[[3]]; print(paste("NUTS finished ISR at: ", date(), ". Time spent: ", round(t), "s.", sep = ""))  
save(list = c("fit.ISR"), file = "results/ISR_fit_UK_N536.R")

# The data selection is exacly similar to Lo et al., which does not take missing on preferences into account, 
# while the M matrix does. The BAM model needs to use all the data to avoid sampling problems:
dat$M[dat$M == 1] = 0

# Fit BAM:
ptm <- proc.time()
fit.BAM <- sampling(object = m.BAM, init = inits.BAM, data = dat, chains = chains, cores = chains, 
  algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
t <- (proc.time() - ptm)[[3]]; print(paste("NUTS finished BAM at: ", date(), ". Time spent: ", round(t), "s.", sep = ""))  
save(list = c("fit.BAM"), file = "results/BAM_fit_UK_N536.R")

# Fit BAM2:
ptm <- proc.time()
fit.BAM2 <- sampling(object = m.BAM2, init = inits.2, data = dat, chains = chains, cores = chains, 
  algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
t <- (proc.time() - ptm)[[3]]; print(paste("NUTS finished BAM2 at: ", date(), ". Time spent: ", round(t), "s.", sep = ""))  
save(list = c("fit.BAM2"), file = "results/BAM2_fit_UK_N536.R")

# The AM model does not have a right-pole, while the BAM model does. The goal of fitting the homoskedastic BAM
# model is to fit a Bayesian model with results that closely resemble the AM model. Setting the rigthmost 
# party in the CHES data as the right pole achieves this:
dat$R <- 7 

# Fit AM* / homoskedastic BAM:
ptm <- proc.time()
fit.AMx <- sampling(object = m.BAM.homosk, init = inits.BAM, data = dat, chains = chains, cores = chains, 
  algorithm = "NUTS", warmup = warm, iter = it, thin = thin, seed = 123)
t <- (proc.time() - ptm)[[3]]; print(paste("NUTS finished AM at: ", date(), ". Time spent: ", round(t), "s.", sep = ""))  
save(list = c("fit.AMx"), file = "results/AMx_fit_UK_N536.R")

# Fit AM:
fit.AM <- aldmck(as.data.frame(cbind(dat$V, dat$Y)), respondent = 1, polarity = (1 + which.min(dat$mean.ppos)))
save(list = c("fit.AM"), file = "results/AM_fit_UK_N536.R")	
