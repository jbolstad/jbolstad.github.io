inits.BAM <- function() {list (theta = dat$mean.ppos + rnorm(dat$J, 0, (dat$B / 5) * 0.25), beta = rnorm(dat$N, 1, .5), thetal = -1.05, thetar = 1.05)}

inits.2 <- function() {list (theta = dat$mean.ppos + rnorm(dat$J, 0, (dat$B / 5) * 0.25), 
                               beta = rnorm(dat$N, 1, .5), nu = 1 + rinvchisq(1, 30, 5), tau = rinvchisq(1, 30, 1.2 * dat$J),
                               eta = rinvchisq(dat$N, 10, dat$J^2 * 1.2^2), lambda = rinvchisq(1, 50, dat$B / 5))}

# Function to draw from an inverse Chi-square distribution (source: GeoR package):
rinvchisq <- function(n, df, scale = 1/df) {
  if ((length(scale) != 1) & (length(scale) != n)) 
    stop("scale should be a scalar or a vector of the same length as x")
  if (df <= 0) 
    stop("df must be greater than zero")
  if (any(scale <= 0)) 
    stop("scale must be greater than zero")
  return((df * scale) / rchisq(n, df = df))
}

# Extracting relevant EES data for a given country:
get.EES.data <- function(data.all, country, m.n.p = 14) {
  data <- data.all[data.all$t101b == country,]
  
  # Find number of available parties and subset data:
  use <- vector()
  for (i in 1:m.n.p) {if (!is.na(mean(data[, (i + 1)], na.rm = T))) {use <- c(use, i)}}
  n.p <- length(use)
  data <- data[, c(1, c((1:m.n.p) + 1)[use], c((1:m.n.p) + (m.n.p + 1))[use])]
  
  self <- data[, 1]
  ppos <- data[, c((1 + 1):(1 + n.p))]
  prefs <- data[, c((1 + 1 + n.p):(1 + n.p + n.p))]
  
  return(list(self = self,ppos = ppos,prefs = prefs,use = use))
}

# Applying selection criteria and creating an object containing everything needed for sampling:
prep.data <- function(self, ppos, prefs, allow.miss = 1, req.only.Y = F) {
  prefs <- prefs / max(prefs, na.rm = T)
  
  # Rescale preferences to range from 0 to 1 per for each individual:
  suppressWarnings(pref.min <- apply(prefs, 1, min, na.rm = T))
  suppressWarnings(pref.max <- apply(prefs, 1, max, na.rm = T))
  sel <- pref.min != pref.max
  prefs[sel,] <- (prefs[sel,] - pref.min[sel]) / (pref.max[sel] - pref.min[sel])
  
  # Indicators of non-constant data for each respondent:
  has.ppos.var <- apply(ppos, 1, var, na.rm = T) > 0
  has.var <- apply(prefs, 1, var, na.rm = T) > 0 & apply(ppos, 1, var, na.rm = T) > 0
  
  # Which observations are missing either prefs or positions:
  is.any.na <- apply((is.na(prefs) | is.na(ppos)), 2, as.numeric)
  
  # Counting number of unique positions reported per responent:
  unq <- function(x) {length(unique(x[!is.na(x)]))}
  n.unique <- apply(cbind(ppos, self), 1, unq)
  
  # This selection with allow.miss set to 0 matches what Lo et al. used:
  if (req.only.Y) {keep <- !is.na(self) & apply(is.na(ppos), 1, sum) <=  allow.miss & has.ppos.var} 
  # This also considers missing preferences and requires respondents to use 3 unique placements:
  else {keep <- !is.na(self) & apply(is.any.na, 1, sum) <= allow.miss & has.var & n.unique >= 3}
  
  M <- is.any.na[keep,]
  
  prefs <- prefs[keep,]; ppos <- ppos[keep,]; self <- self[keep]
  
  mean.ppos <- apply(ppos, 2, mean, na.rm = T)
  
  # Pre-processing because Stan does not accept NA:
  prefs.na <- prefs; prefs.na[is.na(prefs.na)] <- 0
  ppos.na <- ppos; ppos.na[is.na(ppos.na)] <- 0
  
  return(list(J = ncol(ppos), N = nrow(ppos), B = max(ppos, na.rm = T), V = self, Y = as.matrix(ppos.na), 
              U = as.matrix(prefs.na), M = M, L = which.min(mean.ppos), R = which.max(mean.ppos), mean.ppos = mean.ppos, keep = keep))  
}

# Get median and mean estimates with credible intervals:
get.CIs <- function(d) { 
  out <- cbind(rbind(quantile(d, probs = c(0.025, 0.5, 0.975), na.rm = T)), mean(d, na.rm = T))
  colnames(out) <- c("2.5%", "50%", "97.5%", "mean")
  return(out)
}

apply.get.CIs <- function(d) { 
  out <- as.data.frame(t(apply(d, 2, get.CIs)))
  colnames(out) <- c("2.5%", "50%", "97.5%", "mean")
  return(out)
}

# Silverman's bandwidth:
silverman.bw <- function(x) {
  qs <- quantile(x, c(.25, .75))
  IQR <- qs[2] - qs[1]
  .9 * min(sd(x), IQR / 1.349) * (length(x)^-.2)
}

# Calculate density with Silverman's bandwidth and reflection at bounds:
refl.density <- function(x, n2 = 500) {
  n1 <- (n2 * 3) + 1
  x1 <- seq(-1, 2, by = (1 / n2))
  x2 <- x1[(n2 + 1):((2 * n2) + 1)]
  s.bw <- silverman.bw(x)
  x.r <- c(-x, x, (-x + 2))
  y1 <- density(x.r, from = -1, to = 2, n = n1, bw = s.bw, na.rm = T)$y
  y2 <- 3 * y1[(n2 + 1):((2 * n2) + 1)]
  return(list(x = x2, y = y2))
}

# Get posterior mode estimate:
get.post.mode <- function(d) {dd <- refl.density(d); dd$x[which.max(dd$y)]}

# Extract estimates from AM/BAM/ISR object:
get.estimates <- function(fit, d) {
  if (class(fit) == "stanfit") {
    theta.samples <- extract(fit, pars = "theta")[[1]]
    theta <- apply.get.CIs(theta.samples)
    beta.samples <- extract(fit, pars = "beta")[[1]]
    beta <- apply.get.CIs(beta.samples)
    alpha.samples <- extract(fit, pars = "alpha")[[1]]  
    alpha <- apply.get.CIs(alpha.samples)
    vpos.samples <- (rep(d$V, each = nrow(alpha.samples)) - alpha.samples) / beta.samples
    vpos <- apply.get.CIs(vpos.samples)
    if ("gamma" %in% fit@model_pars) {
      gamma.samples <- extract(fit, pars = "gamma")[[1]]
      gamma.CI <- apply.get.CIs(gamma.samples)
      gamma <- gamma.CI[, 2]
      if (mean(gamma) < .15 | mean(gamma) > .85) {gamma <- apply(gamma.samples, 2, get.post.mode)}
      out <- list(alpha = alpha, beta = beta, vpos = vpos, theta = theta, gamma.CI = gamma.CI, gamma = gamma)}
    else {out <- list(alpha = alpha, beta = beta, vpos = vpos, theta = theta)}
  }
  if (class(fit) == "aldmck") {
    alpha = - fit$respondents[, 1]
    beta = fit$respondents[, 2]
    vpos = fit$respondents[, 3]
    theta = fit$stimuli
    out <- list(alpha = alpha, beta = beta, vpos = vpos, theta = theta)
  }
  return(out)
}

# Extract likelihood from stanfit object:
get.lik <- function(obj, M) {
  lik <- extract(obj, pars = "log_lik")$log_lik
  dim(lik)<- c(dim(lik)[1], dim(lik)[2] * dim(lik)[3])
  lik <- lik[, !as.vector(as.logical(M))]
  lik <- exp(lik)
  return(lik)
}

# Calculate WAIC from pointwise likelihood:
WAIC <- function(lik) {
  lppd <- sum(log(colMeans(lik)))
  log_lik <- log(lik)
  n <- dim(log_lik)[1]
  pWAIC2 <- sum((colMeans(log_lik^2) - colMeans(log_lik)^2)) * n / (n - 1)
  return(-2 * (lppd - pWAIC2))
}

# Get proximity correlations:
get.prox.cor <- function(N, U, prox) {
  prox.cor <- vector(length = N)
  for (i in 1:N) {
    prox.cor[i] <- NA
    if (sum(!is.na(U[i, ])) > 3 & sum(!is.na(prox[i, ])) > 3) {
      if (sd(U[i, ], na.rm = T) > 0 & sd(prox[i, ], na.rm = T) > 0) {
        prox.cor[i] <- cor(as.numeric(U[i, ]), as.numeric(prox[i, ]))
      }
    }
  }
  return(prox.cor)
}
