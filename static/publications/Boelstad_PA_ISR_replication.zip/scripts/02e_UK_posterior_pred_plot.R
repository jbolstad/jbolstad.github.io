source("scripts/functions_general.R")
source("scripts/functions_plotting.R")
source("scripts/functions_plot_legends.R")

load("results/UK_Yhats.R")
load("data/data_EES.R")
ches.dta <- read.csv("data/data_CHES.csv")
ches.codes <- read.csv("data/data_EES_CHES_codes.csv")

dat <- get.EES.data(data.all, "UK")
dat <- prep.data(dat$self, dat$ppos, dat$prefs, allow.miss = 0, req.only.Y = T)

n.2 <- length(Yhat.ISR)

EES.UK.names <- c("Labour", "Cons", "Lib Dems", "SNP", "Plaid", "UKIP", "BNP", "Green")

# Merging different party position estimates:
UK.ppos <- as.data.frame(cbind(rep("UK", 8), c(1:8), theta.est.BAM, theta.est.ISR))
colnames(UK.ppos) <- c("c", "party", "BAM.lo", "BAM.med", "BAM.hi", "BAM.mean", "ISR.lo", "ISR.med", "ISR.hi", "ISR.mean")
colnames(ches.codes)[1:2] <- c("c", "party")
colnames(ches.dta)[1] <- "ches_id"
ppos.full <- merge(UK.ppos, ches.codes, by = c("c", "party"))
ppos.full <- merge(ppos.full, ches.dta, by = "ches_id")
from.leftmost <- ppos.full$party[order(ppos.full$mean)]

# Rescaled & ordered CHES means:
CHES.to.EES <- order(ppos.full$party)
means <- ppos.full$mean[CHES.to.EES]
means <- (means - min(means)) / max((means - min(means)))
means <- (means * 4) - 2

# Logical vector identifying respondents with non-constant data:
dat$U[dat$M == 1] <- NA; dat$Y[dat$M == 1] <- NA
has.var <- apply(dat$U, 1, var, na.rm = T) > 0 & apply(dat$Y, 1, var, na.rm = T) > 0
# Logical matrices identifying preferences above and below thresholds:
high.which <- t(apply(dat$U, 1, function(x) x >=  .5))
low.which <- t(apply(dat$U, 1, function(x) x <.5))

####################################################################################################
# Figure 5:
plot.PP.dens <- function(party.n, supp, left, prob) {
  if (supp == T) {
    if (left == T) {use <- has.var & high.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V < 0} 
    else {use <- has.var & high.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V > 0}
  } 
  else {
    if (left == T) {use <- has.var & low.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V < 0} 
    else {use <- has.var & low.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V > 0}
  }

  mean.AMx <- vector()
  for (s in 1:n.2) {mean.AMx <- c(mean.AMx, mean(Yhat.AMx[[s]][use, party.n], na.rm = T))}  
  mean.BAM <- vector()
  for (s in 1:n.2) {mean.BAM <- c(mean.BAM, mean(Yhat.BAM[[s]][use, party.n], na.rm = T))}
  mean.ISR <- vector()
  for (s in 1:n.2) {mean.ISR <- c(mean.ISR, mean(Yhat.ISR[[s]][use, party.n], na.rm = T))}
  
  mean.y <- mean(dat$Y[use, party.n], na.rm = T)

  if ((mean.y < 0) == (mean(mean.AMx) < 0)) {same.side.AMx <<- same.side.AMx + 1}
  if ((mean.y < 0) == (mean(mean.BAM) < 0)) {same.side.BAM <<- same.side.BAM + 1}
  if ((mean.y < 0) == (mean(mean.ISR) < 0)) {same.side.ISR <<- same.side.ISR + 1}

  AMx.dens <- density(mean.AMx, na.rm = T); BAM.dens <- density(mean.BAM, na.rm = T); ISR.dens <- density(mean.ISR, na.rm = T)
  
  xlims = c(-3, 3); ylims = c(0, 1.025 * max(max(AMx.dens$y), max(BAM.dens$y), max(ISR.dens$y)))
  
  plot(BAM.dens, ylim = ylims, xlim = xlims, type = "n", axes = F, main = "", xlab = "Party Placement", xaxs = "i", yaxs = "i")
  polygon(AMx.dens, col = pal.3.t[3], border = pal.3[6], lty = 3)
  polygon(BAM.dens, col = pal.1.t[3], border = pal.1[6], lty = 2)
  polygon(ISR.dens, col = pal.2.t[3], border = pal.2[6], lty = 1)

  abline(v = mean.y, lwd = 2)
  abline(v = means[party.n], lwd = 1.5, lty = 3)

  axis(1)
  if (supp == F & left == T) {mtext(text = EES.UK.names[party.n], side = 2, line = 1.3, outer = F)}
    if (party.n == from.leftmost[1]) {
      if (supp == F & left == T) {mtext("V < 0 & U < .5", side = 3, line = 1.3, outer = F)}
      if (supp == T & left == T) {mtext("V < 0 & U >= .5", side = 3, line = 1.3, outer = F)}
      if (supp == T & left == F) {mtext("V > 0 & U >= .5", side = 3, line = 1.3, outer = F)}
      if (supp == F & left == F) {
        mtext("V > 0 & U < .5", side = 3, line = 1.3, outer = F)
        legend.2("topright", inset = c(0, -.135), c("AM*", "BAM", "ISR", "Mean", "CHES"), lty = c(0, 0, 0, 1, 3), lwd = c(0, 0, 0, 2, 1.5), fill.lty = c(3, 2, 1, 0, 0), fill = c(pal.3.t[3], pal.1.t[3], pal.2.t[3], NA, NA), 
          border = c(pal.3[6], pal.1[6], pal.2[6], NA, NA), bty = "n", cex = 1.2, seg.len = 1, x.intersp = c(0, 0, 0, .915, .915))
    }
  }
}

same.side.AMx <- 0; same.side.BAM <- 0; same.side.ISR <- 0

cairo_pdf(file = "figures/figure_5.pdf", onefile = F, width = 10, height = 11, family = "Helvetica", fallback_resolution = 600)
  par(oma = c(2, 2.1, 1.8, 0), mfrow = c(8, 4), cex = .7, mar = c(1.1, 1.1, 2.1, 1.1), mgp = c(2.5, 1, 0))
  for (p in from.leftmost) {
    plot.PP.dens(p, F, T)
    plot.PP.dens(p, T, T)
    plot.PP.dens(p, T, F)
    plot.PP.dens(p, F, F)
  }
dev.off()

same.side.AMx / (8 * 4)
same.side.BAM / (8 * 4)
same.side.ISR / (8 * 4)

####################################################################################################
# Figure S4:
plot.PP.dens2 <- function(party.n, supp, left, prob) {
  if (supp == T) {
    if (left == T) {use <- has.var & high.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V < 0} 
    else {use <- has.var & high.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V > 0}
  } 
  else {
    if (left == T) {use <- has.var & low.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V < 0} 
    else {use <- has.var & low.which[, party.n] == T & dat$M[, party.n] == 0 & dat$V > 0}
  }

  mean.BAM <- vector()
  for (s in 1:n.2) {mean.BAM <- c(mean.BAM, mean(Yhat.BAM[[s]][use, party.n], na.rm = T))}
  mean.BAM2 <- vector()
  for (s in 1:n.2) {mean.BAM2 <- c(mean.BAM2, mean(Yhat.BAM2[[s]][use, party.n], na.rm = T))}
  
  mean.y <- mean(dat$Y[use, party.n], na.rm = T)

  if ((mean.y < 0) == (mean(mean.BAM) < 0)) {same.side.BAM <<- same.side.BAM + 1}
  if ((mean.y < 0) == (mean(mean.BAM2) < 0)) {same.side.BAM2 <<- same.side.BAM2 + 1}

  BAM.dens <- density(mean.BAM, na.rm = T); BAM2.dens <- density(mean.BAM2, na.rm = T)
  
  xlims = c(-3, 3); ylims = c(0, 1.025 * max(max(BAM.dens$y), max(BAM.dens$y), max(BAM2.dens$y)))
  
  plot(BAM.dens, ylim = ylims, xlim = xlims, type = "n", axes = F, main = "", xlab = "Party Placement", xaxs = "i", yaxs = "i")
  polygon(BAM.dens, col = pal.1.t[3], border = pal.1[6], lty = 2)
  polygon(BAM2.dens, col = pal.2.t[3], border = pal.2[6], lty = 1)

  abline(v = mean.y, lwd = 2)
  abline(v = means[party.n], lwd = 1.5, lty = 3)
  axis(1)
  
  if (supp == F & left == T) {mtext(text = EES.UK.names[party.n], side = 2, line = 1.3, outer = F)}
    if (party.n == from.leftmost[1]) {
      if (supp == F & left == T) {mtext("V < 0 & U < .5", side = 3, line = 1.3, outer = F)}
      if (supp == T & left == T) {mtext("V < 0 & U >= .5", side = 3, line = 1.3, outer = F)}
      if (supp == T & left == F) {mtext("V > 0 & U >= .5", side = 3, line = 1.3, outer = F)}
      if (supp == F & left == F) {
        mtext("V > 0 & U < .5", side = 3, line = 1.3, outer = F)
        legend.2("topright", inset = c(0, -.135), c("BAM", "BAM2", "Mean", "CHES"), lty = c(0, 0, 1, 3), lwd = c(0, 0, 2, 1.5), fill.lty = c(2, 1, 0, 0), fill = c(pal.1.t[3], pal.2.t[3], NA, NA), 
          border = c(pal.1[6], pal.2[6], NA, NA), bty = "n", cex = 1.2, seg.len = 1, x.intersp = c(0, 0, .915, .915))
    }
  }
}

same.side.BAM <- 0; same.side.BAM2 <- 0

cairo_pdf(file = "figures/figure_S4.pdf", onefile = F, width = 10, height = 11, family = "Helvetica", fallback_resolution = 600)
  par(oma = c(2, 2.1, 1.8, 0), mfrow = c(8, 4), cex = .7, mar = c(1.1, 1.1, 2.1, 1.1), mgp = c(2.5, 1, 0))
  for (p in from.leftmost) {
    plot.PP.dens2(p, F, T)
    plot.PP.dens2(p, T, T)
    plot.PP.dens2(p, T, F)
    plot.PP.dens2(p, F, F)
  }
dev.off()
