# Note: This code saves predictions that require about 200MB of space.

library(rstan)

source("scripts/functions_general.R")

load("data/data_EES.R")

load("results/AMx_fit_UK_N536.R")
load("results/BAM_fit_UK_N536.R")
load("results/BAM2_fit_UK_N536.R")
load("results/ISR_fit_UK_N536.R")

dat <- get.EES.data(data.all, "UK")
dat <- prep.data(dat$self, dat$ppos, dat$prefs, allow.miss = 0, req.only.Y = T)
dat$Y <- as.matrix(dat$Y)
attach(dat)

# For seed-comparability with future versions of R:
if ((version$major == "3" & as.numeric(version$minor) >=  6.0) | as.numeric(version$major) > 3) {RNGkind(sample.kind = "Rounding")} 
set.seed(123)

####################################################################################################
# ISR model:
gamma.samples.ISR <- extract(fit.ISR, pars = "gamma")[[1]]
theta.samples.ISR <- extract(fit.ISR, pars = "theta")[[1]]
alpha.samples.ISR <- extract(fit.ISR, pars = "alpha")[[1]]
beta.samples.ISR <- extract(fit.ISR, pars = "beta")[[1]]
sigma.samples.ISR <- extract(fit.ISR, pars = "sigma")[[1]]
delta.samples.ISR <- extract(fit.ISR, pars = "delta")[[1]]

theta.est.ISR <- apply.get.CIs(theta.samples.ISR) 

Yhat.ISR <- list()
for (s in 1:nrow(theta.samples.ISR)) {
  Yhat <- matrix(NA, nrow = N, ncol = J)
  gamma <- gamma.samples.ISR[s, ]
  alpha <- alpha.samples.ISR[s, ]
  beta <- beta.samples.ISR[s, ]
  sigma <- sigma.samples.ISR[s, , ]
  theta <- theta.samples.ISR[s, ]
  delta <- delta.samples.ISR[s]

  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        w <- (.5 * (1-delta)) + (delta * plogis((5.0 / (B * 1.0)) * (V[i] - (alpha[i] + beta[i] * theta[j]))))
        Yhat[i, j] <-  (w * rnorm(1, (1 - gamma[i]) * (alpha[i] + beta[i] * theta[j]) + gamma[i] * (U[i, j] * V[i] + B * U[i, j] - B), sigma[i, j]))  + 
          ((1 - w) * rnorm(1, (1 - gamma[i]) * (alpha[i] + beta[i] * theta[j]) + gamma[i] * (U[i, j] * V[i] - B * U[i, j] + B), sigma[i, j]))
      }
    }
  }
  Yhat.ISR[[s]] <- Yhat
  rm(Yhat)
}

####################################################################################################
# BAM model:
theta.samples.BAM <- extract(fit.BAM, pars = "theta")[[1]]
alpha.samples.BAM <- extract(fit.BAM, pars = "alpha")[[1]]
beta.samples.BAM <- extract(fit.BAM, pars = "beta")[[1]]
sigma.samples.BAM <- extract(fit.BAM, pars = "sigma")[[1]]

theta.est.BAM <- apply.get.CIs(theta.samples.BAM) 

Yhat.BAM <- list()
for (s in 1:nrow(theta.samples.BAM)) {
  Yhat <- matrix(NA, nrow = N, ncol = J)
  alpha <- alpha.samples.BAM[s, ]
  beta <- beta.samples.BAM[s, ]
  sigma <- sigma.samples.BAM[s, , ]
  theta <- theta.samples.BAM[s, ]

  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        Yhat[i, j] <- rnorm(1, alpha[i] + beta[i] * theta[j], sigma[i, j])
      } 
    }
  }
  Yhat.BAM[[s]] <- Yhat
  rm(Yhat)
}

####################################################################################################
# BAM2 model:
theta.samples.BAM2 <- extract(fit.BAM2, pars = "theta")[[1]]
alpha.samples.BAM2 <- extract(fit.BAM2, pars = "alpha")[[1]]
beta.samples.BAM2 <- extract(fit.BAM2, pars = "beta")[[1]]
sigma.samples.BAM2 <- extract(fit.BAM2, pars = "sigma")[[1]]

theta.est.BAM2 <- apply.get.CIs(theta.samples.BAM2) 

Yhat.BAM2 <- list()
for (s in 1:nrow(theta.samples.BAM2)) {
  Yhat <- matrix(NA, nrow = N, ncol = J)
  alpha <- alpha.samples.BAM2[s, ]
  beta <- beta.samples.BAM2[s, ]
  sigma <- sigma.samples.BAM2[s, , ]
  theta <- theta.samples.BAM2[s, ]

  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        Yhat[i, j] <- rnorm(1, alpha[i] + beta[i] * theta[j], sigma[i, j]) 
      }
    }
  }
  Yhat.BAM2[[s]] <- Yhat
  rm(Yhat)
}

####################################################################################################
# AMx / homoskedastic BAM model:
theta.samples.AMx <- extract(fit.AMx, pars = "theta")[[1]]
alpha.samples.AMx <- extract(fit.AMx, pars = "alpha")[[1]]
beta.samples.AMx <- extract(fit.AMx, pars = "beta")[[1]]
sigma.samples.AMx <- extract(fit.AMx, pars = "sigma")[[1]]

theta.est.AMx <- apply.get.CIs(theta.samples.AMx) 

Yhat.AMx <- list()
for (s in 1:nrow(theta.samples.AMx)) {
  Yhat <- matrix(NA, nrow = N, ncol = J)
  alpha <- alpha.samples.AMx[s, ]
  beta <- beta.samples.AMx[s, ]
  sigma <- sigma.samples.AMx[s]
  theta <- theta.samples.AMx[s, ]

  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        Yhat[i, j] <- rnorm(1, alpha[i] + beta[i] * theta[j], sigma) 
      }
    }
  }
  Yhat.AMx[[s]] <- Yhat
  rm(Yhat)
}

####################################################################################################
# Saving the predictions:
save(list = c("Yhat.AMx", "Yhat.BAM", "Yhat.BAM2", "Yhat.ISR", "theta.est.ISR", "theta.est.BAM"), file = "results/UK_Yhats.R")

