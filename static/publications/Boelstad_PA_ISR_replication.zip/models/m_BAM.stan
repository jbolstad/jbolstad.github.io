// Adapted from the JAGS code by Hare et al. (AJPS 2015).

data {
  int<lower = 1> N;                       // n of individuals
  int<lower = 1> J;                       // n of items
  int<lower = 1, upper = J> L;            // left pole
  int<lower = 1, upper = J> R;            // right pole
  real Y[N, J];                           // reported stimuli position
  int<lower = 0, upper = 1> M[N, J];      // indicator of missing values
}

parameters {
  real alpha[N];                          // shift parameter
  real beta[N];                           // stretch parameter
  real<lower = -1.1, upper = -.9> thetal; // left pole stimuli
  real<lower = .9, upper = 1.1> thetar;   // right pole stimuli           
  real thetam[J];                         // remaining stimuli
  real<lower = 0> nu;                     // hyperparameter
  real<lower = 0> omega;                  // hyperparameter
  vector<lower = 0>[N] tau;               // individual precision    
  row_vector<lower = 0>[J] eta;           // stimuli precision
}

transformed parameters { 
  real theta[J];                          // latent stimuli position
  matrix[N, J] log_lik;                   // pointwise log-likelihood
  matrix[N, J] sigma;                
  theta = thetam;
  theta[L] = thetal; 
  theta[R] = thetar; 
  sigma = sqrt(1 ./ (tau * eta) );
  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        log_lik[i, j] = normal_lpdf(Y[i, j] | alpha[i] + beta[i] * theta[j], sigma[i, j]);}
      else {log_lik[i, j] = 0;}
    }
  }
}

model {
  alpha ~ uniform(-100, 100);
  beta ~ uniform(-100, 100);  
  thetam ~ normal(0, 1);
  thetal ~ normal(0, 1);
  thetar ~ normal(0, 1);
  nu ~ gamma(0.1, 0.1);
  omega ~ gamma(0.1, 0.1);
  tau ~ gamma(nu, omega);
  eta ~ gamma(0.1, 0.1);  
  target += sum(log_lik);
}
