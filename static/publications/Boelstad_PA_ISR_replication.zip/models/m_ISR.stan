data {
  int<lower = 1> N;                       // n of individuals
  int<lower = 1> J;                       // n of items
  int<lower = 1> B;                       // scale bound
  int<lower = -B, upper = B> Y[N, J];     // reported stimuli position
  int<lower = -B, upper = B> V[N];        // reported voter position
  real<lower = 0, upper = 1> U[N, J];     // reported voter preference
  int<lower = 0, upper = 1> M[N, J];      // indicator of missing values
}

transformed data {
  real<lower = -B, upper = B> p1[N, J];
  real<lower = -B, upper = B> p2[N, J];
  real z;
  z = (5.0 / (B * 1.0));
  for (i in 1:N) {
    for (j in 1:J) {
      p1[i, j] = U[i, j] * V[i] + B * U[i, j] - B;
      p2[i, j] = U[i, j] * V[i] - B * U[i, j] + B;
    }
  } 
}

parameters {
  vector[N] alpha_raw;                    // shift parameter, raw
  real beta[N];                           // stretch parameter
  real theta[J];                          // latent stimuli position
  real<lower = 0> lambda;                 // sd of alpha
  real<lower = 1> nu;                     // hyperparameter
  real<lower = 0> tau;                    // hyperparameter
  vector<lower = 0>[N] eta;               // mean ind. variance x J^2
  simplex[J] rho;                         // stimuli-shares of variance
  real<lower = 0, upper = 1> gamma[N];    // rationalization
  real<lower = 1> gam_a;                  // hyperparameter
  real<lower = 1> gam_b;                  // hyperparameter
  real<lower = 0, upper = 1> delta;       // weight in mixing prop.
}

transformed parameters {
  vector[N] alpha;                        // shift parameter
  real mu0;                               // dif-adjusted mean
  matrix<lower = 0>[N, J] sigma;          // sd's of errors
  matrix[N, J] log_lik;                   // pointwise log-likelihood
  alpha = alpha_raw * lambda;       
  sigma = sqrt(eta) * to_row_vector(rho);  
  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        mu0 = alpha[i] + beta[i] * theta[j];
        log_lik[i, j] = log_mix( (.5 * (1 - delta)) + (delta * inv_logit(z * (V[i] - mu0))), 
          normal_lpdf(Y[i, j] | (1 - gamma[i]) * mu0 + gamma[i] * p1[i, j], sigma[i, j]), 
          normal_lpdf(Y[i, j] | (1 - gamma[i]) * mu0 + gamma[i] * p2[i, j], sigma[i, j]) );
      }
      else {log_lik[i, j] = 0;}
    }
  }
}

model {
  alpha_raw ~ normal(0, 1); 
  lambda ~ cauchy(0, B);
  beta ~ normal(1, 1);   
  gamma ~ beta(gam_a, gam_b);
  gam_a ~ gamma(1.5, .5);
  gam_b ~ gamma(1.5, .5);
  delta ~ beta(3, 1.1);  
  theta ~ normal(0, 10);  
  nu ~ cauchy(0, 50);
  tau ~ cauchy(0, J * B);
  eta ~ scaled_inv_chi_square(nu, tau);
  rho ~ dirichlet(rep_vector(5, J)); 

  target += sum(log_lik);
}
