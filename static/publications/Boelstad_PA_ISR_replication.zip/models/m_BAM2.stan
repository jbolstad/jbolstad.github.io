data {
  int<lower = 1> N;                       // n of individuals
  int<lower = 1> J;                       // n of items
  int<lower = 1> B;                       // scale bound
  int<lower = -B, upper = B> Y[N, J];     // reported stimuli position
  int<lower = 0, upper = 1> M[N, J];      // indicator of missing values
}

parameters {
  vector[N] alpha_raw;                    // shift parameter, raw
  real beta[N];                           // stretch parameter
  real theta[J];                          // latent stimuli position
  real<lower = 0> lambda;                 // sd of alpha
  real<lower = 1> nu;                     // hyperparameter
  real<lower = 0> tau;                    // hyperparameter
  vector<lower = 0>[N] eta;               // mean ind. variance x J^2
  simplex[J] rho;                         // stimuli-shares of variance
}

transformed parameters {
  vector[N] alpha;                        // shift parameter
  matrix<lower = 0>[N, J] sigma;          // sd's of errors
  matrix[N, J] log_lik;                   // pointwise log-likelihood
  alpha = alpha_raw * lambda;       
  sigma = sqrt(eta) * to_row_vector(rho);  
  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {
        log_lik[i, j] = normal_lpdf(Y[i, j] | alpha[i] + beta[i] * theta[j], sigma[i, j]);
      }
      else {log_lik[i, j] = 0;}
    }
  }
}

model {
  alpha_raw ~ normal(0, 1); 
  lambda ~ cauchy(0, B);
  beta ~ normal(1, 1);   
  theta ~ normal(0, 10);  
  nu ~ cauchy(0, 50);
  tau ~ cauchy(0, J * B);
  eta ~ scaled_inv_chi_square(nu, tau);
  rho ~ dirichlet(rep_vector(5, J)); 

  target += sum(log_lik);
}
