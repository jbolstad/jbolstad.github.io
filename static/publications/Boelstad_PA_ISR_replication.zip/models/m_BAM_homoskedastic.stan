data {
  int<lower = 1> N;                       // n of individuals
  int<lower = 1> J;                       // n of items
  int<lower = 1, upper = J> L;            // left pole
  int<lower = 1, upper = J> R;            // right pole
  real Y[N, J];                           // reported stimuli position
  int<lower = 0, upper = 1> M[N, J];      // indicator of missing values
}

parameters {
  real alpha[N];                          // shift parameter
  real beta[N];                           // stretch parameter
  real<lower = -1.1, upper = -.9> thetal; // left pole stimuli
  real<lower = .9, upper = 1.1> thetar;   // right pole stimuli           
  real thetam[J];                         // remaining stimuli
  real<lower = 0> tau;                    // homoskedastic precision
}

transformed parameters { 
  real theta[J];                          // latent stimuli position
  matrix[N, J] log_lik;                   // pointwise log-likelihood
  real sigma = sqrt(1 / tau);
  theta = thetam;
  theta[L] = thetal; 
  theta[R] = thetar; 
  for (i in 1:N) {
    for (j in 1:J) {
      if (M[i, j] == 0) {	
        log_lik[i, j] = normal_lpdf(Y[i, j] | alpha[i] + beta[i] * theta[j], sigma);
      }
      else {log_lik[i, j] = 0;}
    }
  }
}

model {
  alpha ~ uniform(-100, 100);
  beta ~ uniform(-100, 100);  
  thetam ~ normal(0, 1);
  thetal ~ normal(0, 1);
  thetar ~ normal(0, 1);
  tau ~ gamma(.1, .1);
  
  target += sum(log_lik);
}
